/**
 * Criptografia dos dados no navegador (Web Crypto).
 * Senha → chave com PBKDF2-SHA256 (lento de propósito) → AES-GCM 256 bits.
 * A chave nunca é gravada: fica só na memória enquanto a sessão está aberta.
 */

export const DEFAULT_ITERATIONS = 600_000

const enc = new TextEncoder()
const dec = new TextDecoder()

export function toB64(buf: ArrayBuffer | Uint8Array): string {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf)
  let s = ''
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i])
  return btoa(s)
}

export function fromB64(b64: string): Uint8Array {
  const s = atob(b64)
  const out = new Uint8Array(s.length)
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i)
  return out
}

export function randomBytes(n: number): Uint8Array {
  return crypto.getRandomValues(new Uint8Array(n))
}

export function cryptoAvailable(): boolean {
  return typeof crypto !== 'undefined' && !!crypto.subtle && typeof crypto.getRandomValues === 'function'
}

export async function sha256Hex(text: string): Promise<string> {
  const h = await crypto.subtle.digest('SHA-256', enc.encode(text))
  return Array.from(new Uint8Array(h), (b) => b.toString(16).padStart(2, '0')).join('')
}

export async function deriveKey(password: string, salt: Uint8Array, iterations: number): Promise<CryptoKey> {
  const base = await crypto.subtle.importKey('raw', enc.encode(password.normalize('NFKC')), 'PBKDF2', false, ['deriveKey'])
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', hash: 'SHA-256', salt: salt as BufferSource, iterations },
    base,
    { name: 'AES-GCM', length: 256 },
    false, // não extraível
    ['encrypt', 'decrypt'],
  )
}

/** Formato gravado: { v, iv, ct } em base64. O IV é novo a cada gravação. */
export interface Sealed {
  v: 1
  iv: string
  ct: string
}

export async function seal(key: CryptoKey, value: unknown): Promise<string> {
  const iv = randomBytes(12)
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv as BufferSource }, key, enc.encode(JSON.stringify(value)))
  const out: Sealed = { v: 1, iv: toB64(iv), ct: toB64(ct) }
  return JSON.stringify(out)
}

/** Lança erro se a chave estiver errada ou o conteúdo tiver sido alterado (AES-GCM autentica). */
export async function open<T = unknown>(key: CryptoKey, sealed: string): Promise<T> {
  const p = JSON.parse(sealed) as Sealed
  if (!p || p.v !== 1 || typeof p.iv !== 'string' || typeof p.ct !== 'string') throw new Error('formato inválido')
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64(p.iv) as BufferSource }, key, fromB64(p.ct) as BufferSource)
  return JSON.parse(dec.decode(pt)) as T
}
