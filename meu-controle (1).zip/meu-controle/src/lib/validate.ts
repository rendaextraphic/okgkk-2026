import type { AppData } from '../types'
import { createInitialData, defaultSettings } from './defaults'
import { isISODate } from './dates'

type Result = { ok: true; data: AppData } | { ok: false; errors: string[] }

const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v)
const isNum = (v: unknown) => typeof v === 'number' && Number.isFinite(v)
const isStr = (v: unknown) => typeof v === 'string'

type Check = (r: Record<string, unknown>) => string | null

const needs = (fields: Record<string, 'str' | 'num' | 'date' | 'dateOpt'>): Check => (r) => {
  for (const [k, t] of Object.entries(fields)) {
    const v = r[k]
    if (t === 'str' && !isStr(v)) return `campo "${k}" inválido`
    if (t === 'num' && !isNum(v)) return `campo "${k}" inválido`
    if (t === 'date' && !isISODate(v)) return `campo "${k}" não é uma data válida`
    if (t === 'dateOpt' && !(v === '' || v === undefined || isISODate(v))) return `campo "${k}" não é uma data válida`
  }
  return null
}

const COLLECTIONS: Record<string, Check> = {
  productivity: (r) =>
    needs({ id: 'str', date: 'date', qty: 'num', unitValue: 'num' })(r) ?? (r.type === 'conferencia' || r.type === 'separacao' ? null : 'campo "type" inválido'),
  payrolls: (r) => needs({ id: 'str', month: 'str', gross: 'num', deductions: 'num', net: 'num', expectedDate: 'dateOpt', paidDate: 'dateOpt' })(r),
  expenses: (r) =>
    needs({ id: 'str', name: 'str', category: 'str', amount: 'num', dueDate: 'date', paidDate: 'dateOpt' })(r) ??
    (r.status === 'pendente' || r.status === 'paga' ? null : 'campo "status" inválido'),
  debts: (r) =>
    needs({ id: 'str', name: 'str', originalAmount: 'num', currentAmount: 'num', downPayment: 'num', totalInstallments: 'num', installmentValue: 'num', nextDue: 'dateOpt' })(r),
  debtPayments: (r) => needs({ id: 'str', debtId: 'str', date: 'date', amount: 'num' })(r),
  transactions: (r) =>
    needs({ id: 'str', description: 'str', category: 'str', amount: 'num', date: 'date' })(r) ??
    (r.type === 'entrada' || r.type === 'saida' ? null : 'campo "type" inválido'),
  goals: (r) => needs({ id: 'str', name: 'str', target: 'num', saved: 'num', deadline: 'dateOpt' })(r),
}

/** Valida um backup JSON e o mescla com os padrões, sem confiar em campos ausentes. */
export function validateBackup(raw: unknown): Result {
  const errors: string[] = []
  if (!isObj(raw)) return { ok: false, errors: ['O arquivo não contém um objeto JSON válido.'] }
  if (raw.version !== 1) errors.push('Versão de backup desconhecida (esperado: 1).')
  if (!isObj(raw.settings)) errors.push('Configurações ausentes ou inválidas.')

  const base = createInitialData()
  const data: AppData = { ...base }

  for (const [key, check] of Object.entries(COLLECTIONS)) {
    const list = raw[key]
    if (list === undefined) continue
    if (!Array.isArray(list)) {
      errors.push(`"${key}" deve ser uma lista.`)
      continue
    }
    const ids = new Set<string>()
    list.forEach((item, i) => {
      if (!isObj(item)) return errors.push(`${key}[${i}]: registro inválido`)
      const msg = check(item)
      if (msg) return errors.push(`${key}[${i}]: ${msg}`)
      const id = String(item.id)
      if (ids.has(id)) return errors.push(`${key}[${i}]: id duplicado (${id})`)
      ids.add(id)
    })
    ;(data as unknown as Record<string, unknown>)[key] = list
  }

  if (errors.length) return { ok: false, errors: errors.slice(0, 12) }

  const s = raw.settings as Record<string, unknown>
  data.settings = { ...defaultSettings, ...(s as object) } as AppData['settings']
  // mantém a estrutura aninhada válida
  data.settings.inss = { ...defaultSettings.inss, ...(isObj(s.inss) ? (s.inss as object) : {}) } as AppData['settings']['inss']
  for (const k of ['otherAdditions', 'otherDeductions', 'expenseCategories', 'incomeCategories', 'accounts'] as const) {
    if (!Array.isArray(data.settings[k])) (data.settings as unknown as Record<string, unknown>)[k] = defaultSettings[k]
  }
  if (!isObj(data.settings.budgets)) data.settings.budgets = {}
  data.monthParams = isObj(raw.monthParams) ? (raw.monthParams as AppData['monthParams']) : {}
  data.deletedOccurrences = Array.isArray(raw.deletedOccurrences) ? (raw.deletedOccurrences as string[]).filter(isStr) : []
  data.seriesEnds = isObj(raw.seriesEnds) ? (raw.seriesEnds as AppData['seriesEnds']) : {}
  data.updatedAt = new Date().toISOString()
  return { ok: true, data }
}
