import { describe, expect, it } from 'vitest'
import type { AppData, Debt, DebtPayment, Expense, ProductivityEntry, Transaction } from '../types'
import { createInitialData } from './defaults'
import {
  accountBalances,
  buildAlerts,
  calcDebt,
  computePayroll,
  debtOutflow,
  effectivePayroll,
  expenseStatus,
  extraIncome,
  generateOccurrences,
  ledgerTotals,
  nextPayDate,
  pendingInstallments,
  plannedBalance,
  productionValue,
  realizedBalance,
  rangeSummary,
  simulatePayoff,
  summarizeProductivity,
  totalsByCategory,
} from './calc'
import { addMonths, monthRange, payrollPeriod } from './dates'
import { brl, formatDateBR, parseNumber, round2 } from './format'
import { validateBackup } from './validate'

const prod = (date: string, type: 'conferencia' | 'separacao', qty: number, unit = 5): ProductivityEntry => ({
  id: `${date}-${type}-${qty}`,
  date,
  type,
  qty,
  unitValue: unit,
})

const debt = (over: Partial<Debt> = {}): Debt => ({
  id: 'd1',
  name: 'Empréstimo',
  creditor: 'Banco',
  category: 'Empréstimo',
  originalAmount: 1200,
  currentAmount: 0,
  downPayment: 0,
  totalInstallments: 12,
  installmentValue: 100,
  paidInstallmentsInitial: 0,
  interestRate: 0,
  contractDate: '2026-01-10',
  nextDue: '2026-11-10',
  status: 'ativa',
  priority: 'media',
  notes: '',
  ...over,
})

const pay = (amount: number, date = '2026-10-10', debtId = 'd1', id = `p${amount}${date}`): DebtPayment => ({ id, debtId, date, amount, notes: '' })

describe('formatação e números', () => {
  it('formata moeda no padrão brasileiro', () => {
    expect(brl(1234.56).replace(/\s/g, ' ')).toBe('R$ 1.234,56')
    expect(brl(-10).replace(/\s/g, ' ')).toContain('10,00')
    expect(brl(0.1 + 0.2).replace(/\s/g, ' ')).toBe('R$ 0,30')
  })
  it('formata datas como DD/MM/AAAA', () => {
    expect(formatDateBR('2026-10-09')).toBe('09/10/2026')
    expect(formatDateBR('')).toBe('—')
  })
  it('converte textos numéricos brasileiros', () => {
    expect(parseNumber('1.234,56')).toBe(1234.56)
    expect(parseNumber('R$ 2.120,00')).toBe(2120)
    expect(parseNumber('5')).toBe(5)
    expect(parseNumber('5,5')).toBe(5.5)
    expect(parseNumber('1.234')).toBe(1234)
    expect(parseNumber('12.5')).toBe(12.5)
    expect(parseNumber('')).toBeNaN()
    expect(parseNumber('abc')).toBeNaN()
    expect(parseNumber('1,2,3')).toBeNaN()
  })
  it('arredonda dinheiro de forma consistente', () => {
    expect(round2(1.005)).toBe(1.01)
    expect(round2(-1.005)).toBe(-1.01)
    expect(round2(0.1 + 0.2)).toBe(0.3)
    expect(Object.is(round2(-0.001), -0)).toBe(false)
  })
  it('soma meses sem estourar o fim do mês', () => {
    expect(addMonths('2026-01-31', 1)).toBe('2026-02-28')
    expect(addMonths('2026-12-15', 1)).toBe('2027-01-15')
    expect(addMonths('2026-03-31', -1)).toBe('2026-02-28')
  })
})

describe('produtividade', () => {
  it('calcula quantidade x valor unitário (exemplo do enunciado)', () => {
    expect(productionValue(30, 5)).toBe(150)
    expect(productionValue(20, 5)).toBe(100)
    const s = summarizeProductivity([prod('2026-10-01', 'conferencia', 30), prod('2026-10-01', 'separacao', 20)])
    expect(s.confValue).toBe(150)
    expect(s.sepValue).toBe(100)
    expect(s.totalValue).toBe(250)
    expect(s.activeDays).toBe(1)
    expect(s.avgPerDay).toBe(250)
  })
  it('encontra o melhor dia e a média por dia trabalhado', () => {
    const s = summarizeProductivity([
      prod('2026-10-01', 'conferencia', 10),
      prod('2026-10-02', 'separacao', 40),
      prod('2026-10-02', 'conferencia', 10),
    ])
    expect(s.bestDay).toEqual({ date: '2026-10-02', value: 250 })
    expect(s.totalValue).toBe(300)
    expect(s.avgPerDay).toBe(150)
  })
  it('lida com valores inválidos sem gerar NaN', () => {
    expect(productionValue(NaN, 5)).toBe(0)
    expect(summarizeProductivity([]).avgPerDay).toBe(0)
    expect(summarizeProductivity([]).bestDay).toBeNull()
  })
})

describe('salário', () => {
  const base = () => {
    const d = createInitialData()
    d.settings.nightHoursPerDay = 7
    d.settings.workedDays = 22
    d.productivity = [prod('2026-10-02', 'conferencia', 30), prod('2026-10-03', 'separacao', 20)]
    return d
  }

  it('calcula bruto, descontos e líquido com valores conhecidos', () => {
    const c = computePayroll(base(), '2026-10')
    expect(c.baseSalary).toBe(2120)
    // 2120 / 220h * 20% * (7h x 22 dias = 154h) = 296,80
    expect(c.nightHours).toBe(154)
    expect(c.nightAdditional).toBe(296.8)
    expect(c.attendance).toBe(200)
    expect(c.productionEligible).toBe(250)
    expect(c.gross).toBe(2866.8) // 2120 + 296,80 + 200 + 250
    expect(c.vt).toBe(127.2) // 6% de 2120
    expect(c.inss).toBe(0)
    expect(c.inssConfigured).toBe(false)
    expect(c.totalDeductions).toBe(127.2)
    expect(c.net).toBe(2739.6)
  })

  it('NÃO aplica 20% sobre o salário inteiro sem horas noturnas informadas', () => {
    const d = createInitialData()
    const c = computePayroll(d, '2026-10')
    expect(c.nightAdditional).toBe(0)
    expect(c.warnings.some((w) => w.includes('Adicional noturno'))).toBe(true)
  })

  it('respeita pagamento parcial e pendente da produtividade', () => {
    const d = base()
    d.settings.prodPayMode = 'parcial'
    d.settings.prodPartialPct = 40
    let c = computePayroll(d, '2026-10')
    expect(c.productionEligible).toBe(100)
    expect(c.productionPending).toBe(150)
    d.settings.prodPayMode = 'pendente'
    c = computePayroll(d, '2026-10')
    expect(c.productionEligible).toBe(0)
    expect(c.gross).toBe(2616.8)
  })

  it('usa parâmetros do mês no lugar dos padrões e ignora outros meses', () => {
    const d = base()
    d.monthParams['2026-10'] = { nightHours: 100, advances: 300 }
    const c = computePayroll(d, '2026-10')
    expect(c.nightHours).toBe(100)
    expect(c.advances).toBe(300)
    expect(computePayroll(d, '2026-11').productionTotal).toBe(0)
  })

  it('calcula INSS apenas quando configurado (valor ou percentual informado pelo usuário)', () => {
    const d = base()
    d.settings.inss = { mode: 'valor', value: 200, competence: 'x' }
    expect(computePayroll(d, '2026-10').inss).toBe(200)
    d.settings.inss = { mode: 'percentual', value: 10, competence: 'x' }
    expect(computePayroll(d, '2026-10').inss).toBe(286.68)
  })

  it('suporta hora extra, vale-transporte fixo e outros itens', () => {
    const d = base()
    d.settings.overtimeEnabled = true
    d.settings.overtimeHours = 10
    d.settings.overtimePct = 50
    d.settings.vtMode = 'valor'
    d.settings.vtFixed = 150
    d.settings.otherAdditions = [{ id: '1', name: 'Bônus', amount: 100 }]
    d.settings.otherDeductions = [{ id: '2', name: 'Plano', amount: 50 }]
    const c = computePayroll(d, '2026-10')
    expect(c.overtime).toBe(144.55) // 2120/220 * 1,5 * 10
    expect(c.otherAdditions).toBe(100)
    expect(c.vt).toBe(150)
    expect(c.totalDeductions).toBe(200)
  })

  it('período da folha com dia de corte diferente de 1', () => {
    expect(payrollPeriod('2026-10', 1)).toEqual({ from: '2026-10-01', to: '2026-10-31' })
    expect(payrollPeriod('2026-10', 21)).toEqual({ from: '2026-09-21', to: '2026-10-20' })
    const d = base()
    d.settings.payrollStartDay = 21
    d.productivity = [prod('2026-09-25', 'conferencia', 10), prod('2026-10-25', 'conferencia', 10)]
    expect(computePayroll(d, '2026-10').productionTotal).toBe(50)
  })

  it('folha confirmada tem prioridade sobre a estimativa e mostra a diferença', () => {
    const d = base()
    const est = computePayroll(d, '2026-10').net
    d.payrolls = [
      { id: 'p1', month: '2026-10', expectedDate: '2026-11-05', paidDate: '2026-11-05', gross: 2800, deductions: 300, net: 2500, status: 'recebido', notes: '' },
    ]
    const eff = effectivePayroll(d, '2026-10')
    expect(eff.confirmed).toBe(true)
    expect(eff.net).toBe(2500)
    expect(round2(eff.net - est)).toBe(-239.6)
    d.payrolls[0].status = 'previsto'
    expect(effectivePayroll(d, '2026-10').confirmed).toBe(false)
  })

  it('próximo pagamento', () => {
    expect(nextPayDate({ payDay: 5 }, '2026-10-09')).toBe('2026-11-05')
    expect(nextPayDate({ payDay: 20 }, '2026-10-09')).toBe('2026-10-20')
  })
})

describe('despesas e recorrência', () => {
  const rec = (over: Partial<Expense> = {}): Expense => ({
    id: 'e1',
    name: 'Aluguel',
    category: 'Moradia',
    amount: 800,
    dueDate: '2026-10-05',
    paidDate: '',
    method: 'Pix',
    recurrence: 'mensal',
    status: 'pendente',
    notes: '',
    seriesId: 's1',
    seriesStart: '2026-10-05',
    occurrenceKey: 's1|2026-10-05',
    ...over,
  })

  it('gera ocorrências sem duplicar ao rodar várias vezes', () => {
    const d = { expenses: [rec()], deletedOccurrences: [] as string[], seriesEnds: {} as Record<string, string> }
    let n = 0
    const first = generateOccurrences(d, '2026-10-09', () => `n${n++}`)
    expect(first.length).toBe(12) // 05/11/2026 ... 05/10/2027
    d.expenses = [...d.expenses, ...first]
    const second = generateOccurrences(d, '2026-10-09', () => `n${n++}`)
    expect(second.length).toBe(0)
    const keys = d.expenses.map((e) => e.occurrenceKey)
    expect(new Set(keys).size).toBe(keys.length)
  })

  it('não recria ocorrências excluídas nem passa do fim da série', () => {
    const d = {
      expenses: [rec()],
      deletedOccurrences: ['s1|2026-11-05'],
      seriesEnds: { s1: '2027-01-31' } as Record<string, string>,
    }
    const created = generateOccurrences(d, '2026-10-09', () => Math.random().toString())
    const dates = created.map((e) => e.dueDate)
    expect(dates).not.toContain('2026-11-05')
    expect(dates).toEqual(['2026-12-05', '2027-01-05'])
  })

  it('classifica atrasada, pendente e paga', () => {
    expect(expenseStatus(rec({ dueDate: '2026-10-01' }), '2026-10-09')).toBe('atrasada')
    expect(expenseStatus(rec({ dueDate: '2026-10-20' }), '2026-10-09')).toBe('pendente')
    expect(expenseStatus(rec({ dueDate: '2026-10-01', status: 'paga' }), '2026-10-09')).toBe('paga')
  })

  it('agrupa por categoria', () => {
    const t = totalsByCategory([rec({ amount: 100 }), rec({ id: 'x', amount: 50, category: 'Saúde' }), rec({ id: 'y', amount: 25 })])
    expect(t).toEqual([
      { category: 'Moradia', total: 125 },
      { category: 'Saúde', total: 50 },
    ])
  })
})

describe('dívidas', () => {
  it('atualiza saldo, parcelas e percentual com pagamentos parciais e totais', () => {
    const d = debt({ paidInstallmentsInitial: 3 })
    let c = calcDebt(d, [], '2026-10-09')
    expect(c.totalOwed).toBe(1200)
    expect(c.paidTotal).toBe(300)
    expect(c.remaining).toBe(900)
    expect(c.paidInstallments).toBe(3)
    expect(c.remainingInstallments).toBe(9)
    c = calcDebt(d, [pay(250)], '2026-10-09')
    expect(c.paidTotal).toBe(550)
    expect(c.remaining).toBe(650)
    expect(c.paidInstallments).toBe(5) // 550/100 = 5,5 -> 5 parcelas completas
    expect(c.remainingInstallments).toBe(7)
    expect(Math.round(c.pct * 100) / 100).toBe(45.83)
    expect(c.status).toBe('em_dia')
  })

  it('usa valor atualizado e desconta a entrada quando não informado', () => {
    expect(calcDebt(debt({ originalAmount: 1500, downPayment: 300 }), [], '2026-10-09').totalOwed).toBe(1200)
    expect(calcDebt(debt({ currentAmount: 1350 }), [], '2026-10-09').totalOwed).toBe(1350)
  })

  it('marca quitada, atrasada e negociação', () => {
    const quit = calcDebt(debt(), [pay(1200)], '2026-10-09')
    expect(quit.status).toBe('quitada')
    expect(quit.remaining).toBe(0)
    expect(quit.pct).toBe(100)
    expect(calcDebt(debt({ nextDue: '2026-10-01' }), [], '2026-10-09').status).toBe('atrasada')
    expect(calcDebt(debt({ status: 'negociacao' }), [], '2026-10-09').status).toBe('negociacao')
  })

  it('prevê a quitação pela última parcela', () => {
    const c = calcDebt(debt(), [], '2026-10-09')
    expect(c.payoffDate).toBe('2027-10-10') // 12 parcelas a partir de 10/11/2026
  })

  it('parcelas pendentes somam exatamente o saldo restante', () => {
    const d = debt()
    const c = calcDebt(d, [pay(250)], '2026-10-09')
    const list = pendingInstallments(d, c)
    expect(list.reduce((a, p) => a + p.amount, 0)).toBeCloseTo(c.remaining, 2)
    expect(list[0].amount).toBe(50) // sobra da parcela já parcialmente paga
    expect(list[0].k).toBe(3)
  })

  it('saída com dívidas não conta duas vezes pagamento e parcela', () => {
    const d = createInitialData()
    d.debts = [debt({ nextDue: '2026-10-10' })]
    const range = monthRange('2026-10')
    const before = debtOutflow(d, range, '2026-10-01')
    expect(before).toEqual({ paid: 0, pending: 100, total: 100 })
    d.debtPayments = [pay(100, '2026-10-10')]
    d.debts[0].nextDue = '2026-11-10' // o pagamento avança o vencimento
    const after = debtOutflow(d, range, '2026-10-11')
    expect(after).toEqual({ paid: 100, pending: 0, total: 100 })
  })

  it('simula quitação com e sem pagamentos extras', () => {
    const base = simulatePayoff({ balance: 1000, payment: 100, extraMonthly: 0, lumpSum: 0, monthlyRate: 0 })
    expect(base).toMatchObject({ ok: true, months: 10, totalPaid: 1000, totalInterest: 0 })
    const extra = simulatePayoff({ balance: 1000, payment: 100, extraMonthly: 100, lumpSum: 0, monthlyRate: 0 })
    expect(extra.months).toBe(5)
    const lump = simulatePayoff({ balance: 1000, payment: 100, extraMonthly: 0, lumpSum: 500, monthlyRate: 0 })
    expect(lump.months).toBe(5)
    expect(lump.totalPaid).toBe(1000)
  })

  it('só calcula juros quando a taxa é informada', () => {
    const none = simulatePayoff({ balance: 1000, payment: 100, extraMonthly: 0, lumpSum: 0, monthlyRate: 0 })
    const withRate = simulatePayoff({ balance: 1000, payment: 100, extraMonthly: 0, lumpSum: 0, monthlyRate: 2 })
    expect(none.totalInterest).toBe(0)
    expect(withRate.totalInterest).toBeGreaterThan(0)
    expect(withRate.months).toBeGreaterThan(none.months)
  })

  it('detecta pagamento que nunca quita a dívida', () => {
    const r = simulatePayoff({ balance: 10000, payment: 100, extraMonthly: 0, lumpSum: 0, monthlyRate: 5 })
    expect(r.ok).toBe(false)
    expect(simulatePayoff({ balance: 100, payment: 0, extraMonthly: 0, lumpSum: 0, monthlyRate: 0 }).ok).toBe(false)
  })
})

describe('livro-caixa e resumos', () => {
  const tx = (over: Partial<Transaction>): Transaction => ({
    id: Math.random().toString(),
    type: 'entrada',
    description: 'x',
    category: 'Renda extra',
    amount: 100,
    date: '2026-10-10',
    account: 'Conta principal',
    origin: '',
    notes: '',
    status: 'efetivado',
    kind: 'normal',
    ...over,
  })

  it('separa saldo realizado do previsto', () => {
    const list = [tx({ amount: 1000 }), tx({ type: 'saida', amount: 300 }), tx({ amount: 500, status: 'previsto' }), tx({ type: 'saida', amount: 200, status: 'previsto' })]
    expect(realizedBalance(list)).toBe(700)
    expect(plannedBalance(list)).toBe(1000)
    expect(ledgerTotals(list)).toEqual({ inReal: 1000, outReal: 300, inPlan: 500, outPlan: 200 })
  })

  it('transferências não alteram o saldo total nem os totais de receitas/despesas', () => {
    const list = [
      tx({ amount: 1000 }),
      tx({ type: 'saida', amount: 400, kind: 'transferencia', account: 'Conta principal', category: 'Transferências' }),
      tx({ type: 'entrada', amount: 400, kind: 'transferencia', account: 'Carteira', category: 'Transferências' }),
    ]
    expect(realizedBalance(list)).toBe(1000)
    expect(ledgerTotals(list).outReal).toBe(0)
    const acc = accountBalances(list, ['Conta principal', 'Carteira'])
    expect(acc.find((a) => a.account === 'Conta principal')?.balance).toBe(600)
    expect(acc.find((a) => a.account === 'Carteira')?.balance).toBe(400)
  })

  it('lançamentos incorporados ao salário não entram nos saldos', () => {
    const list = [tx({ amount: 250, category: 'Produtividade', kind: 'incorporada' }), tx({ amount: 100 })]
    expect(realizedBalance(list)).toBe(100)
    expect(extraIncome(list, monthRange('2026-10'))).toBe(100)
  })

  it('receitas extras ignoram salário e itens da família do salário', () => {
    const list = [
      tx({ category: 'Salário', amount: 2000 }),
      tx({ category: 'Produtividade', amount: 300 }),
      tx({ category: 'Renda extra', amount: 150 }),
      tx({ category: 'Renda extra', amount: 80, sourceType: 'salary', sourceId: 'p' }),
    ]
    expect(extraIncome(list, monthRange('2026-10'))).toBe(150)
  })

  it('resumo do período não duplica dívida como despesa e compara com o salário', () => {
    const d: AppData = createInitialData()
    d.settings.nightHoursPerDay = 7
    d.settings.workedDays = 22
    d.expenses = [
      {
        id: 'e1', name: 'Luz', category: 'Água, luz e internet', amount: 200, dueDate: '2026-10-15', paidDate: '', method: '', recurrence: 'unica', status: 'pendente', notes: '',
      },
      {
        id: 'e2', name: 'Mercado', category: 'Alimentação', amount: 400, dueDate: '2026-10-20', paidDate: '2026-10-20', method: 'Pix', recurrence: 'unica', status: 'paga', notes: '',
      },
    ]
    d.debts = [debt({ nextDue: '2026-10-25' })]
    d.debtPayments = []
    const s = rangeSummary(d, monthRange('2026-10'), '2026-10-09')
    expect(s.expensesPlanned).toBe(600)
    expect(s.expensesPaid).toBe(400)
    expect(s.expensesPending).toBe(200)
    expect(s.debtTotal).toBe(100)
    expect(s.outflow).toBe(700) // despesas + parcela da dívida, cada uma uma única vez
    expect(s.salaryNet).toBe(2489.6) // 2120 + 296,80 + 200 - 127,20
    expect(s.balance).toBe(1789.6)
    expect(s.committedPct).toBeCloseTo(28.12, 1)
  })

  it('alertas: despesas acima das receitas, atrasos e orçamento', () => {
    const d: AppData = createInitialData()
    d.settings.baseSalary = 1000
    d.settings.attendanceEnabled = false
    d.settings.vtMode = 'nenhum'
    d.settings.budgets = { Lazer: 100 }
    d.expenses = [
      { id: 'e1', name: 'TV', category: 'Lazer', amount: 1500, dueDate: '2026-10-03', paidDate: '', method: '', recurrence: 'unica', status: 'pendente', notes: '' },
    ]
    const alerts = buildAlerts(d, '2026-10', '2026-10-09', (n) => `R$ ${n}`)
    const texts = alerts.map((a) => a.text).join(' | ')
    expect(texts).toContain('superam as receitas')
    expect(texts).toContain('em atraso')
    expect(texts).toContain('Orçamento de Lazer ultrapassado')
  })
})

describe('backup', () => {
  it('aceita um backup exportado e rejeita dados inválidos', () => {
    const d = createInitialData()
    d.productivity = [prod('2026-10-02', 'conferencia', 5)]
    const ok = validateBackup(JSON.parse(JSON.stringify(d)))
    expect(ok.ok).toBe(true)
    const bad = validateBackup({ version: 1, settings: {}, productivity: [{ id: 'a', date: 'ontem', qty: 'x', unitValue: 5, type: 'conferencia' }] })
    expect(bad.ok).toBe(false)
    expect(validateBackup('texto').ok).toBe(false)
    expect(validateBackup({ version: 2, settings: {} }).ok).toBe(false)
  })
  it('rejeita ids duplicados', () => {
    const d = createInitialData()
    const e = prod('2026-10-02', 'conferencia', 5)
    d.productivity = [e, { ...e }]
    expect(validateBackup(JSON.parse(JSON.stringify(d))).ok).toBe(false)
  })
})
