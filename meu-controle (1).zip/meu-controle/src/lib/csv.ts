/** CSV compatível com Excel em português (separador ";" e BOM UTF-8). */
export function toCSV(rows: (string | number | null | undefined)[][]): string {
  const esc = (v: string | number | null | undefined) => {
    if (v === null || v === undefined) return ''
    let s = typeof v === 'number' ? String(v).replace('.', ',') : String(v)
    // evita injeção de fórmulas ao abrir no Excel
    if (typeof v === 'string' && /^[=+\-@]/.test(s)) s = `'${s}`
    if (/[";\n\r]/.test(s)) s = `"${s.replace(/"/g, '""')}"`
    return s
  }
  return '﻿' + rows.map((r) => r.map(esc).join(';')).join('\r\n')
}

export function downloadFile(name: string, content: string | Blob, mime = 'text/plain;charset=utf-8') {
  const blob = content instanceof Blob ? content : new Blob([content], { type: mime })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = name
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 2000)
}
