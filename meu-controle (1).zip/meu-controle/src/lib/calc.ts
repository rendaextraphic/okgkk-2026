/**
 * Cálculos financeiros centralizados. Nenhuma página faz conta própria:
 * tudo passa por estas funções, que são cobertas por testes.
 */
import type {
  AppData,
  Debt,
  DebtPayment,
  Expense,
  PayrollRecord,
  ProductivityEntry,
  Range,
  Settings,
  Transaction,
  ActivityType,
} from '../types'
import { round2 } from './format'
import { SALARY_FAMILY } from './defaults'
import {
  addDays,
  addMonths,
  inRange,
  monthRange,
  monthsBetween,
  payrollPeriod,
  daysInRange,
} from './dates'

export const sum = (xs: number[]): number => round2(xs.reduce((a, b) => a + (Number.isFinite(b) ? b : 0), 0))
const clamp = (n: number, a: number, b: number) => Math.min(b, Math.max(a, n))

/* ------------------------------------------------------------------ */
/* Produtividade                                                       */
/* ------------------------------------------------------------------ */

export function productionValue(qty: number, unit: number): number {
  return round2((Number(qty) || 0) * (Number(unit) || 0))
}

export const entryValue = (e: ProductivityEntry) => productionValue(e.qty, e.unitValue)

export function filterProductivity(entries: ProductivityEntry[], range: Range, type?: ActivityType | 'todas'): ProductivityEntry[] {
  return entries.filter((e) => inRange(e.date, range) && (!type || type === 'todas' || e.type === type))
}

export interface ProdDay {
  date: string
  conf: number
  sep: number
  confQty: number
  sepQty: number
  total: number
}

export function productivityByDay(entries: ProductivityEntry[]): ProdDay[] {
  const map = new Map<string, ProdDay>()
  for (const e of entries) {
    const d = map.get(e.date) ?? { date: e.date, conf: 0, sep: 0, confQty: 0, sepQty: 0, total: 0 }
    const v = entryValue(e)
    if (e.type === 'conferencia') {
      d.conf = round2(d.conf + v)
      d.confQty += e.qty
    } else {
      d.sep = round2(d.sep + v)
      d.sepQty += e.qty
    }
    d.total = round2(d.total + v)
    map.set(e.date, d)
  }
  return [...map.values()].sort((a, b) => a.date.localeCompare(b.date))
}

export interface ProdSummary {
  confQty: number
  confValue: number
  sepQty: number
  sepValue: number
  totalQty: number
  totalValue: number
  activeDays: number
  avgPerDay: number
  bestDay: { date: string; value: number } | null
}

export function summarizeProductivity(entries: ProductivityEntry[]): ProdSummary {
  const days = productivityByDay(entries)
  const conf = entries.filter((e) => e.type === 'conferencia')
  const sep = entries.filter((e) => e.type === 'separacao')
  const confValue = sum(conf.map(entryValue))
  const sepValue = sum(sep.map(entryValue))
  const totalValue = round2(confValue + sepValue)
  let best: ProdSummary['bestDay'] = null
  for (const d of days) if (!best || d.total > best.value) best = { date: d.date, value: d.total }
  return {
    confQty: conf.reduce((a, e) => a + e.qty, 0),
    confValue,
    sepQty: sep.reduce((a, e) => a + e.qty, 0),
    sepValue,
    totalQty: entries.reduce((a, e) => a + e.qty, 0),
    totalValue,
    activeDays: days.length,
    avgPerDay: days.length ? round2(totalValue / days.length) : 0,
    bestDay: best,
  }
}

/** Variação percentual; null quando não há base de comparação. */
export function pctChange(current: number, previous: number): number | null {
  if (!previous) return null
  return round2(((current - previous) / previous) * 100)
}

/* ------------------------------------------------------------------ */
/* Salário                                                             */
/* ------------------------------------------------------------------ */

export function payFactor(s: Pick<Settings, 'prodPayMode' | 'prodPartialPct'>): number {
  if (s.prodPayMode === 'integral') return 1
  if (s.prodPayMode === 'parcial') return clamp(Number(s.prodPartialPct) || 0, 0, 100) / 100
  return 0
}

export type PayInput = Pick<AppData, 'settings' | 'productivity' | 'monthParams'>

export interface PayrollCalc {
  month: string
  period: Range
  baseSalary: number
  hourly: number
  nightHours: number
  nightAdditional: number
  attendance: number
  productionTotal: number
  productionEligible: number
  productionPending: number
  overtimeHours: number
  overtime: number
  otherAdditions: number
  gross: number
  vt: number
  inss: number
  inssConfigured: boolean
  advances: number
  otherDeductions: number
  totalDeductions: number
  net: number
  warnings: string[]
}

export function hourlyRate(s: Pick<Settings, 'baseSalary' | 'monthlyHours' | 'hourlyRateOverride'>): number {
  if (s.hourlyRateOverride > 0) return s.hourlyRateOverride
  return s.monthlyHours > 0 ? s.baseSalary / s.monthlyHours : 0
}

export function computePayroll(d: PayInput, month: string): PayrollCalc {
  const s = d.settings
  const mp = d.monthParams[month] ?? {}
  const period = payrollPeriod(month, s.payrollStartDay)
  const entries = filterProductivity(d.productivity, period)
  const productionTotal = sum(entries.map(entryValue))
  const productionEligible = round2(productionTotal * payFactor(s))
  const productionPending = round2(productionTotal - productionEligible)

  const hourly = hourlyRate(s)
  const workedDays = mp.workedDays ?? s.workedDays
  const nightHours = mp.nightHours ?? round2(s.nightHoursPerDay * workedDays)
  const nightEquivalent = s.nightReducedHour ? nightHours * (60 / 52.5) : nightHours
  const nightAdditional = round2(hourly * (s.nightPct / 100) * nightEquivalent)

  const attendance = s.attendanceEnabled ? round2(s.attendance) : 0
  const overtimeHours = s.overtimeEnabled ? mp.overtimeHours ?? s.overtimeHours : 0
  const overtime = s.overtimeEnabled ? round2(hourly * (1 + s.overtimePct / 100) * overtimeHours) : 0
  const otherAdditions = sum(s.otherAdditions.map((i) => i.amount))

  const gross = round2(s.baseSalary + nightAdditional + attendance + productionEligible + overtime + otherAdditions)

  const vt = s.vtMode === 'percentual' ? round2((s.baseSalary * s.vtPercent) / 100) : s.vtMode === 'valor' ? round2(s.vtFixed) : 0
  let inss = 0
  let inssConfigured = false
  if (s.inss.mode === 'valor') {
    inss = round2(s.inss.value)
    inssConfigured = true
  } else if (s.inss.mode === 'percentual') {
    inss = round2((gross * s.inss.value) / 100)
    inssConfigured = true
  }
  const advances = round2(mp.advances ?? s.advances)
  const otherDeductions = sum(s.otherDeductions.map((i) => i.amount))
  const totalDeductions = round2(vt + inss + advances + otherDeductions)
  const net = round2(gross - totalDeductions)

  const warnings: string[] = []
  if (s.nightPct > 0 && nightHours <= 0)
    warnings.push('Adicional noturno não calculado: informe as horas noturnas por dia e os dias trabalhados (Configurações) ou ajuste este mês.')
  if (!inssConfigured) warnings.push('INSS e outros descontos legais não configurados: confirme os valores reais no holerite.')
  if (productionPending > 0) warnings.push('Parte da produtividade está pendente de pagamento e não entra no total bruto deste mês.')

  return {
    month,
    period,
    baseSalary: round2(s.baseSalary),
    hourly,
    nightHours,
    nightAdditional,
    attendance,
    productionTotal,
    productionEligible,
    productionPending,
    overtimeHours,
    overtime,
    otherAdditions,
    gross,
    vt,
    inss,
    inssConfigured,
    advances,
    otherDeductions,
    totalDeductions,
    net,
    warnings,
  }
}

export interface EffectivePayroll {
  month: string
  gross: number
  deductions: number
  net: number
  confirmed: boolean
  record?: PayrollRecord
  estimate: PayrollCalc
}

/** Folha confirmada (recebida/ajustada) tem prioridade sobre a estimativa. */
export function effectivePayroll(d: PayInput & Pick<AppData, 'payrolls'>, month: string): EffectivePayroll {
  const estimate = computePayroll(d, month)
  const record = d.payrolls.find((p) => p.month === month)
  if (record && (record.status === 'recebido' || record.status === 'ajustado')) {
    return { month, gross: record.gross, deductions: record.deductions, net: record.net, confirmed: true, record, estimate }
  }
  return { month, gross: estimate.gross, deductions: estimate.totalDeductions, net: estimate.net, confirmed: false, record, estimate }
}

export function nextPayDate(s: Pick<Settings, 'payDay'>, today: string): string {
  const day = clamp(Math.floor(s.payDay) || 1, 1, 28)
  const [y, m] = today.split('-')
  const thisMonth = `${y}-${m}-${String(day).padStart(2, '0')}`
  return thisMonth >= today ? thisMonth : addMonths(thisMonth, 1)
}

/** Competência (YYYY-MM) paga na data informada. */
export function referenceMonthForPayDate(payDate: string, offset: 0 | 1): string {
  const m = payDate.slice(0, 7)
  return offset === 1 ? addMonths(`${m}-01`, -1).slice(0, 7) : m
}

/* ------------------------------------------------------------------ */
/* Despesas                                                            */
/* ------------------------------------------------------------------ */

export type ExpenseView = 'paga' | 'pendente' | 'atrasada'

export function expenseStatus(e: Expense, today: string): ExpenseView {
  if (e.status === 'paga') return 'paga'
  return e.dueDate < today ? 'atrasada' : 'pendente'
}

export const expensesInRange = (list: Expense[], r: Range) => list.filter((e) => inRange(e.dueDate, r))

export function totalsByCategory(list: Expense[]): { category: string; total: number }[] {
  const map = new Map<string, number>()
  for (const e of list) map.set(e.category, round2((map.get(e.category) ?? 0) + e.amount))
  return [...map.entries()].map(([category, total]) => ({ category, total })).sort((a, b) => b.total - a.total)
}

export const isFixedExpense = (e: Expense) => e.recurrence !== 'unica'

function occurrenceDates(start: string, rec: Expense['recurrence'], until: string): string[] {
  const out: string[] = []
  for (let i = 0; i < 1500; i++) {
    const dt = rec === 'semanal' ? addDays(start, 7 * i) : rec === 'mensal' ? addMonths(start, i) : addMonths(start, 12 * i)
    if (dt > until) break
    out.push(dt)
  }
  return out
}

/**
 * Retorna as ocorrências de despesas recorrentes que ainda não existem.
 * É idempotente: cada ocorrência tem chave `serie|data`; ocorrências excluídas
 * pelo usuário ficam registradas e não são recriadas.
 */
export function generateOccurrences(d: Pick<AppData, 'expenses' | 'deletedOccurrences' | 'seriesEnds'>, today: string, uidFn: () => string): Expense[] {
  const bySeries = new Map<string, Expense[]>()
  for (const e of d.expenses) {
    if (e.seriesId && e.recurrence !== 'unica') {
      const arr = bySeries.get(e.seriesId) ?? []
      arr.push(e)
      bySeries.set(e.seriesId, arr)
    }
  }
  const existing = new Set(d.expenses.map((e) => e.occurrenceKey).filter(Boolean) as string[])
  const deleted = new Set(d.deletedOccurrences)
  const created: Expense[] = []
  for (const [seriesId, items] of bySeries) {
    const sorted = [...items].sort((a, b) => a.dueDate.localeCompare(b.dueDate))
    const template = sorted[sorted.length - 1]
    const start = template.seriesStart ?? sorted[0].dueDate
    const horizon =
      template.recurrence === 'semanal' ? addDays(today, 84) : template.recurrence === 'mensal' ? addMonths(today, 12) : addMonths(today, 36)
    const end = d.seriesEnds[seriesId]
    const until = end && end < horizon ? end : horizon
    for (const date of occurrenceDates(start, template.recurrence, until)) {
      const key = `${seriesId}|${date}`
      if (existing.has(key) || deleted.has(key)) continue
      existing.add(key)
      created.push({
        ...template,
        id: uidFn(),
        dueDate: date,
        paidDate: '',
        status: 'pendente',
        occurrenceKey: key,
        seriesStart: start,
      })
    }
  }
  return created
}

/* ------------------------------------------------------------------ */
/* Dívidas                                                             */
/* ------------------------------------------------------------------ */

export type DebtView = 'quitada' | 'atrasada' | 'negociacao' | 'em_dia'

export interface DebtCalc {
  totalOwed: number
  paidBefore: number
  paidPayments: number
  paidTotal: number
  remaining: number
  pct: number
  paidInstallments: number
  remainingInstallments: number
  status: DebtView
  payoffDate: string | null
}

export function calcDebt(debt: Debt, payments: DebtPayment[], today: string): DebtCalc {
  const mine = payments.filter((p) => p.debtId === debt.id)
  const totalOwed = round2(debt.currentAmount > 0 ? debt.currentAmount : Math.max(0, debt.originalAmount - debt.downPayment))
  const paidBefore = round2((debt.paidInstallmentsInitial || 0) * (debt.installmentValue || 0))
  const paidPayments = sum(mine.map((p) => p.amount))
  const paidTotal = round2(paidBefore + paidPayments)
  const remaining = Math.max(0, round2(totalOwed - paidTotal))
  const quitada = totalOwed > 0 && remaining <= 0.004
  const pct = totalOwed > 0 ? clamp((paidTotal / totalOwed) * 100, 0, 100) : 0

  let paidInstallments = debt.paidInstallmentsInitial || 0
  if (debt.installmentValue > 0) {
    paidInstallments = Math.floor((paidTotal + 0.005) / debt.installmentValue)
    if (debt.totalInstallments > 0) paidInstallments = Math.min(debt.totalInstallments, paidInstallments)
  }
  let remainingInstallments = 0
  if (!quitada) {
    if (debt.totalInstallments > 0) remainingInstallments = Math.max(0, debt.totalInstallments - paidInstallments)
    else if (debt.installmentValue > 0) remainingInstallments = Math.ceil(remaining / debt.installmentValue - 1e-9)
  }

  let status: DebtView = 'em_dia'
  if (quitada) status = 'quitada'
  else if (debt.nextDue && debt.nextDue < today) status = 'atrasada'
  else if (debt.status === 'negociacao') status = 'negociacao'

  let payoffDate: string | null = null
  if (!quitada && debt.installmentValue > 0 && debt.nextDue && remaining > 0) {
    const n = Math.max(1, Math.ceil(remaining / debt.installmentValue - 1e-9))
    payoffDate = addMonths(debt.nextDue, n - 1)
  }
  return { totalOwed, paidBefore, paidPayments, paidTotal, remaining, pct, paidInstallments, remainingInstallments, status, payoffDate }
}

export interface PendingInstallment {
  k: number
  due: string
  amount: number
}

export function pendingInstallments(debt: Debt, c: DebtCalc): PendingInstallment[] {
  if (c.status === 'quitada' || !debt.nextDue || debt.installmentValue <= 0) return []
  const n = Math.min(600, c.remainingInstallments)
  const partial = Math.max(0, round2(c.paidTotal - c.paidInstallments * debt.installmentValue))
  const out: PendingInstallment[] = []
  let rest = c.remaining
  for (let i = 0; i < n && rest > 0.004; i++) {
    const amt = Math.min(debt.installmentValue - (i === 0 ? partial : 0), rest)
    out.push({ k: c.paidInstallments + i + 1, due: addMonths(debt.nextDue, i), amount: round2(amt) })
    rest = round2(rest - amt)
  }
  return out
}

/** Saída total com dívidas no período: pagamentos feitos + parcelas ainda em aberto que vencem no período. */
export function debtOutflow(d: Pick<AppData, 'debts' | 'debtPayments'>, r: Range, today: string): { paid: number; pending: number; total: number } {
  const paid = sum(d.debtPayments.filter((p) => inRange(p.date, r)).map((p) => p.amount))
  let pending = 0
  for (const debt of d.debts) {
    const c = calcDebt(debt, d.debtPayments, today)
    for (const p of pendingInstallments(debt, c)) if (inRange(p.due, r)) pending = round2(pending + p.amount)
  }
  return { paid, pending, total: round2(paid + pending) }
}

export interface SimulationInput {
  balance: number
  payment: number // pagamento mensal base
  extraMonthly: number
  lumpSum: number
  monthlyRate: number // % ao mês; 0 = sem juros
}

export interface SimulationResult {
  ok: boolean
  months: number
  totalPaid: number
  totalInterest: number
  balances: number[] // saldo ao fim de cada mês (índice 0 = mês 1)
}

export function simulatePayoff(inp: SimulationInput): SimulationResult {
  const rate = Math.max(0, inp.monthlyRate) / 100
  let bal = Math.max(0, round2(inp.balance - Math.max(0, inp.lumpSum)))
  const monthly = Math.max(0, inp.payment) + Math.max(0, inp.extraMonthly)
  let totalPaid = Math.min(inp.balance, Math.max(0, inp.lumpSum))
  let totalInterest = 0
  const balances: number[] = []
  if (bal <= 0.004) return { ok: true, months: 0, totalPaid: round2(totalPaid), totalInterest: 0, balances }
  if (monthly <= 0) return { ok: false, months: 0, totalPaid: round2(totalPaid), totalInterest: 0, balances }
  let months = 0
  while (bal > 0.004 && months < 600) {
    const interest = bal * rate
    if (monthly <= interest && months > 0 && rate > 0) return { ok: false, months, totalPaid: round2(totalPaid), totalInterest: round2(totalInterest), balances }
    bal += interest
    totalInterest += interest
    const pay = Math.min(bal, monthly)
    bal -= pay
    totalPaid += pay
    months++
    balances.push(round2(Math.max(0, bal)))
  }
  return { ok: bal <= 0.004, months, totalPaid: round2(totalPaid), totalInterest: round2(totalInterest), balances }
}

/* ------------------------------------------------------------------ */
/* Livro-caixa                                                         */
/* ------------------------------------------------------------------ */

/** Lançamentos "incorporados" já fazem parte do salário e não entram nos saldos. */
export const countsInBalance = (t: Transaction) => t.kind !== 'incorporada'

const signedAmount = (t: Transaction) => (t.type === 'entrada' ? t.amount : -t.amount)

export function realizedBalance(txs: Transaction[]): number {
  return sum(txs.filter((t) => countsInBalance(t) && t.status === 'efetivado').map(signedAmount))
}

export function plannedBalance(txs: Transaction[]): number {
  return sum(txs.filter(countsInBalance).map(signedAmount))
}

export interface LedgerTotals {
  inReal: number
  outReal: number
  inPlan: number
  outPlan: number
}

/** Totais de entradas/saídas, sem transferências nem lançamentos incorporados. */
export function ledgerTotals(txs: Transaction[]): LedgerTotals {
  const base = txs.filter((t) => t.kind === 'normal')
  const f = (type: Transaction['type'], status: Transaction['status']) =>
    sum(base.filter((t) => t.type === type && t.status === status).map((t) => t.amount))
  return {
    inReal: f('entrada', 'efetivado'),
    outReal: f('saida', 'efetivado'),
    inPlan: f('entrada', 'previsto'),
    outPlan: f('saida', 'previsto'),
  }
}

export function accountBalances(txs: Transaction[], accounts: string[]): { account: string; balance: number }[] {
  const names = new Set(accounts)
  for (const t of txs) names.add(t.account)
  return [...names].map((account) => ({
    account,
    balance: sum(txs.filter((t) => t.account === account && countsInBalance(t) && t.status === 'efetivado').map(signedAmount)),
  }))
}

/** Receitas extras: entradas que não são salário/produtividade/etc. e não são transferências. */
export function extraIncome(txs: Transaction[], r: Range, onlyRealized = false): number {
  return sum(
    txs
      .filter(
        (t) =>
          t.type === 'entrada' &&
          t.kind === 'normal' &&
          t.sourceType !== 'salary' &&
          !SALARY_FAMILY.includes(t.category) &&
          inRange(t.date, r) &&
          (!onlyRealized || t.status === 'efetivado'),
      )
      .map((t) => t.amount),
  )
}

/* ------------------------------------------------------------------ */
/* Resumos por período                                                 */
/* ------------------------------------------------------------------ */

export interface RangeSummary {
  range: Range
  months: string[]
  baseSalary: number
  salaryGross: number
  salaryNet: number
  salaryConfirmed: boolean
  production: number
  extras: number
  income: number
  expensesPlanned: number
  expensesPaid: number
  expensesPending: number
  debtPaid: number
  debtPending: number
  debtTotal: number
  outflow: number
  balance: number // previsto: receitas - despesas - dívidas
  committedPct: number // % do salário líquido comprometido
}

export function rangeSummary(d: AppData, r: Range, today: string): RangeSummary {
  const months = monthsBetween(r.from, r.to)
  const pays = months.map((m) => effectivePayroll(d, m))
  const salaryNet = sum(pays.map((p) => p.net))
  const salaryGross = sum(pays.map((p) => p.gross))
  const baseSalary = round2(d.settings.baseSalary * months.length)
  const production = sum(pays.map((p) => p.estimate.productionEligible))
  const extras = extraIncome(d.transactions, r)
  const exp = expensesInRange(d.expenses, r)
  const expensesPlanned = sum(exp.map((e) => e.amount))
  const expensesPaid = sum(exp.filter((e) => e.status === 'paga').map((e) => e.amount))
  const debt = debtOutflow(d, r, today)
  const income = round2(salaryNet + extras)
  const outflow = round2(expensesPlanned + debt.total)
  return {
    range: r,
    months,
    baseSalary,
    salaryGross,
    salaryNet,
    salaryConfirmed: pays.length > 0 && pays.every((p) => p.confirmed),
    production,
    extras,
    income,
    expensesPlanned,
    expensesPaid,
    expensesPending: round2(expensesPlanned - expensesPaid),
    debtPaid: debt.paid,
    debtPending: debt.pending,
    debtTotal: debt.total,
    outflow,
    balance: round2(income - outflow),
    committedPct: salaryNet > 0 ? round2((outflow / salaryNet) * 100) : outflow > 0 ? 100 : 0,
  }
}

export function monthSummary(d: AppData, month: string, today: string): RangeSummary {
  return rangeSummary(d, monthRange(month), today)
}

/** Série diária (até 62 dias) ou mensal de produtividade para gráficos. */
export function productivitySeries(entries: ProductivityEntry[], r: Range): { label: string; conf: number; sep: number; total: number }[] {
  const days = daysInRange(r.from, r.to)
  if (days.length <= 62) {
    const map = new Map(productivityByDay(entries).map((x) => [x.date, x]))
    return days.map((date) => {
      const x = map.get(date)
      return { label: date.slice(8) + '/' + date.slice(5, 7), conf: x?.conf ?? 0, sep: x?.sep ?? 0, total: x?.total ?? 0 }
    })
  }
  return monthsBetween(r.from, r.to).map((m) => {
    const list = entries.filter((e) => e.date.startsWith(m))
    const s = summarizeProductivity(list)
    return { label: m.slice(5) + '/' + m.slice(2, 4), conf: s.confValue, sep: s.sepValue, total: s.totalValue }
  })
}

/* ------------------------------------------------------------------ */
/* Alertas                                                             */
/* ------------------------------------------------------------------ */

export interface Alert {
  level: 'danger' | 'warn' | 'info'
  text: string
}

export function buildAlerts(d: AppData, month: string, today: string, fmt: (n: number) => string): Alert[] {
  const out: Alert[] = []
  const r = monthRange(month)
  const s = monthSummary(d, month, today)
  if (s.outflow > s.income && (s.outflow > 0 || s.income > 0))
    out.push({ level: 'danger', text: `Despesas e parcelas (${fmt(s.outflow)}) superam as receitas previstas (${fmt(s.income)}) em ${fmt(s.outflow - s.income)}.` })

  const soon = d.expenses.filter((e) => e.status === 'pendente' && e.dueDate >= today && e.dueDate <= addDays(today, 7))
  if (soon.length) out.push({ level: 'warn', text: `${soon.length} conta(s) vence(m) nos próximos 7 dias, somando ${fmt(sum(soon.map((e) => e.amount)))}.` })

  const late = d.expenses.filter((e) => e.status === 'pendente' && e.dueDate < today)
  if (late.length) out.push({ level: 'danger', text: `${late.length} despesa(s) em atraso, somando ${fmt(sum(late.map((e) => e.amount)))}.` })

  const lateDebts = d.debts.filter((x) => calcDebt(x, d.debtPayments, today).status === 'atrasada')
  if (lateDebts.length) out.push({ level: 'danger', text: `${lateDebts.length} dívida(s) com parcela atrasada: ${lateDebts.map((x) => x.name).join(', ')}.` })

  if (d.settings.monthlyGoal > 0 && s.balance < d.settings.monthlyGoal)
    out.push({ level: 'warn', text: `Meta de economia do mês (${fmt(d.settings.monthlyGoal)}) não atingida pelo saldo previsto (${fmt(s.balance)}).` })

  const cats = totalsByCategory(expensesInRange(d.expenses, r))
  for (const c of cats) {
    const b = d.settings.budgets[c.category]
    if (b && b > 0 && c.total > b) out.push({ level: 'warn', text: `Orçamento de ${c.category} ultrapassado: ${fmt(c.total)} de ${fmt(b)}.` })
  }
  return out
}
