import type { Range } from '../types'

export const pad = (n: number) => String(n).padStart(2, '0')

export function toISO(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}

/** Converte YYYY-MM-DD em Date local ao meio-dia (evita saltos por fuso/horário de verão). */
export function fromISO(s: string): Date {
  const [y, m, d] = s.split('-').map(Number)
  return new Date(y, (m || 1) - 1, d || 1, 12)
}

export const todayISO = () => toISO(new Date())

export const isISODate = (s: unknown): s is string =>
  typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(fromISO(s).getTime())

export function addDays(iso: string, n: number): string {
  const d = fromISO(iso)
  d.setDate(d.getDate() + n)
  return toISO(d)
}

/** Soma meses preservando o dia quando possível (31/01 + 1 mês = 28/02). */
export function addMonths(iso: string, n: number): string {
  const [y, m, d] = iso.split('-').map(Number)
  const target = new Date(y, m - 1 + n, 1, 12)
  const last = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate()
  target.setDate(Math.min(d, last))
  return toISO(target)
}

export const monthKey = (iso: string) => iso.slice(0, 7)

export function monthRange(month: string): Range {
  const [y, m] = month.split('-').map(Number)
  const last = new Date(y, m, 0).getDate()
  return { from: `${month}-01`, to: `${month}-${pad(last)}` }
}

export function addMonthKey(month: string, n: number): string {
  return monthKey(addMonths(`${month}-01`, n))
}

export function monthsBetween(from: string, to: string): string[] {
  const out: string[] = []
  let cur = monthKey(from)
  const end = monthKey(to)
  let guard = 0
  while (cur <= end && guard++ < 1200) {
    out.push(cur)
    cur = addMonthKey(cur, 1)
  }
  return out
}

export function monthLabel(month: string): string {
  const d = fromISO(`${month}-01`)
  return d.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })
}

export function shortMonth(month: string): string {
  const d = fromISO(`${month}-01`)
  const s = d.toLocaleDateString('pt-BR', { month: 'short' }).replace('.', '')
  return `${s}/${String(d.getFullYear()).slice(2)}`
}

export const inRange = (iso: string, r: Range) => !!iso && iso >= r.from && iso <= r.to

export function daysBetween(a: string, b: string): number {
  return Math.round((fromISO(b).getTime() - fromISO(a).getTime()) / 86400000)
}

export function daysInRange(from: string, to: string): string[] {
  const out: string[] = []
  let cur = from
  let guard = 0
  while (cur <= to && guard++ < 4000) {
    out.push(cur)
    cur = addDays(cur, 1)
  }
  return out
}

/** Segunda-feira da semana de `iso`. */
export function startOfWeek(iso: string): string {
  const d = fromISO(iso)
  const dow = (d.getDay() + 6) % 7
  return addDays(iso, -dow)
}

export function weekdayShort(iso: string): string {
  return fromISO(iso).toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', '')
}

/**
 * Período da folha para uma competência.
 * startDay 1 = mês-calendário. Ex.: startDay 21 e mês 2026-10 => 21/09 a 20/10.
 */
export function payrollPeriod(month: string, startDay: number): Range {
  const sd = Math.min(28, Math.max(1, Math.floor(startDay) || 1))
  if (sd === 1) return monthRange(month)
  const start = addMonths(`${month}-${pad(sd)}`, -1)
  const end = addDays(`${month}-${pad(sd)}`, -1)
  return { from: start, to: end }
}
