import type { AppData, Settings } from '../types'

export const EXPENSE_CATEGORIES = [
  'Moradia',
  'Alimentação',
  'Transporte',
  'Água, luz e internet',
  'Telefone',
  'Saúde',
  'Lazer',
  'Compras',
  'Assinaturas',
  'Família',
  'Outros',
]

export const INCOME_CATEGORIES = [
  'Salário',
  'Produtividade',
  'Assiduidade',
  'Outros adicionais',
  'Renda extra',
  'Despesas pessoais',
  'Pagamento de dívidas',
  'Transferências',
]

/** Categorias cujo valor já faz parte do cálculo do salário. */
export const SALARY_FAMILY = ['Salário', 'Produtividade', 'Assiduidade', 'Outros adicionais']

export const PAYMENT_METHODS = ['Pix', 'Dinheiro', 'Cartão de débito', 'Cartão de crédito', 'Boleto', 'Transferência', 'Débito automático', 'Outro']

export const DEBT_CATEGORIES = ['Cartão de crédito', 'Empréstimo', 'Financiamento', 'Crediário', 'Acordo', 'Família/amigos', 'Outros']

export const defaultSettings: Settings = {
  displayName: '',
  baseSalary: 2120,
  nightPct: 20,
  attendanceEnabled: true,
  attendance: 200,
  rateConferencia: 5,
  rateSeparacao: 5,
  prodPayMode: 'integral',
  prodPartialPct: 50,
  monthlyHours: 220,
  hourlyRateOverride: 0,
  nightHoursPerDay: 0,
  workedDays: 0,
  nightReducedHour: false,
  payrollStartDay: 1,
  payDay: 5,
  payMonthOffset: 1,
  overtimeEnabled: false,
  overtimeHours: 0,
  overtimePct: 50,
  otherAdditions: [],
  vtMode: 'percentual',
  vtPercent: 6,
  vtFixed: 0,
  inss: { mode: 'nenhum', value: 0, competence: '' },
  advances: 0,
  otherDeductions: [],
  monthlyGoal: 0,
  expenseCategories: EXPENSE_CATEGORIES,
  incomeCategories: INCOME_CATEGORIES,
  accounts: ['Conta principal', 'Carteira'],
  budgets: {},
  currency: 'BRL',
  dateFormat: 'br',
  accent: 'grafite',
  textSize: 'normal',
}

export function createInitialData(): AppData {
  return {
    version: 1,
    settings: JSON.parse(JSON.stringify(defaultSettings)),
    productivity: [],
    payrolls: [],
    monthParams: {},
    expenses: [],
    deletedOccurrences: [],
    seriesEnds: {},
    debts: [],
    debtPayments: [],
    transactions: [],
    goals: [],
    updatedAt: new Date().toISOString(),
  }
}
