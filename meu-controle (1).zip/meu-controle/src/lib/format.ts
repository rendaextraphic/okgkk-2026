export const round2 = (n: number): number => {
  if (!Number.isFinite(n)) return 0
  const r = Math.round((n + Math.sign(n) * Number.EPSILON) * 100) / 100
  return r === 0 ? 0 : r
}

let cfg: { currency: string; dateFormat: 'br' | 'iso' } = { currency: 'BRL', dateFormat: 'br' }

export function setFormatConfig(c: Partial<typeof cfg>) {
  cfg = { ...cfg, ...c }
}

export function brl(v: number): string {
  const n = round2(Number.isFinite(v) ? v : 0)
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: cfg.currency }).format(n)
}

/** Versão sem espaços especiais, segura para PDFs e CSVs. */
export function brlPlain(v: number): string {
  return brl(v).replace(/[  ]/g, ' ')
}

export function num(v: number, digits = 0): string {
  return new Intl.NumberFormat('pt-BR', {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  }).format(Number.isFinite(v) ? v : 0)
}

export const pct = (v: number, digits = 0) => `${num(v, digits)}%`

/** Aceita "1.234,56", "1234,56", "1234.56", "R$ 10" e números. Retorna NaN se inválido. */
export function parseNumber(input: string | number | null | undefined): number {
  if (typeof input === 'number') return Number.isFinite(input) ? input : NaN
  if (input == null) return NaN
  let s = String(input).trim().replace(/R\$|\s/g, '')
  if (s === '' || s === '-' || s === ',') return NaN
  if (s.includes(',')) {
    s = s.replace(/\./g, '').replace(',', '.')
  } else if (/^-?\d{1,3}(\.\d{3})+$/.test(s)) {
    s = s.replace(/\./g, '')
  }
  if (!/^-?\d*\.?\d+$/.test(s)) return NaN
  const n = Number(s)
  return Number.isFinite(n) ? n : NaN
}

export function formatDate(iso?: string): string {
  if (!iso) return '—'
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso)
  if (!m) return iso
  return cfg.dateFormat === 'iso' ? iso : `${m[3]}/${m[2]}/${m[1]}`
}

/** Sempre DD/MM/AAAA (usado nos relatórios em PDF). */
export function formatDateBR(iso?: string): string {
  if (!iso) return '—'
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso)
  return m ? `${m[3]}/${m[2]}/${m[1]}` : iso
}

export function signed(v: number): string {
  return `${v > 0 ? '+' : ''}${brl(v)}`
}

export function uid(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID()
  return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`
}
