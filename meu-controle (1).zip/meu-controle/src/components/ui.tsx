import { useEffect, useRef, type ButtonHTMLAttributes, type ReactNode, type InputHTMLAttributes, type SelectHTMLAttributes, type TextareaHTMLAttributes } from 'react'
import { AlertTriangle, CheckCircle2, Info, Inbox, X } from 'lucide-react'
import { useApp } from '../store/store'

export const cx = (...a: (string | false | null | undefined)[]) => a.filter(Boolean).join(' ')

/* Cartões ---------------------------------------------------------- */

export function Card({
  title,
  subtitle,
  action,
  children,
  className,
  pad = true,
}: {
  title?: ReactNode
  subtitle?: ReactNode
  action?: ReactNode
  children?: ReactNode
  className?: string
  pad?: boolean
}) {
  return (
    <section className={cx('card animate-fade', className)}>
      {(title || action) && (
        <header className="flex flex-wrap items-start justify-between gap-2 px-5 pt-4">
          <div>
            {title && <h2 className="text-sm font-semibold text-gray-900">{title}</h2>}
            {subtitle && <p className="mt-0.5 text-xs text-gray-500">{subtitle}</p>}
          </div>
          {action}
        </header>
      )}
      <div className={pad ? 'p-5' : ''}>{children}</div>
    </section>
  )
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight text-gray-900">{title}</h1>
        {subtitle && <p className="mt-1 max-w-2xl text-sm text-gray-500">{subtitle}</p>}
      </div>
      {actions && <div className="no-print flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  )
}

type Tone = 'neutral' | 'income' | 'expense' | 'warn' | 'info'

const toneText: Record<Tone, string> = {
  neutral: 'text-gray-900',
  income: 'text-income',
  expense: 'text-expense',
  warn: 'text-amber-700',
  info: 'text-sky-700',
}

export function Stat({
  label,
  value,
  tone = 'neutral',
  icon,
  hint,
}: {
  label: string
  value: ReactNode
  tone?: Tone
  icon?: ReactNode
  hint?: ReactNode
}) {
  return (
    <div className="card animate-fade p-4">
      <div className="flex items-center justify-between gap-2">
        <p className="text-xs font-medium text-gray-500">{label}</p>
        {icon && <span className="text-gray-400">{icon}</span>}
      </div>
      <p className={cx('num mt-2 text-xl font-semibold tracking-tight sm:text-2xl', toneText[tone])}>{value}</p>
      {hint && <p className="mt-1 text-xs text-gray-500">{hint}</p>}
    </div>
  )
}

const badgeTone: Record<Tone, string> = {
  neutral: 'bg-gray-100 text-gray-700',
  income: 'bg-emerald-50 text-emerald-800',
  expense: 'bg-red-50 text-red-800',
  warn: 'bg-amber-50 text-amber-800',
  info: 'bg-sky-50 text-sky-800',
}

export function Badge({ tone = 'neutral', children }: { tone?: Tone; children: ReactNode }) {
  return <span className={cx('badge', badgeTone[tone])}>{children}</span>
}

export function ProgressBar({ value, tone = 'income', label }: { value: number; tone?: 'income' | 'expense' | 'neutral' | 'warn'; label?: string }) {
  const v = Math.max(0, Math.min(100, Number.isFinite(value) ? value : 0))
  const color = { income: 'bg-income', expense: 'bg-expense', neutral: 'bg-gray-800', warn: 'bg-amber-500' }[tone]
  return (
    <div
      role="progressbar"
      aria-valuenow={Math.round(v)}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={label}
      className="h-2 w-full overflow-hidden rounded-full bg-gray-100"
    >
      <div className={cx('h-full rounded-full transition-all duration-500', color)} style={{ width: `${v}%` }} />
    </div>
  )
}

export function EmptyState({ title, text, action, icon }: { title: string; text?: ReactNode; action?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-gray-200 bg-white/60 px-6 py-10 text-center">
      <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-full bg-gray-100 text-gray-500">{icon ?? <Inbox size={20} />}</div>
      <p className="text-sm font-semibold text-gray-800">{title}</p>
      {text && <p className="mt-1 max-w-sm text-sm text-gray-500">{text}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}

export function Notice({ tone = 'info', children, className }: { tone?: 'info' | 'warn' | 'danger' | 'ok'; children: ReactNode; className?: string }) {
  const styles = {
    info: 'border-sky-200 bg-sky-50 text-sky-900',
    warn: 'border-amber-200 bg-amber-50 text-amber-900',
    danger: 'border-red-200 bg-red-50 text-red-900',
    ok: 'border-emerald-200 bg-emerald-50 text-emerald-900',
  }[tone]
  const Icon = tone === 'ok' ? CheckCircle2 : tone === 'info' ? Info : AlertTriangle
  return (
    <div role={tone === 'danger' ? 'alert' : undefined} className={cx('flex items-start gap-2.5 rounded-xl border px-3.5 py-2.5 text-sm', styles, className)}>
      <Icon size={16} className="mt-0.5 shrink-0" aria-hidden />
      <div className="min-w-0 flex-1">{children}</div>
    </div>
  )
}

/* Botões e campos -------------------------------------------------- */

export function Button({
  variant = 'primary',
  size = 'md',
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'danger' | 'ghost'; size?: 'md' | 'sm' }) {
  return (
    <button
      type="button"
      {...props}
      className={cx(`btn-${variant}`, size === 'sm' && 'btn-sm', className)}
    />
  )
}

export function Field({
  label,
  error,
  hint,
  children,
  className,
}: {
  label: string
  error?: string | null
  hint?: ReactNode
  children: ReactNode
  className?: string
}) {
  return (
    <label className={cx('block', className)}>
      <span className="label">{label}</span>
      {children}
      {hint && !error && <span className="mt-1 block text-xs text-gray-500">{hint}</span>}
      {error && (
        <span role="alert" className="mt-1 block text-xs font-medium text-expense">
          {error}
        </span>
      )}
    </label>
  )
}

export function Input({ invalid, className, ...p }: InputHTMLAttributes<HTMLInputElement> & { invalid?: boolean }) {
  return <input {...p} aria-invalid={invalid || undefined} className={cx('input', invalid && 'input-error', className)} />
}

export function Select({ invalid, className, children, ...p }: SelectHTMLAttributes<HTMLSelectElement> & { invalid?: boolean }) {
  return (
    <select {...p} aria-invalid={invalid || undefined} className={cx('input pr-8', invalid && 'input-error', className)}>
      {children}
    </select>
  )
}

export function Textarea({ className, ...p }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea rows={3} {...p} className={cx('input resize-y', className)} />
}

export function Segmented<T extends string>({
  value,
  onChange,
  options,
  label,
}: {
  value: T
  onChange: (v: T) => void
  options: { value: T; label: string }[]
  label?: string
}) {
  return (
    <div role="group" aria-label={label} className="inline-flex rounded-xl bg-gray-100 p-0.5">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          aria-pressed={o.value === value}
          onClick={() => onChange(o.value)}
          className={cx(
            'rounded-[10px] px-3 py-1.5 text-xs font-medium transition',
            o.value === value ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-800',
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  )
}

/* Modal ------------------------------------------------------------ */

export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  wide,
}: {
  open: boolean
  onClose: () => void
  title: string
  children: ReactNode
  footer?: ReactNode
  wide?: boolean
}) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!open) return
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', onKey)
    // Foca o primeiro campo, mas nunca rouba o foco de quem já começou a digitar no diálogo.
    const t = setTimeout(() => {
      const root = ref.current
      if (!root || root.contains(document.activeElement)) return
      root.querySelector<HTMLElement>('input:not([type=hidden]), select, textarea')?.focus()
    }, 30)
    return () => {
      document.body.style.overflow = prev
      document.removeEventListener('keydown', onKey)
      clearTimeout(t)
    }
  }, [open, onClose])
  if (!open) return null
  return (
    <div className="no-print fixed inset-0 z-50 flex items-end justify-center bg-gray-900/40 p-0 sm:items-center sm:p-4" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={cx('flex max-h-[92vh] w-full animate-fade flex-col rounded-t-2xl bg-white shadow-pop sm:rounded-2xl', wide ? 'sm:max-w-2xl' : 'sm:max-w-lg')}
      >
        <header className="flex items-center justify-between border-b border-gray-100 px-5 py-3.5">
          <h2 className="text-base font-semibold text-gray-900">{title}</h2>
          <button type="button" onClick={onClose} aria-label="Fechar" className="rounded-lg p-1.5 text-gray-500 hover:bg-gray-100">
            <X size={18} />
          </button>
        </header>
        <div className="overflow-y-auto px-5 py-4">{children}</div>
        {footer && <footer className="flex flex-wrap justify-end gap-2 border-t border-gray-100 px-5 py-3.5">{footer}</footer>}
      </div>
    </div>
  )
}

export function ConfirmDialog({
  open,
  title,
  text,
  confirmLabel = 'Confirmar',
  danger,
  onConfirm,
  onClose,
  children,
}: {
  open: boolean
  title: string
  text?: ReactNode
  confirmLabel?: string
  danger?: boolean
  onConfirm: () => void
  onClose: () => void
  children?: ReactNode
}) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            variant={danger ? 'danger' : 'primary'}
            onClick={() => {
              onConfirm()
              onClose()
            }}
          >
            {confirmLabel}
          </Button>
        </>
      }
    >
      {text && <p className="text-sm text-gray-600">{text}</p>}
      {children}
    </Modal>
  )
}

/* Toasts ----------------------------------------------------------- */

export function ToastHost() {
  const { toasts, dismissToast } = useApp()
  return (
    <div aria-live="polite" className="no-print pointer-events-none fixed inset-x-0 bottom-20 z-[60] flex flex-col items-center gap-2 px-4 lg:bottom-6">
      {toasts.map((t) => (
        <div
          key={t.id}
          role={t.type === 'error' ? 'alert' : 'status'}
          className={cx(
            'pointer-events-auto flex max-w-md animate-fade items-start gap-2.5 rounded-xl px-4 py-2.5 text-sm text-white shadow-pop',
            t.type === 'error' ? 'bg-expense' : t.type === 'info' ? 'bg-gray-800' : 'bg-gray-900',
          )}
        >
          {t.type === 'success' ? <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-emerald-300" /> : t.type === 'error' ? <AlertTriangle size={16} className="mt-0.5 shrink-0" /> : <Info size={16} className="mt-0.5 shrink-0" />}
          <span>{t.text}</span>
          <button type="button" aria-label="Dispensar" onClick={() => dismissToast(t.id)} className="ml-1 opacity-70 hover:opacity-100">
            <X size={14} />
          </button>
        </div>
      ))}
    </div>
  )
}

/* Tabelas ---------------------------------------------------------- */

export function Table({ head, children, empty }: { head: (string | { label: string; className?: string })[]; children: ReactNode; empty?: ReactNode }) {
  return (
    <div className="table-wrap">
      <table className="w-full min-w-[34rem] border-collapse">
        <thead>
          <tr className="border-b border-gray-100">
            {head.map((h, i) => {
              const o = typeof h === 'string' ? { label: h } : h
              return (
                <th key={i} scope="col" className={cx('th', (o as { className?: string }).className)}>
                  {o.label}
                </th>
              )
            })}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-50">{children}</tbody>
      </table>
      {empty}
    </div>
  )
}

export function Tabs<T extends string>({ value, onChange, tabs }: { value: T; onChange: (v: T) => void; tabs: { value: T; label: string }[] }) {
  return (
    <div role="tablist" className="no-print mb-4 flex gap-1 overflow-x-auto border-b border-gray-200">
      {tabs.map((t) => (
        <button
          key={t.value}
          role="tab"
          type="button"
          aria-selected={t.value === value}
          onClick={() => onChange(t.value)}
          className={cx(
            '-mb-px whitespace-nowrap border-b-2 px-3.5 py-2 text-sm font-medium transition',
            t.value === value ? 'border-accent text-gray-900' : 'border-transparent text-gray-500 hover:text-gray-800',
          )}
        >
          {t.label}
        </button>
      ))}
    </div>
  )
}
