import { useState, type ReactNode } from 'react'
import {
  BookOpen,
  CalendarCheck,
  FileText,
  Landmark,
  LayoutDashboard,
  LogOut,
  Menu,
  PackageCheck,
  Receipt,
  Settings as SettingsIcon,
  ShieldAlert,
  Wallet,
  X,
} from 'lucide-react'
import { useApp } from '../store/store'
import { useAuth } from '../auth/context'
import { cx, Notice, ToastHost } from './ui'

export type Route = 'inicio' | 'produtividade' | 'salario' | 'despesas' | 'dividas' | 'caixa' | 'planejamento' | 'relatorios' | 'configuracoes'

export const NAV: { route: Route; label: string; icon: typeof Wallet }[] = [
  { route: 'inicio', label: 'Início', icon: LayoutDashboard },
  { route: 'produtividade', label: 'Produtividade', icon: PackageCheck },
  { route: 'salario', label: 'Salário', icon: Wallet },
  { route: 'despesas', label: 'Despesas', icon: Receipt },
  { route: 'dividas', label: 'Dívidas', icon: Landmark },
  { route: 'caixa', label: 'Livro-caixa', icon: BookOpen },
  { route: 'planejamento', label: 'Planejamento', icon: CalendarCheck },
  { route: 'relatorios', label: 'Relatórios', icon: FileText },
  { route: 'configuracoes', label: 'Configurações', icon: SettingsIcon },
]

const MOBILE_MAIN: Route[] = ['inicio', 'produtividade', 'despesas', 'dividas']

function Brand() {
  return (
    <div className="flex items-center gap-2.5">
      <div className="flex h-8 w-8 items-center justify-center rounded-[10px] bg-accent text-white">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
          <path d="M5 18V8l7 5 7-5v10" />
        </svg>
      </div>
      <span className="text-base font-semibold tracking-tight text-gray-900">Meu Controle</span>
    </div>
  )
}

function NavLinks({ route, go, onPick }: { route: Route; go: (r: Route) => void; onPick?: () => void }) {
  return (
    <nav aria-label="Principal" className="space-y-0.5">
      {NAV.map(({ route: r, label, icon: Icon }) => (
        <button
          key={r}
          type="button"
          aria-current={route === r ? 'page' : undefined}
          onClick={() => {
            go(r)
            onPick?.()
          }}
          className={cx(
            'flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition',
            route === r ? 'bg-accent/10 text-gray-900' : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900',
          )}
        >
          <Icon size={18} className={route === r ? 'text-accent' : 'text-gray-400'} aria-hidden />
          {label}
        </button>
      ))}
    </nav>
  )
}

export function Layout({ route, go, children }: { route: Route; go: (r: Route) => void; children: ReactNode }) {
  const [open, setOpen] = useState(false)
  const { storageError } = useApp()
  const { name, logout } = useAuth()

  return (
    <div className="min-h-screen lg:flex">
      {/* Barra lateral (desktop) */}
      <aside className="no-print sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-gray-200/80 bg-white px-4 py-5 lg:flex">
        <div className="mb-6 px-1">
          <Brand />
        </div>
        <div className="flex-1 overflow-y-auto">
          <NavLinks route={route} go={go} />
        </div>
        <button
          type="button"
          onClick={() => go('configuracoes')}
          className="mt-4 flex items-start gap-2 rounded-xl bg-gray-50 p-3 text-left text-xs leading-relaxed text-gray-500 hover:bg-gray-100"
        >
          <ShieldAlert size={14} className="mt-0.5 shrink-0" aria-hidden />
          Seus dados ficam apenas neste navegador, criptografados com a sua senha. Faça backups regulares em Configurações.
        </button>
        <div className="mt-3 flex items-center justify-between gap-2 border-t border-gray-100 pt-3">
          <span className="min-w-0 truncate text-sm font-medium text-gray-700" title={name}>
            {name}
          </span>
          <button
            type="button"
            onClick={logout}
            className="flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-sm font-medium text-gray-600 hover:bg-gray-100 hover:text-gray-900"
          >
            <LogOut size={15} aria-hidden /> Sair
          </button>
        </div>
      </aside>

      {/* Topo (mobile) */}
      <header className="no-print sticky top-0 z-30 flex items-center justify-between border-b border-gray-200/80 bg-white/90 px-4 py-3 backdrop-blur lg:hidden">
        <Brand />
        <button type="button" aria-label="Abrir menu" onClick={() => setOpen(true)} className="rounded-lg p-2 text-gray-600 hover:bg-gray-100">
          <Menu size={20} />
        </button>
      </header>

      {/* Gaveta (mobile) */}
      {open && (
        <div className="no-print fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Menu">
          <div className="absolute inset-0 bg-gray-900/40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-0 flex h-full w-72 max-w-[85vw] animate-fade flex-col bg-white p-4 shadow-pop">
            <div className="mb-4 flex items-center justify-between">
              <Brand />
              <button type="button" aria-label="Fechar menu" onClick={() => setOpen(false)} className="rounded-lg p-2 text-gray-600 hover:bg-gray-100">
                <X size={18} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              <NavLinks route={route} go={go} onPick={() => setOpen(false)} />
            </div>
            <div className="mt-3 flex items-center justify-between gap-2 border-t border-gray-100 pt-3">
              <span className="min-w-0 truncate text-sm font-medium text-gray-700">{name}</span>
              <button
                type="button"
                onClick={logout}
                className="flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-sm font-medium text-gray-600 hover:bg-gray-100 hover:text-gray-900"
              >
                <LogOut size={15} aria-hidden /> Sair
              </button>
            </div>
          </div>
        </div>
      )}

      <main className="print-full min-w-0 flex-1 px-4 pb-28 pt-5 sm:px-6 lg:px-10 lg:pb-12 lg:pt-8">
        <div className="mx-auto max-w-6xl print-full">
          {storageError && (
            <Notice tone="danger" className="no-print mb-4">
              {storageError}
            </Notice>
          )}
          {children}
        </div>
      </main>

      {/* Navegação inferior (mobile) */}
      <nav aria-label="Atalhos" className="no-print fixed inset-x-0 bottom-0 z-40 grid grid-cols-5 border-t border-gray-200 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden">
        {MOBILE_MAIN.map((r) => {
          const item = NAV.find((n) => n.route === r)!
          const Icon = item.icon
          return (
            <button
              key={r}
              type="button"
              aria-current={route === r ? 'page' : undefined}
              onClick={() => go(r)}
              className={cx('flex flex-col items-center gap-0.5 py-2 text-[11px] font-medium', route === r ? 'text-accent' : 'text-gray-500')}
            >
              <Icon size={19} aria-hidden />
              {item.label}
            </button>
          )
        })}
        <button type="button" onClick={() => setOpen(true)} className="flex flex-col items-center gap-0.5 py-2 text-[11px] font-medium text-gray-500">
          <Menu size={19} aria-hidden />
          Mais
        </button>
      </nav>
      <ToastHost />
    </div>
  )
}
