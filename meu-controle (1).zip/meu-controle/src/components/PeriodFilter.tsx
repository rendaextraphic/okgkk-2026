import { ChevronLeft, ChevronRight } from 'lucide-react'
import type { Period } from '../store/store'
import { addMonthKey, monthLabel } from '../lib/dates'
import { Button, Input, Segmented } from './ui'

export function PeriodFilter({ value, onChange }: { value: Period; onChange: (p: Period) => void }) {
  return (
    <div className="no-print flex flex-wrap items-center gap-2">
      <Segmented
        label="Tipo de período"
        value={value.mode}
        onChange={(mode) => onChange({ ...value, mode })}
        options={[
          { value: 'mes', label: 'Mês' },
          { value: 'ano', label: 'Ano' },
          { value: 'personalizado', label: 'Personalizado' },
        ]}
      />
      {value.mode === 'mes' && (
        <div className="flex items-center gap-1">
          <Button variant="secondary" size="sm" aria-label="Mês anterior" onClick={() => onChange({ ...value, month: addMonthKey(value.month, -1) })}>
            <ChevronLeft size={15} />
          </Button>
          <Input
            type="month"
            aria-label={`Mês: ${monthLabel(value.month)}`}
            value={value.month}
            onChange={(e) => e.target.value && onChange({ ...value, month: e.target.value })}
            className="w-40 py-1.5"
          />
          <Button variant="secondary" size="sm" aria-label="Próximo mês" onClick={() => onChange({ ...value, month: addMonthKey(value.month, 1) })}>
            <ChevronRight size={15} />
          </Button>
        </div>
      )}
      {value.mode === 'ano' && (
        <div className="flex items-center gap-1">
          <Button variant="secondary" size="sm" aria-label="Ano anterior" onClick={() => onChange({ ...value, year: value.year - 1 })}>
            <ChevronLeft size={15} />
          </Button>
          <Input
            type="number"
            aria-label="Ano"
            min={2000}
            max={2100}
            value={value.year}
            onChange={(e) => {
              const y = Number(e.target.value)
              if (y >= 2000 && y <= 2100) onChange({ ...value, year: y })
            }}
            className="w-24 py-1.5"
          />
          <Button variant="secondary" size="sm" aria-label="Próximo ano" onClick={() => onChange({ ...value, year: value.year + 1 })}>
            <ChevronRight size={15} />
          </Button>
        </div>
      )}
      {value.mode === 'personalizado' && (
        <div className="flex flex-wrap items-center gap-2">
          <Input type="date" aria-label="Data inicial" value={value.from} onChange={(e) => e.target.value && onChange({ ...value, from: e.target.value })} className="w-40 py-1.5" />
          <span className="text-xs text-gray-500">até</span>
          <Input type="date" aria-label="Data final" value={value.to} onChange={(e) => e.target.value && onChange({ ...value, to: e.target.value })} className="w-40 py-1.5" />
        </div>
      )}
    </div>
  )
}
