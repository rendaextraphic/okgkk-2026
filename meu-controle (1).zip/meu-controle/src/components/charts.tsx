import { type ReactNode } from 'react'
import { brl } from '../lib/format'

export const COLORS = {
  income: '#2f7d4f',
  expense: '#b4412f',
  ink: '#111827',
  muted: '#9ca3af',
  grid: '#eef0f2',
  conf: '#1f2937',
  sep: '#9ca3af',
}

export const PIE_COLORS = ['#1f2937', '#2f7d4f', '#b4412f', '#6b7280', '#c8a24a', '#4b7ba7', '#9ca3af', '#7c5a8a', '#3f6f6a', '#a3a86b', '#d1d5db']

export function ChartBox({ children, height = 260, empty }: { children: ReactNode; height?: number; empty?: string }) {
  if (empty) {
    return (
      <div style={{ height }} className="flex items-center justify-center rounded-xl bg-gray-50 px-4 text-center text-sm text-gray-500">
        {empty}
      </div>
    )
  }
  return <div style={{ height }}>{children}</div>
}

interface TipProps {
  active?: boolean
  payload?: { name?: string; value?: number; color?: string; dataKey?: string; payload?: Record<string, unknown> }[]
  label?: string
  money?: boolean
}

export function MoneyTooltip({ active, payload, label, money = true }: TipProps) {
  if (!active || !payload?.length) return null
  return (
    <div className="rounded-xl border border-gray-200 bg-white px-3 py-2 text-xs shadow-pop">
      {label !== undefined && <p className="mb-1 font-medium text-gray-800">{label}</p>}
      {payload.map((p, i) => (
        <p key={i} className="flex items-center gap-2 text-gray-600">
          <span className="inline-block h-2 w-2 rounded-full" style={{ background: p.color }} />
          <span>{p.name}</span>
          <span className="num ml-auto pl-3 font-medium text-gray-900">{money ? brl(Number(p.value)) : p.value}</span>
        </p>
      ))}
    </div>
  )
}

export const axisMoney = (v: number) => {
  const a = Math.abs(v)
  if (a >= 1000) return `${(v / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} mil`
  return String(Math.round(v))
}
