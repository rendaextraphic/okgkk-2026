import { describe, expect, it } from 'vitest'
import { mkdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import type { AppData } from '../types'
import { createInitialData } from '../lib/defaults'
import { addDays } from '../lib/dates'
import { buildReport, resolveRange, type ReportKind } from './build'

const OUT = process.env.REPORT_OUT_DIR

function bigData(): AppData {
  const d = createInitialData()
  d.settings.displayName = 'Maria da Silva'
  d.settings.nightHoursPerDay = 7
  d.settings.workedDays = 22
  d.settings.monthlyGoal = 300
  d.settings.budgets = { Alimentação: 500, Lazer: 100 }
  let n = 0
  const id = () => `id${++n}`
  // 8 meses de produtividade, quase todos os dias, 2 a 3 lançamentos por dia
  for (let i = 0; i < 240; i++) {
    const date = addDays('2026-02-01', i)
    d.productivity.push({ id: id(), date, type: 'conferencia', qty: 20 + (i % 17), unitValue: 5, notes: i % 9 === 0 ? 'Turno da noite com observação mais longa para testar quebra de linha na tabela' : undefined })
    d.productivity.push({ id: id(), date, type: 'separacao', qty: 10 + (i % 23), unitValue: 5 })
  }
  const cats = d.settings.expenseCategories
  for (let i = 0; i < 160; i++) {
    const due = addDays('2026-02-03', i * 2)
    const paid = due < '2026-10-01'
    d.expenses.push({
      id: id(), name: `Despesa número ${i + 1} com nome razoavelmente comprido`, category: cats[i % cats.length], amount: 35 + (i * 13) % 400, dueDate: due,
      paidDate: paid ? due : '', method: paid ? 'Pix' : '', recurrence: 'unica', status: paid ? 'paga' : 'pendente', notes: '',
    })
  }
  for (let k = 0; k < 4; k++) {
    d.debts.push({
      id: `debt${k}`, name: `Dívida ${k + 1}`, creditor: `Credor ${k + 1}`, category: 'Empréstimo', originalAmount: 3000 + k * 1000, currentAmount: 0, downPayment: 0,
      totalInstallments: 24, installmentValue: 150 + k * 40, paidInstallmentsInitial: 2, interestRate: 0, contractDate: '2026-01-10', nextDue: `2026-1${k % 3}-10`.replace('2026-12', '2026-12'), status: 'ativa', priority: 'media', notes: '',
    })
    for (let p = 0; p < 5; p++) d.debtPayments.push({ id: id(), debtId: `debt${k}`, date: addDays('2026-03-10', p * 30 + k), amount: 150 + k * 40, notes: '' })
  }
  for (let i = 0; i < 180; i++) {
    d.transactions.push({
      id: id(), type: i % 3 === 0 ? 'entrada' : 'saida', description: `Lançamento ${i + 1}`, category: i % 3 === 0 ? 'Renda extra' : 'Despesas pessoais', amount: 20 + (i * 7) % 300,
      date: addDays('2026-02-01', i), account: i % 2 ? 'Conta principal' : 'Carteira', origin: '', notes: '', status: 'efetivado', kind: 'normal',
    })
  }
  for (const m of ['2026-08', '2026-09']) d.payrolls.push({ id: id(), month: m, expectedDate: `${m}-30`, paidDate: `${m}-30`, gross: 2900, deductions: 250, net: 2650, status: 'recebido', notes: '' })
  d.goals.push({ id: id(), name: 'Reserva de emergência', target: 3000, saved: 900, deadline: '2026-12-31', notes: '' })
  return d
}

const KINDS: ReportKind[] = ['completo', 'salario', 'produtividade', 'despesas', 'dividas', 'movimentacoes', 'planejamento', 'anual']

describe('relatórios PDF A4', () => {
  const data = bigData()
  for (const kind of KINDS) {
    it(`gera o relatório "${kind}" com dados volumosos`, () => {
      const opts = { kind, range: { from: '2026-02-01', to: '2026-09-30' }, month: '2026-10', year: 2026, activityFilter: 'todas' as const, charts: true, notes: 'Observação de teste.' }
      const doc = buildReport(data, opts, '2026-10-09')
      const pages = doc.getNumberOfPages()
      expect(pages).toBeGreaterThanOrEqual(1)
      if (kind === 'completo' || kind === 'produtividade' || kind === 'despesas') expect(pages).toBeGreaterThan(3)
      const ab = doc.output('arraybuffer')
      expect(ab.byteLength).toBeGreaterThan(2000)
      expect(doc.internal.pageSize.getWidth()).toBeCloseTo(210, 0)
      expect(doc.internal.pageSize.getHeight()).toBeCloseTo(297, 0)
      if (OUT) {
        mkdirSync(OUT, { recursive: true })
        writeFileSync(join(OUT, `${kind}.pdf`), Buffer.from(ab))
      }
    })
  }

  it('gera relatórios vazios sem erro', () => {
    const empty = createInitialData()
    for (const kind of KINDS) {
      const doc = buildReport(empty, { kind, range: { from: '2026-10-01', to: '2026-10-31' }, month: '2026-10', year: 2026 }, '2026-10-09')
      expect(doc.getNumberOfPages()).toBeGreaterThanOrEqual(1)
    }
  })

  it('resolve o período conforme o tipo', () => {
    expect(resolveRange({ kind: 'anual', range: { from: 'x', to: 'y' }, month: '2026-10', year: 2025 })).toEqual({ from: '2025-01-01', to: '2025-12-31' })
    expect(resolveRange({ kind: 'planejamento', range: { from: 'x', to: 'y' }, month: '2026-02', year: 2025 })).toEqual({ from: '2026-02-01', to: '2026-02-28' })
    expect(resolveRange({ kind: 'despesas', range: { from: '2026-05-10', to: '2026-05-01' }, month: '2026-10', year: 2025 })).toEqual({ from: '2026-05-01', to: '2026-05-10' })
  })
})
