/**
 * Geração dos relatórios em PDF A4 (jsPDF + jsPDF-AutoTable).
 * Cada relatório tem layout próprio: cabeçalho/rodapé discretos, numeração de páginas,
 * tabelas com cabeçalho repetido, gráficos desenhados em vetor (legíveis em preto e branco).
 */
import { jsPDF } from 'jspdf'
import autoTable, { type CellHookData, type RowInput } from 'jspdf-autotable'
import type { ActivityType, AppData, Range } from '../types'
import { ACTIVITY_LABEL } from '../types'
import {
  accountBalances,
  buildAlerts,
  calcDebt,
  computePayroll,
  effectivePayroll,
  entryValue,
  expenseStatus,
  expensesInRange,
  extraIncome,
  filterProductivity,
  isFixedExpense,
  ledgerTotals,
  monthSummary,
  pendingInstallments,
  plannedBalance,
  productivityByDay,
  productivitySeries,
  rangeSummary,
  realizedBalance,
  sum,
  summarizeProductivity,
  totalsByCategory,
  pctChange,
} from '../lib/calc'
import { addDays, daysBetween, inRange, monthLabel, monthRange, monthsBetween, shortMonth, weekdayShort } from '../lib/dates'
import { brlPlain, formatDateBR, num, pct, round2 } from '../lib/format'

export type ReportKind = 'completo' | 'salario' | 'produtividade' | 'despesas' | 'dividas' | 'movimentacoes' | 'planejamento' | 'anual'

export interface ReportOptions {
  kind: ReportKind
  range: Range
  month: string
  year: number
  activityFilter?: ActivityType | 'todas'
  title?: string
  notes?: string
  charts?: boolean
}

export const REPORT_TITLES: Record<ReportKind, string> = {
  completo: 'Relatório financeiro completo',
  salario: 'Relatório de salário e folha',
  produtividade: 'Relatório de produtividade',
  despesas: 'Relatório de despesas',
  dividas: 'Relatório de dívidas',
  movimentacoes: 'Relatório de receitas e movimentações',
  planejamento: 'Relatório de planejamento mensal',
  anual: 'Relatório anual consolidado',
}

export function resolveRange(o: ReportOptions): Range {
  if (o.kind === 'planejamento') return monthRange(o.month)
  if (o.kind === 'anual') return { from: `${o.year}-01-01`, to: `${o.year}-12-31` }
  return o.range.from <= o.range.to ? o.range : { from: o.range.to, to: o.range.from }
}

export function reportFileName(o: ReportOptions): string {
  const r = resolveRange(o)
  return `meu-controle_${o.kind}_${r.from}_${r.to}.pdf`
}

/* ------------------------------------------------------------------ */

const PW = 210
const PH = 297
const ML = 15
const MR = 15
const MT = 24
const MB = 18
const CW = PW - ML - MR

type RGB = [number, number, number]
const INK: RGB = [24, 28, 36]
const MUTED: RGB = [105, 112, 122]
const LINE: RGB = [215, 218, 223]
const HEAD_BG: RGB = [236, 238, 241]
const FOOT_BG: RGB = [246, 247, 249]
const GREEN: RGB = [34, 106, 62]
const RED: RGB = [160, 50, 36]

/** Mantém apenas caracteres suportados pela fonte padrão do PDF (Latin-1). */
const T = (s: string | number): string =>
  String(s)
    .replace(/[−–—]/g, '-')
    .replace(/…/g, '...')
    .replace(/[‘’]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/[   ]/g, ' ')
    .replace(/[^\x20-\x7e¡-ÿ\n]/g, '')

const M = (n: number) => brlPlain(n)

type Tone = 'income' | 'expense'
interface TableOpts {
  head: string[]
  body: (string | number)[][]
  foot?: (string | number)[]
  right?: number[]
  center?: number[]
  widths?: Record<number, number>
  tone?: Record<number, Tone>
  fontSize?: number
}

class Writer {
  doc: jsPDF
  y = MT
  constructor() {
    this.doc = new jsPDF({ unit: 'mm', format: 'a4', orientation: 'portrait', compress: true })
    this.doc.setFont('helvetica', 'normal')
  }

  space(h: number) {
    if (this.y + h > PH - MB) {
      this.doc.addPage()
      this.y = MT
    }
  }

  gap(h = 4) {
    this.y += h
  }

  text(s: string, opt: { size?: number; bold?: boolean; color?: RGB; x?: number; align?: 'left' | 'right' | 'center'; width?: number; lh?: number } = {}) {
    const d = this.doc
    const size = opt.size ?? 9
    d.setFont('helvetica', opt.bold ? 'bold' : 'normal')
    d.setFontSize(size)
    d.setTextColor(...(opt.color ?? INK))
    const lines = d.splitTextToSize(T(s), opt.width ?? CW) as string[]
    const lh = opt.lh ?? size * 0.42
    for (const ln of lines) {
      this.space(lh + 1)
      const x = opt.align === 'right' ? (opt.x ?? ML + CW) : opt.align === 'center' ? (opt.x ?? ML + CW / 2) : opt.x ?? ML
      d.text(ln, x, this.y + size * 0.3, { align: opt.align ?? 'left' })
      this.y += lh
    }
  }

  section(title: string) {
    this.space(16)
    this.gap(3)
    const d = this.doc
    d.setFont('helvetica', 'bold')
    d.setFontSize(11.5)
    d.setTextColor(...INK)
    d.text(T(title), ML, this.y + 4)
    this.y += 6.5
    d.setDrawColor(...INK)
    d.setLineWidth(0.35)
    d.line(ML, this.y, ML + CW, this.y)
    this.y += 3.5
  }

  sub(title: string) {
    this.space(10)
    this.gap(1.5)
    this.text(title, { size: 9.5, bold: true })
    this.gap(1.5)
  }

  note(s: string) {
    this.text(s, { size: 8, color: MUTED, lh: 3.6 })
    this.gap(1.5)
  }

  empty(s = 'Sem registros no período.') {
    this.text(s, { size: 9, color: MUTED })
    this.gap(2)
  }

  table(o: TableOpts) {
    const right = new Set(o.right ?? [])
    const center = new Set(o.center ?? [])
    const columnStyles: Record<number, object> = {}
    o.head.forEach((_, i) => {
      columnStyles[i] = {
        halign: right.has(i) ? 'right' : center.has(i) ? 'center' : 'left',
        ...(o.widths?.[i] ? { cellWidth: o.widths[i] } : {}),
      }
    })
    const body: RowInput[] = o.body.map((r) => r.map((c) => T(c)))
    autoTable(this.doc, {
      startY: this.y,
      margin: { left: ML, right: MR, top: MT, bottom: MB },
      head: [o.head.map(T)],
      body,
      foot: o.foot ? [o.foot.map(T)] : undefined,
      showHead: 'everyPage',
      showFoot: 'lastPage',
      rowPageBreak: 'avoid',
      theme: 'plain',
      styles: { font: 'helvetica', fontSize: o.fontSize ?? 8.2, cellPadding: { top: 1.6, bottom: 1.6, left: 1.8, right: 1.8 }, textColor: INK, lineColor: LINE, lineWidth: 0, overflow: 'linebreak' },
      headStyles: { fillColor: HEAD_BG, textColor: INK, fontStyle: 'bold', fontSize: (o.fontSize ?? 8.2) - 0.4 },
      footStyles: { fillColor: FOOT_BG, textColor: INK, fontStyle: 'bold' },
      columnStyles,
      didParseCell: (h: CellHookData) => {
        if (h.section === 'head' || h.section === 'foot') {
          h.cell.styles.halign = right.has(h.column.index) ? 'right' : center.has(h.column.index) ? 'center' : 'left'
        }
        if (h.section === 'body' || h.section === 'foot') {
          const tone = o.tone?.[h.column.index]
          if (tone && h.section === 'body') h.cell.styles.textColor = tone === 'income' ? GREEN : RED
        }
      },
      didDrawCell: (h: CellHookData) => {
        // linha fina sob cada linha do corpo e sobre o rodapé
        const d = this.doc
        if (h.section === 'body' || h.section === 'head') {
          d.setDrawColor(...LINE)
          d.setLineWidth(0.15)
          d.line(h.cell.x, h.cell.y + h.cell.height, h.cell.x + h.cell.width, h.cell.y + h.cell.height)
        }
        if (h.section === 'foot') {
          d.setDrawColor(...INK)
          d.setLineWidth(0.3)
          d.line(h.cell.x, h.cell.y, h.cell.x + h.cell.width, h.cell.y)
        }
      },
    })
    this.y = (this.doc as jsPDF & { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 4
  }

  /** Pares rótulo/valor em 2 colunas de indicadores. */
  kv(rows: [string, string, Tone?][]) {
    const body: RowInput[] = []
    for (let i = 0; i < rows.length; i += 2) {
      const a = rows[i]
      const b = rows[i + 1]
      body.push([T(a[0]), T(a[1]), b ? T(b[0]) : '', b ? T(b[1]) : ''])
    }
    autoTable(this.doc, {
      startY: this.y,
      margin: { left: ML, right: MR, top: MT, bottom: MB },
      body,
      theme: 'plain',
      rowPageBreak: 'avoid',
      styles: { font: 'helvetica', fontSize: 8.6, cellPadding: { top: 1.7, bottom: 1.7, left: 1.8, right: 1.8 }, textColor: INK },
      columnStyles: {
        0: { cellWidth: 49, textColor: MUTED },
        1: { cellWidth: 41, halign: 'right', fontStyle: 'bold' },
        2: { cellWidth: 49, textColor: MUTED },
        3: { cellWidth: 41, halign: 'right', fontStyle: 'bold' },
      },
      didParseCell: (h: CellHookData) => {
        if (h.section !== 'body') return
        const idx = h.row.index * 2 + (h.column.index >= 2 ? 1 : 0)
        const tone = rows[idx]?.[2]
        if (tone && (h.column.index === 1 || h.column.index === 3)) h.cell.styles.textColor = tone === 'income' ? GREEN : RED
      },
      didDrawCell: (h: CellHookData) => {
        this.doc.setDrawColor(...LINE)
        this.doc.setLineWidth(0.15)
        this.doc.line(h.cell.x, h.cell.y + h.cell.height, h.cell.x + h.cell.width, h.cell.y + h.cell.height)
      },
    })
    this.y = (this.doc as jsPDF & { lastAutoTable: { finalY: number } }).lastAutoTable.finalY + 4
  }

  /* Gráficos em vetor ------------------------------------------------ */

  chartV(title: string, labels: string[], series: { name: string; values: number[]; shade: number }[], h = 54) {
    const d = this.doc
    const total = h + 12
    this.space(total)
    this.text(title, { size: 9, bold: true })
    const x0 = ML + 15
    const x1 = ML + CW - 1
    const top = this.y + 2
    const bottom = top + h - 12
    const maxRaw = Math.max(1, ...series.flatMap((s) => s.values))
    const maxV = niceCeil(maxRaw)
    d.setFontSize(7)
    d.setFont('helvetica', 'normal')
    d.setTextColor(...MUTED)
    for (let i = 0; i <= 4; i++) {
      const v = (maxV / 4) * i
      const yy = bottom - ((bottom - top) * i) / 4
      d.setDrawColor(i === 0 ? 150 : 232)
      d.setLineWidth(i === 0 ? 0.3 : 0.15)
      d.line(x0, yy, x1, yy)
      d.text(T(short(v)), x0 - 1.5, yy + 1, { align: 'right' })
    }
    const n = Math.max(1, labels.length)
    const gw = (x1 - x0) / n
    const bw = Math.min(10, (gw * 0.72) / series.length)
    const step = Math.ceil(n / 16)
    labels.forEach((lab, i) => {
      const cx = x0 + gw * i + gw / 2
      series.forEach((s, j) => {
        const v = Math.max(0, s.values[i] ?? 0)
        const bh = ((bottom - top) * v) / maxV
        const bx = cx - (bw * series.length) / 2 + bw * j
        d.setFillColor(s.shade, s.shade, s.shade)
        if (bh > 0) d.rect(bx, bottom - bh, bw, bh, 'F')
      })
      if (i % step === 0) {
        d.setTextColor(...MUTED)
        d.text(T(lab), cx, bottom + 3.8, { align: 'center' })
      }
    })
    if (series.length > 1) {
      let lx = x1
      d.setFontSize(7.2)
      for (const s of [...series].reverse()) {
        const w = d.getTextWidth(T(s.name))
        lx -= w
        d.setTextColor(...INK)
        d.text(T(s.name), lx, this.y - 0.6)
        lx -= 4
        d.setFillColor(s.shade, s.shade, s.shade)
        d.rect(lx, this.y - 3, 2.8, 2.8, 'F')
        lx -= 4
      }
    }
    this.y = bottom + 8
    this.gap(2)
  }

  chartH(title: string, items: { label: string; value: number }[], max = 8) {
    const list = items.filter((i) => i.value > 0).slice(0, max)
    if (!list.length) return
    const d = this.doc
    this.space(list.length * 6 + 10)
    this.text(title, { size: 9, bold: true })
    this.gap(1)
    const maxV = Math.max(...list.map((i) => i.value))
    const bx = ML + 52
    const bmax = CW - 52 - 30
    for (const it of list) {
      d.setFont('helvetica', 'normal')
      d.setFontSize(8)
      d.setTextColor(...INK)
      const lab = (d.splitTextToSize(T(it.label), 50) as string[])[0]
      d.text(lab, ML, this.y + 3.6)
      const w = Math.max(0.6, (bmax * it.value) / maxV)
      d.setFillColor(70, 74, 82)
      d.rect(bx, this.y + 0.9, w, 3.6, 'F')
      d.setTextColor(...MUTED)
      d.text(T(M(it.value)), bx + w + 2, this.y + 3.6)
      this.y += 6
    }
    this.gap(2)
  }

  notesBox(text?: string) {
    this.section('Observações')
    const d = this.doc
    const clean = (text ?? '').trim()
    if (clean) {
      this.text(clean, { size: 9, lh: 4.2 })
    } else {
      this.space(32)
      d.setDrawColor(...LINE)
      d.setLineWidth(0.2)
      for (let i = 0; i < 5; i++) {
        d.line(ML, this.y + 6 * (i + 1), ML + CW, this.y + 6 * (i + 1))
      }
      this.y += 32
    }
  }

  finish(headerTitle: string, who: string, generated: string) {
    const d = this.doc
    const n = d.getNumberOfPages()
    for (let i = 1; i <= n; i++) {
      d.setPage(i)
      d.setFont('helvetica', 'normal')
      d.setFontSize(7.5)
      d.setTextColor(...MUTED)
      d.text('Meu Controle', ML, 11)
      d.text(T(headerTitle), PW - MR, 11, { align: 'right' })
      d.setDrawColor(...LINE)
      d.setLineWidth(0.2)
      d.line(ML, 13.5, PW - MR, 13.5)
      d.line(ML, PH - 13, PW - MR, PH - 13)
      d.text(T(`Gerado em ${generated}${who ? ` · ${who}` : ''}`), ML, PH - 8.5)
      d.text(`Página ${i} de ${n}`, PW - MR, PH - 8.5, { align: 'right' })
    }
  }
}

function niceCeil(v: number): number {
  if (v <= 0) return 1
  const p = Math.pow(10, Math.floor(Math.log10(v)))
  const f = v / p
  // valores divisíveis por 4 para que os 4 intervalos do eixo tenham números "redondos"
  const nf = f <= 1 ? 1 : f <= 2 ? 2 : f <= 4 ? 4 : f <= 6 ? 6 : f <= 8 ? 8 : 10
  return nf * p
}

function short(v: number): string {
  if (v >= 1000) return `${(v / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} mil`
  return String(Math.round(v))
}

const periodText = (r: Range) => (r.from === r.to ? formatDateBR(r.from) : `${formatDateBR(r.from)} a ${formatDateBR(r.to)}`)

/* ------------------------------------------------------------------ */
/* Seções                                                              */
/* ------------------------------------------------------------------ */

function secResumo(w: Writer, d: AppData, r: Range, today: string) {
  const s = rangeSummary(d, r, today)
  const txs = d.transactions.filter((t) => inRange(t.date, r))
  const lt = ledgerTotals(txs)
  w.section('Resumo financeiro')
  w.kv([
    ['Salário líquido ' + (s.salaryConfirmed ? '(confirmado)' : '(estimado)'), M(s.salaryNet), 'income'],
    ['Receitas extras', M(s.extras), 'income'],
    ['Receitas previstas (total)', M(s.income), 'income'],
    ['Receitas realizadas (caixa)', M(lt.inReal), 'income'],
    ['Despesas do período', M(s.expensesPlanned), 'expense'],
    ['Parcelas e pagamentos de dívidas', M(s.debtTotal), 'expense'],
    ['Total de compromissos', M(s.outflow), 'expense'],
    ['Salário comprometido', s.salaryNet > 0 ? pct(s.committedPct, 0) : '-'],
    ['Saldo previsto do período', M(s.balance), s.balance >= 0 ? 'income' : 'expense'],
    ['Saldo atual (realizado)', M(realizedBalance(d.transactions)), realizedBalance(d.transactions) >= 0 ? 'income' : 'expense'],
    ['Saldo previsto (total)', M(plannedBalance(d.transactions))],
    ['Despesas pagas / pendentes', `${M(s.expensesPaid)} / ${M(s.expensesPending)}`],
  ])
  w.note('Salário e produtividade são contados uma única vez: a produtividade elegível já compõe o salário e não é somada novamente como receita extra. Pagamentos de dívidas não são somados também como despesas.')
}

function secSalarioMonths(w: Writer, d: AppData, r: Range) {
  const months = monthsBetween(r.from, r.to)
  w.section('Salário e folha')
  const rows = months.map((m) => {
    const e = effectivePayroll(d, m)
    const c = e.estimate
    return { m, e, c }
  })
  w.table({
    head: ['Competência', 'Base', 'Noturno', 'Assid.', 'Produt.', 'Bruto', 'Descontos', 'Líquido', 'Situação'],
    body: rows.map(({ m, e, c }) => [
      cap(monthLabel(m)),
      M(c.baseSalary),
      M(c.nightAdditional),
      M(c.attendance),
      M(c.productionEligible),
      M(e.gross),
      M(e.deductions),
      M(e.net),
      e.confirmed ? (e.record?.status === 'ajustado' ? 'Ajustada' : 'Recebida') : 'Estimativa',
    ]),
    foot: [
      'Total',
      M(sum(rows.map((x) => x.c.baseSalary))),
      M(sum(rows.map((x) => x.c.nightAdditional))),
      M(sum(rows.map((x) => x.c.attendance))),
      M(sum(rows.map((x) => x.c.productionEligible))),
      M(sum(rows.map((x) => x.e.gross))),
      M(sum(rows.map((x) => x.e.deductions))),
      M(sum(rows.map((x) => x.e.net))),
      '',
    ],
    right: [1, 2, 3, 4, 5, 6, 7],
    fontSize: 7.6,
    tone: { 7: 'income' },
  })

  if (months.length <= 3) {
    for (const { m, e, c } of rows) {
      w.sub(`Detalhamento: ${cap(monthLabel(m))} (período da folha ${periodText(c.period)})`)
      const body: (string | number)[][] = [
        ['Salário-base', M(c.baseSalary)],
        [`Adicional noturno (${num(c.nightHours, 1)} h x ${M(c.hourly)}/h x ${num(d.settings.nightPct, 1)}%)`, M(c.nightAdditional)],
        ['Assiduidade', M(c.attendance)],
        [`Produtividade elegível (produzido ${M(c.productionTotal)})`, M(c.productionEligible)],
      ]
      if (d.settings.overtimeEnabled) body.push([`Horas extras (${num(c.overtimeHours, 1)} h)`, M(c.overtime)])
      for (const it of d.settings.otherAdditions) body.push([it.name || 'Outro adicional', M(it.amount)])
      body.push(['TOTAL BRUTO ESTIMADO', M(c.gross)])
      body.push(['Vale-transporte', '- ' + M(c.vt)])
      body.push([c.inssConfigured ? 'INSS e descontos legais (conforme configuração)' : 'INSS e descontos legais (a confirmar no holerite)', c.inssConfigured ? '- ' + M(c.inss) : 'não calculado'])
      body.push(['Adiantamentos', '- ' + M(c.advances)])
      for (const it of d.settings.otherDeductions) body.push([it.name || 'Outro desconto', '- ' + M(it.amount)])
      body.push(['TOTAL DE DESCONTOS', '- ' + M(c.totalDeductions)])
      w.table({
        head: ['Descrição', 'Valor'],
        body,
        foot: ['SALÁRIO LÍQUIDO ESTIMADO', M(c.net)],
        right: [1],
        widths: { 1: 38 },
      })
      if (e.confirmed && e.record) {
        w.note(`Folha ${e.record.status === 'ajustado' ? 'ajustada' : 'recebida'}: líquido ${M(e.net)} (diferença para a estimativa: ${M(round2(e.net - c.net))}).`)
      }
      for (const warn of c.warnings) w.note('Aviso: ' + warn)
    }
  }

  const pays = d.payrolls.filter((p) => months.includes(p.month)).sort((a, b) => a.month.localeCompare(b.month))
  w.sub('Controle de pagamentos')
  if (!pays.length) w.empty('Nenhum pagamento de folha registrado no período.')
  else
    w.table({
      head: ['Competência', 'Previsto para', 'Pago em', 'Bruto', 'Descontos', 'Líquido', 'Estimado', 'Diferença', 'Status'],
      body: pays.map((p) => {
        const est = computePayroll(d, p.month)
        const diff = p.status === 'previsto' ? '-' : M(round2(p.net - est.net))
        return [cap(shortMonth(p.month)), formatDateBR(p.expectedDate), formatDateBR(p.paidDate), M(p.gross), M(p.deductions), M(p.net), M(est.net), diff, p.status === 'previsto' ? 'Previsto' : p.status === 'recebido' ? 'Recebido' : 'Ajustado']
      }),
      right: [3, 4, 5, 6, 7],
      fontSize: 7.4,
    })
}

function prevRange(r: Range): Range {
  const len = daysBetween(r.from, r.to) + 1
  return { from: addDays(r.from, -len), to: addDays(r.from, -1) }
}

function secProdutividade(w: Writer, d: AppData, r: Range, filter: ActivityType | 'todas', charts: boolean, full: boolean) {
  const entries = filterProductivity(d.productivity, r, filter)
  const s = summarizeProductivity(entries)
  const prev = summarizeProductivity(filterProductivity(d.productivity, prevRange(r), filter))
  const delta = pctChange(s.totalValue, prev.totalValue)
  w.section('Produtividade')
  if (filter !== 'todas') w.note(`Filtro aplicado: ${ACTIVITY_LABEL[filter]}.`)
  w.kv([
    ['Conferências (unidades)', num(s.confQty)],
    ['Valor gerado em conferências', M(s.confValue), 'income'],
    ['Separações (unidades)', num(s.sepQty)],
    ['Valor gerado em separações', M(s.sepValue), 'income'],
    ['Produtividade total', M(s.totalValue), 'income'],
    ['Dias com produção', num(s.activeDays)],
    ['Média por dia trabalhado', M(s.avgPerDay)],
    ['Melhor dia', s.bestDay ? `${formatDateBR(s.bestDay.date)} (${M(s.bestDay.value)})` : '-'],
    ['Período anterior', M(prev.totalValue)],
    ['Variação', delta === null ? 'sem base' : `${delta >= 0 ? '+' : ''}${num(delta, 1)}%`],
  ])
  if (!entries.length) return w.empty('Nenhuma produtividade registrada no período.')

  if (charts) {
    const series = productivitySeries(entries, r)
    if (series.length > 1)
      w.chartV('Produtividade por ' + (series.length <= 62 && daysBetween(r.from, r.to) <= 61 ? 'dia' : 'mês') + ' (R$)', series.map((x) => x.label), [
        { name: 'Conferência', values: series.map((x) => x.conf), shade: 55 },
        { name: 'Separação', values: series.map((x) => x.sep), shade: 165 },
      ])
  }

  w.sub('Resumo por dia')
  const days = productivityByDay(entries)
  w.table({
    head: ['Dia', 'Conferências', 'Separações', 'Valor conferência', 'Valor separação', 'Total do dia'],
    body: days.map((x) => [`${formatDateBR(x.date)} ${weekdayShort(x.date)}`, num(x.confQty), num(x.sepQty), M(x.conf), M(x.sep), M(x.total)]),
    foot: ['Total', num(s.confQty), num(s.sepQty), M(s.confValue), M(s.sepValue), M(s.totalValue)],
    right: [1, 2, 3, 4, 5],
    tone: { 5: 'income' },
  })

  const hist = (type: ActivityType, title: string) => {
    const list = entries.filter((e) => e.type === type).sort((a, b) => a.date.localeCompare(b.date))
    w.sub(title)
    if (!list.length) return w.empty('Sem registros.')
    w.table({
      head: ['Data', 'Quantidade', 'Valor unitário', 'Total', 'Observações'],
      body: list.map((e) => [formatDateBR(e.date), num(e.qty), M(e.unitValue), M(entryValue(e)), e.notes ?? '']),
      foot: ['Total', num(sum(list.map((e) => e.qty))), '', M(sum(list.map(entryValue))), ''],
      right: [1, 2, 3],
      widths: { 4: 60 },
    })
  }
  if (filter !== 'separacao') hist('conferencia', 'Histórico de conferências')
  if (filter !== 'conferencia') hist('separacao', 'Histórico de separações')
  void full
}

function secDespesas(w: Writer, d: AppData, r: Range, today: string, charts: boolean) {
  const list = expensesInRange(d.expenses, r).sort((a, b) => a.dueDate.localeCompare(b.dueDate))
  w.section('Despesas')
  const total = sum(list.map((e) => e.amount))
  const paid = sum(list.filter((e) => e.status === 'paga').map((e) => e.amount))
  const late = sum(list.filter((e) => expenseStatus(e, today) === 'atrasada').map((e) => e.amount))
  w.kv([
    ['Total no período', M(total), 'expense'],
    ['Pagas', M(paid), 'income'],
    ['A pagar', M(round2(total - paid))],
    ['Em atraso', M(late), late > 0 ? 'expense' : undefined],
    ['Despesas fixas (recorrentes)', M(sum(list.filter(isFixedExpense).map((e) => e.amount)))],
    ['Despesas variáveis', M(sum(list.filter((e) => !isFixedExpense(e)).map((e) => e.amount)))],
  ])
  if (!list.length) return w.empty('Nenhuma despesa no período.')

  const cats = totalsByCategory(list)
  if (charts) w.chartH('Despesas por categoria', cats.map((c) => ({ label: c.category, value: c.total })))
  w.sub('Totais por categoria')
  w.table({
    head: ['Categoria', 'Planejado', 'Pago', 'A pagar', '% do total'],
    body: cats.map((c) => {
      const p = sum(list.filter((e) => e.category === c.category && e.status === 'paga').map((e) => e.amount))
      return [c.category, M(c.total), M(p), M(round2(c.total - p)), pct(total ? (c.total / total) * 100 : 0, 1)]
    }),
    foot: ['Total', M(total), M(paid), M(round2(total - paid)), '100%'],
    right: [1, 2, 3, 4],
  })

  w.sub('Lista detalhada')
  w.table({
    head: ['Vencimento', 'Despesa', 'Categoria', 'Valor', 'Status', 'Pago em', 'Forma'],
    body: list.map((e) => {
      const st = expenseStatus(e, today)
      const nm = e.installment ? `${e.name} (${e.installment.n}/${e.installment.of})` : e.name
      return [formatDateBR(e.dueDate), nm, e.category, M(e.amount), st === 'paga' ? 'Paga' : st === 'atrasada' ? 'Atrasada' : 'Pendente', formatDateBR(e.paidDate), e.method || '-']
    }),
    foot: ['Total', '', '', M(total), '', '', ''],
    right: [3],
    fontSize: 7.8,
    widths: { 0: 22, 3: 25, 4: 20, 5: 22 },
  })
}

function secDividas(w: Writer, d: AppData, r: Range, today: string) {
  w.section('Dívidas')
  const rows = d.debts.map((x) => ({ x, c: calcDebt(x, d.debtPayments, today) }))
  const open = rows.filter((v) => v.c.status !== 'quitada')
  const pays = d.debtPayments.filter((p) => inRange(p.date, r)).sort((a, b) => a.date.localeCompare(b.date))
  w.kv([
    ['Dívida total em aberto', M(sum(open.map((v) => v.c.remaining))), 'expense'],
    ['Total já pago (acumulado)', M(sum(rows.map((v) => v.c.paidTotal))), 'income'],
    ['Pago no período', M(sum(pays.map((p) => p.amount))), 'income'],
    ['Dívidas atrasadas', num(rows.filter((v) => v.c.status === 'atrasada').length)],
    ['Dívidas quitadas', num(rows.filter((v) => v.c.status === 'quitada').length)],
    ['Dívidas ativas', num(open.length)],
  ])
  w.sub('Dívidas em aberto')
  if (!open.length) w.empty('Nenhuma dívida em aberto.')
  else
    w.table({
      head: ['Dívida / credor', 'Valor total', 'Pago', 'Saldo', '% quitado', 'Parcelas', 'Próx. venc.', 'Situação'],
      body: open.map(({ x, c }) => [
        x.creditor ? `${x.name} (${x.creditor})` : x.name,
        M(c.totalOwed),
        M(c.paidTotal),
        M(c.remaining),
        pct(c.pct, 0),
        x.totalInstallments > 0 ? `${c.paidInstallments}/${x.totalInstallments}` : `${c.paidInstallments} pagas`,
        formatDateBR(x.nextDue),
        c.status === 'atrasada' ? 'Atrasada' : c.status === 'negociacao' ? 'Negociação' : 'Em dia',
      ]),
      foot: ['Total', M(sum(open.map((v) => v.c.totalOwed))), M(sum(open.map((v) => v.c.paidTotal))), M(sum(open.map((v) => v.c.remaining))), '', '', '', ''],
      right: [1, 2, 3, 4],
      fontSize: 7.6,
      tone: { 3: 'expense' },
    })

  w.sub('Parcelas pagas e pendentes')
  const pendRows: (string | number)[][] = []
  for (const { x, c } of open)
    for (const p of pendingInstallments(x, c)) if (inRange(p.due, r)) pendRows.push([formatDateBR(p.due), x.name, `${p.k}${x.totalInstallments ? '/' + x.totalInstallments : ''}`, M(p.amount), p.due < today ? 'Atrasada' : 'A vencer'])
  pendRows.sort((a, b) => String(a[0]).split('/').reverse().join('').localeCompare(String(b[0]).split('/').reverse().join('')))
  if (!pendRows.length) w.empty('Nenhuma parcela pendente com vencimento no período.')
  else
    w.table({
      head: ['Vencimento', 'Dívida', 'Parcela', 'Valor', 'Situação'],
      body: pendRows,
      foot: ['Total pendente no período', '', '', M(sum(pendRows.map((x) => Number(String(x[3]).replace(/[^\d,-]/g, '').replace(',', '.')) || 0))), ''],
      right: [3],
    })

  w.sub('Histórico de pagamentos no período')
  if (!pays.length) w.empty('Nenhum pagamento de dívida no período.')
  else
    w.table({
      head: ['Data', 'Dívida', 'Credor', 'Valor', 'Observações'],
      body: pays.map((p) => {
        const x = d.debts.find((y) => y.id === p.debtId)
        return [formatDateBR(p.date), x?.name ?? '-', x?.creditor || '-', M(p.amount), p.notes]
      }),
      foot: ['Total', '', '', M(sum(pays.map((p) => p.amount))), ''],
      right: [3],
      widths: { 4: 55 },
    })

  const done = rows.filter((v) => v.c.status === 'quitada')
  if (done.length) {
    w.sub('Dívidas quitadas')
    w.table({ head: ['Dívida', 'Credor', 'Valor total', 'Total pago'], body: done.map(({ x, c }) => [x.name, x.creditor || '-', M(c.totalOwed), M(c.paidTotal)]), right: [2, 3] })
  }
}

function secMovimentacoes(w: Writer, d: AppData, r: Range) {
  w.section('Receitas e movimentações')
  const txs = d.transactions.filter((t) => inRange(t.date, r)).sort((a, b) => a.date.localeCompare(b.date))
  const lt = ledgerTotals(txs)
  w.kv([
    ['Entradas efetivadas', M(lt.inReal), 'income'],
    ['Entradas previstas', M(lt.inPlan)],
    ['Saídas efetivadas', M(lt.outReal), 'expense'],
    ['Saídas previstas', M(lt.outPlan)],
    ['Saldo realizado (total)', M(realizedBalance(d.transactions)), realizedBalance(d.transactions) >= 0 ? 'income' : 'expense'],
    ['Saldo previsto (total)', M(plannedBalance(d.transactions))],
    ['Receitas extras no período', M(extraIncome(d.transactions, r)), 'income'],
    ['Resultado efetivado do período', M(round2(lt.inReal - lt.outReal)), lt.inReal - lt.outReal >= 0 ? 'income' : 'expense'],
  ])
  w.sub('Saldo por conta (realizado)')
  w.table({ head: ['Conta', 'Saldo'], body: accountBalances(d.transactions, d.settings.accounts).map((a) => [a.account, M(a.balance)]), right: [1], widths: { 1: 40 } })
  w.sub('Lançamentos')
  if (!txs.length) return w.empty('Nenhuma movimentação no período.')
  w.table({
    head: ['Data', 'Descrição', 'Categoria', 'Conta', 'Valor', 'Situação'],
    body: txs.map((t) => [
      formatDateBR(t.date),
      t.description + (t.kind === 'transferencia' ? ' (transf.)' : t.kind === 'incorporada' ? ' (já no salário)' : ''),
      t.category,
      t.account,
      (t.type === 'entrada' ? '+ ' : '- ') + M(t.amount),
      t.status === 'efetivado' ? 'Efetivado' : 'Previsto',
    ]),
    foot: ['Resultado (sem transferências)', '', '', '', M(round2(sum(txs.filter((t) => t.kind === 'normal').map((t) => (t.type === 'entrada' ? t.amount : -t.amount))))), ''],
    right: [4],
    fontSize: 7.8,
    widths: { 0: 22, 4: 30, 5: 20 },
  })
  w.note('Transferências entre contas e lançamentos já incorporados ao salário não entram nos totais de entradas e saídas.')
}

function secPlanejamento(w: Writer, d: AppData, month: string, today: string) {
  const s = monthSummary(d, month, today)
  const eff = effectivePayroll(d, month)
  const r = monthRange(month)
  const list = expensesInRange(d.expenses, r)
  const fixed = sum(list.filter(isFixedExpense).map((e) => e.amount))
  const variable = sum(list.filter((e) => !isFixedExpense(e)).map((e) => e.amount))
  const goal = d.settings.monthlyGoal
  w.section(`Planejamento de ${monthLabel(month)}`)
  w.kv([
    ['Salário líquido ' + (eff.confirmed ? '(confirmado)' : '(estimado)'), M(eff.net), 'income'],
    ['Produtividade prevista', M(eff.estimate.productionEligible), 'income'],
    ['Receitas extras', M(s.extras), 'income'],
    ['Total de receitas', M(s.income), 'income'],
    ['Despesas fixas', M(fixed), 'expense'],
    ['Despesas variáveis', M(variable), 'expense'],
    ['Parcelas de dívidas', M(s.debtTotal), 'expense'],
    ['Total de compromissos', M(s.outflow), 'expense'],
    ['Saldo previsto', M(s.balance), s.balance >= 0 ? 'income' : 'expense'],
    ['Meta de economia', goal > 0 ? M(goal) : 'não definida'],
    ['Disponível para gastos', M(round2(s.income - s.outflow - goal)), s.income - s.outflow - goal >= 0 ? 'income' : 'expense'],
    ['Salário comprometido', s.salaryNet > 0 ? pct(s.committedPct, 0) : '-'],
  ])
  w.sub('Alertas do mês')
  const alerts = buildAlerts(d, month, today, M)
  if (!alerts.length) w.empty('Nenhum alerta.')
  else for (const a of alerts) w.text(`- ${a.text}`, { size: 8.6, lh: 4, color: a.level === 'danger' ? RED : INK })
  w.gap(2)

  const cats = totalsByCategory(list)
  const names = [...new Set([...cats.map((c) => c.category), ...Object.keys(d.settings.budgets).filter((c) => d.settings.budgets[c] > 0)])]
  w.sub('Orçamento por categoria')
  if (!names.length) w.empty('Sem despesas nem orçamentos definidos.')
  else
    w.table({
      head: ['Categoria', 'Gasto previsto', 'Orçamento', 'Situação'],
      body: names.map((c) => {
        const spent = cats.find((x) => x.category === c)?.total ?? 0
        const b = d.settings.budgets[c] ?? 0
        return [c, M(spent), b > 0 ? M(b) : '-', b > 0 ? (spent > b ? `Ultrapassado em ${M(spent - b)}` : `${pct((spent / b) * 100, 0)} usado`) : 'Sem limite']
      }),
      right: [1, 2],
    })

  w.sub('Metas financeiras')
  if (!d.goals.length) w.empty('Nenhuma meta cadastrada.')
  else
    w.table({
      head: ['Meta', 'Prazo', 'Guardado', 'Objetivo', 'Falta', 'Progresso'],
      body: d.goals.map((g) => [g.name, formatDateBR(g.deadline), M(g.saved), M(g.target), M(Math.max(0, round2(g.target - g.saved))), pct(g.target ? Math.min(100, (g.saved / g.target) * 100) : 0, 0)]),
      right: [2, 3, 4, 5],
    })

  const upcoming = list.filter((e) => e.status === 'pendente').sort((a, b) => a.dueDate.localeCompare(b.dueDate))
  w.sub('Contas pendentes do mês')
  if (!upcoming.length) w.empty('Nenhuma conta pendente.')
  else
    w.table({
      head: ['Vencimento', 'Despesa', 'Categoria', 'Valor'],
      body: upcoming.map((e) => [formatDateBR(e.dueDate), e.name, e.category, M(e.amount)]),
      foot: ['Total', '', '', M(sum(upcoming.map((e) => e.amount)))],
      right: [3],
    })
}

function secAnual(w: Writer, d: AppData, year: number, today: string, charts: boolean) {
  const months = Array.from({ length: 12 }, (_, i) => `${year}-${String(i + 1).padStart(2, '0')}`)
  const rows = months.map((m) => ({ m, s: monthSummary(d, m, today) }))
  const whole = rangeSummary(d, { from: `${year}-01-01`, to: `${year}-12-31` }, today)
  w.section(`Consolidado de ${year}`)
  w.kv([
    ['Receitas previstas', M(whole.income), 'income'],
    ['Salário líquido', M(whole.salaryNet), 'income'],
    ['Produtividade (na folha)', M(whole.production), 'income'],
    ['Receitas extras', M(whole.extras), 'income'],
    ['Despesas', M(whole.expensesPlanned), 'expense'],
    ['Dívidas (pagas + parcelas)', M(whole.debtTotal), 'expense'],
    ['Saldo previsto do ano', M(whole.balance), whole.balance >= 0 ? 'income' : 'expense'],
    ['Despesas pagas no ano', M(whole.expensesPaid)],
  ])
  if (charts)
    w.chartV(
      'Receitas e despesas por mês (R$)',
      months.map((m) => shortMonth(m)),
      [
        { name: 'Receitas', values: rows.map((x) => x.s.income), shade: 70 },
        { name: 'Despesas + dívidas', values: rows.map((x) => x.s.outflow), shade: 170 },
      ],
    )
  w.sub('Resumo mensal')
  w.table({
    head: ['Mês', 'Salário líq.', 'Extras', 'Receitas', 'Despesas', 'Dívidas', 'Saldo'],
    body: rows.map(({ m, s }) => [cap(monthLabel(m).split(' ')[0]), M(s.salaryNet), M(s.extras), M(s.income), M(s.expensesPlanned), M(s.debtTotal), M(s.balance)]),
    foot: ['Total', M(whole.salaryNet), M(whole.extras), M(whole.income), M(whole.expensesPlanned), M(whole.debtTotal), M(whole.balance)],
    right: [1, 2, 3, 4, 5, 6],
    fontSize: 7.8,
    tone: { 3: 'income', 4: 'expense' },
  })
  const cats = totalsByCategory(expensesInRange(d.expenses, { from: `${year}-01-01`, to: `${year}-12-31` }))
  if (charts) w.chartH('Despesas por categoria no ano', cats.map((c) => ({ label: c.category, value: c.total })))
  if (cats.length)
    w.table({ head: ['Categoria', 'Total no ano', '% das despesas'], body: cats.map((c) => [c.category, M(c.total), pct(whole.expensesPlanned ? (c.total / whole.expensesPlanned) * 100 : 0, 1)]), right: [1, 2] })
  const prod = summarizeProductivity(filterProductivity(d.productivity, { from: `${year}-01-01`, to: `${year}-12-31` }))
  w.sub('Produtividade no ano')
  w.kv([
    ['Conferências', num(prod.confQty)],
    ['Valor das conferências', M(prod.confValue), 'income'],
    ['Separações', num(prod.sepQty)],
    ['Valor das separações', M(prod.sepValue), 'income'],
    ['Total produzido', M(prod.totalValue), 'income'],
    ['Melhor dia', prod.bestDay ? `${formatDateBR(prod.bestDay.date)} (${M(prod.bestDay.value)})` : '-'],
  ])
  const debtRows = d.debts.map((x) => ({ x, c: calcDebt(x, d.debtPayments, today) }))
  const paidYear = sum(d.debtPayments.filter((p) => p.date.startsWith(String(year))).map((p) => p.amount))
  w.sub('Dívidas')
  w.kv([
    ['Pago em dívidas no ano', M(paidYear), 'income'],
    ['Saldo devedor atual', M(sum(debtRows.filter((v) => v.c.status !== 'quitada').map((v) => v.c.remaining))), 'expense'],
  ])
}

const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1)

/* ------------------------------------------------------------------ */

export function buildReport(data: AppData, opts: ReportOptions, today: string): jsPDF {
  const w = new Writer()
  const r = resolveRange(opts)
  const title = (opts.title ?? '').trim() || REPORT_TITLES[opts.kind]
  const charts = opts.charts !== false
  const filter = opts.activityFilter ?? 'todas'
  const who = data.settings.displayName.trim()
  const now = new Date()
  const generated = `${formatDateBR(today)} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`

  // Capa/cabeçalho do documento
  w.text(title, { size: 20, bold: true, lh: 8.5 })
  w.gap(1)
  const periodLine = opts.kind === 'planejamento' ? cap(monthLabel(opts.month)) : opts.kind === 'anual' ? String(opts.year) : periodText(r)
  w.text(`Período: ${periodLine}`, { size: 10, color: MUTED, lh: 5 })
  if (who) w.text(`Responsável: ${who}`, { size: 10, color: MUTED, lh: 5 })
  w.text(`Gerado em: ${generated}`, { size: 10, color: MUTED, lh: 5 })
  w.gap(1)

  switch (opts.kind) {
    case 'completo':
      secResumo(w, data, r, today)
      secSalarioMonths(w, data, r)
      secProdutividade(w, data, r, filter, charts, true)
      secDespesas(w, data, r, today, charts)
      secDividas(w, data, r, today)
      secMovimentacoes(w, data, r)
      if (charts && monthsBetween(r.from, r.to).length >= 2) {
        const ms = monthsBetween(r.from, r.to).slice(-12)
        const rows = ms.map((m) => monthSummary(data, m, today))
        w.section('Receitas e despesas por mês')
        w.chartV('Receitas e compromissos (R$)', ms.map(shortMonth), [
          { name: 'Receitas', values: rows.map((x) => x.income), shade: 70 },
          { name: 'Despesas + dívidas', values: rows.map((x) => x.outflow), shade: 170 },
        ])
      }
      break
    case 'salario':
      secSalarioMonths(w, data, r)
      break
    case 'produtividade':
      secProdutividade(w, data, r, filter, charts, false)
      break
    case 'despesas':
      secDespesas(w, data, r, today, charts)
      break
    case 'dividas':
      secDividas(w, data, r, today)
      break
    case 'movimentacoes':
      secMovimentacoes(w, data, r)
      break
    case 'planejamento':
      secPlanejamento(w, data, opts.month, today)
      break
    case 'anual':
      secAnual(w, data, opts.year, today, charts)
      break
  }

  w.notesBox(opts.notes)
  w.finish(title, who, generated)
  return w.doc
}
