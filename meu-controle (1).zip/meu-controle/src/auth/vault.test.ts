import { beforeEach, describe, expect, it } from 'vitest'

class MemStorage {
  private m = new Map<string, string>()
  get length() { return this.m.size }
  key(i: number) { return Array.from(this.m.keys())[i] ?? null }
  getItem(k: string) { return this.m.has(k) ? (this.m.get(k) as string) : null }
  setItem(k: string, v: string) { this.m.set(k, String(v)) }
  removeItem(k: string) { this.m.delete(k) }
  clear() { this.m.clear() }
}
Object.defineProperty(globalThis, 'localStorage', { value: new MemStorage(), configurable: true, writable: true })

import * as vault from './vault'
vault._setIterationsForTests(1000)

const ls = () => (globalThis as any).localStorage as MemStorage
const allText = () => Array.from({ length: ls().length }, (_, i) => `${ls().key(i)}=${ls().getItem(ls().key(i) as string)}`).join('\n')

beforeEach(() => {
  ls().clear()
  vault.logout()
})

describe('cofre de usuários', () => {
  it('cria conta, grava dados criptografados e reabre com a senha certa', async () => {
    const c = await vault.createUser('Maria', 'senha-segura-1')
    expect(c.ok).toBe(true)
    await vault.saveData({ segredo: 'salario-12345' })
    expect(allText()).not.toContain('salario-12345')
    expect(allText().toLowerCase()).not.toContain('maria')
    vault.logout()
    const l = await vault.login('maria', 'senha-segura-1')
    expect(l.ok && l.session.initialRaw).toEqual({ segredo: 'salario-12345' })
  })

  it('rejeita senha errada e usuário inexistente com a mesma mensagem', async () => {
    await vault.createUser('Maria', 'senha-segura-1')
    vault.logout()
    const a = await vault.login('Maria', 'errada-errada')
    const b = await vault.login('Fulano', 'qualquer-coisa')
    expect(a.ok).toBe(false)
    expect(b.ok).toBe(false)
    expect(!a.ok && !b.ok && a.error === b.error).toBe(true)
  })

  it('isola os dados de cada usuário', async () => {
    await vault.createUser('Ana', 'senha-da-ana-1')
    await vault.saveData({ dono: 'ana' })
    vault.logout()
    await vault.createUser('Bia', 'senha-da-bia-1')
    await vault.saveData({ dono: 'bia' })
    vault.logout()
    const a = await vault.login('Ana', 'senha-da-ana-1')
    expect(a.ok && a.session.initialRaw).toEqual({ dono: 'ana' })
    vault.logout()
    const cruzado = await vault.login('Ana', 'senha-da-bia-1')
    expect(cruzado.ok).toBe(false)
  })

  it('bloqueia depois de várias tentativas erradas', async () => {
    await vault.createUser('Maria', 'senha-segura-1')
    vault.logout()
    for (let i = 0; i < 5; i++) await vault.login('Maria', 'errada-errada')
    const r = await vault.login('Maria', 'senha-segura-1')
    expect(r.ok).toBe(false)
    expect(!r.ok && r.error).toContain('Aguarde')
    expect(await vault.lockSecondsLeft('Maria')).toBeGreaterThan(0)
  })

  it('protege os dados antigos (sem senha) na primeira conta e apaga o texto aberto', async () => {
    ls().setItem(vault.LEGACY_KEY, JSON.stringify({ antigo: 'dado-em-texto-777' }))
    const c = await vault.createUser('Maria', 'senha-segura-1')
    expect(c.ok && c.session.initialRaw).toEqual({ antigo: 'dado-em-texto-777' })
    expect(ls().getItem(vault.LEGACY_KEY)).toBeNull()
    expect(allText()).not.toContain('dado-em-texto-777')
  })

  it('troca a senha preservando os dados', async () => {
    await vault.createUser('Maria', 'senha-segura-1')
    await vault.saveData({ x: 1 })
    expect((await vault.changePassword('errada-errada', 'nova-senha-123')).ok).toBe(false)
    expect((await vault.changePassword('senha-segura-1', 'nova-senha-123')).ok).toBe(true)
    await vault.saveData({ x: 2 })
    vault.logout()
    expect((await vault.login('Maria', 'senha-segura-1')).ok).toBe(false)
    const l = await vault.login('Maria', 'nova-senha-123')
    expect(l.ok && l.session.initialRaw).toEqual({ x: 2 })
  })

  it('exclui a conta e todos os dados dela', async () => {
    await vault.createUser('Maria', 'senha-segura-1')
    await vault.saveData({ x: 1 })
    expect((await vault.deleteAccount('errada-errada')).ok).toBe(false)
    expect((await vault.deleteAccount('senha-segura-1')).ok).toBe(true)
    expect(vault.hasUsers()).toBe(false)
    expect(allText()).not.toContain('meu-controle:v1:u:')
  })

  it('valida usuário e senha novos', () => {
    expect(vault.validateNewCredentials('ab', 'senha-segura-1', 'senha-segura-1')).toContain('3 caracteres')
    expect(vault.validateNewCredentials('maria', 'curta', 'curta')).toContain('8 caracteres')
    expect(vault.validateNewCredentials('maria', 'senha-segura-1', 'outra-coisa-12')).toContain('não conferem')
    expect(vault.validateNewCredentials('maria', 'senha-segura-1', 'senha-segura-1')).toBeNull()
  })
})
