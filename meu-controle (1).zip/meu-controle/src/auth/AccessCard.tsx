import { useState } from 'react'
import { LogOut, Trash2 } from 'lucide-react'
import { useApp } from '../store/store'
import { useAuth } from './context'
import { MIN_PASSWORD } from './vault'
import { Button, Card, Field, Input, Modal, Notice } from '../components/ui'

/** Configurações → Dados e backup: usuário, trocar senha e excluir conta. */
export function AccessCard() {
  const { name, logout, changePassword, deleteAccount } = useAuth()
  const { notify } = useApp()
  const [oldPw, setOldPw] = useState('')
  const [newPw, setNewPw] = useState('')
  const [confirmPw, setConfirmPw] = useState('')
  const [err, setErr] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [delOpen, setDelOpen] = useState(false)
  const [delPw, setDelPw] = useState('')
  const [delErr, setDelErr] = useState<string | null>(null)

  const submit = async () => {
    setErr(null)
    if (newPw.length < MIN_PASSWORD) return setErr(`A nova senha precisa ter pelo menos ${MIN_PASSWORD} caracteres.`)
    if (newPw !== confirmPw) return setErr('As senhas novas não conferem.')
    if (newPw === oldPw) return setErr('A nova senha precisa ser diferente da atual.')
    setBusy(true)
    const r = await changePassword(oldPw, newPw)
    setBusy(false)
    if (r.ok) {
      setOldPw('')
      setNewPw('')
      setConfirmPw('')
      notify('Senha alterada. Seus dados foram protegidos com a nova senha.')
    } else setErr(r.error)
  }

  const remove = async () => {
    setDelErr(null)
    setBusy(true)
    const r = await deleteAccount(delPw)
    setBusy(false)
    if (!r.ok) setDelErr(r.error)
  }

  return (
    <>
      <Card title="Acesso e senha" subtitle={`Usuário: ${name}`}>
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Senha atual">
            <Input type="password" value={oldPw} onChange={(e) => setOldPw(e.target.value)} autoComplete="current-password" />
          </Field>
          <Field label="Nova senha">
            <Input type="password" value={newPw} onChange={(e) => setNewPw(e.target.value)} autoComplete="new-password" />
          </Field>
          <Field label="Repita a nova senha">
            <Input type="password" value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)} autoComplete="new-password" />
          </Field>
        </div>
        {err && (
          <Notice tone="danger" className="mt-3">
            {err}
          </Notice>
        )}
        <div className="mt-3 flex flex-wrap gap-2">
          <Button onClick={submit} disabled={busy || !oldPw || !newPw || !confirmPw}>
            {busy ? 'Aguarde…' : 'Alterar senha'}
          </Button>
          <Button variant="secondary" onClick={logout}>
            <LogOut size={16} /> Sair
          </Button>
          <Button
            variant="danger"
            onClick={() => {
              setDelPw('')
              setDelErr(null)
              setDelOpen(true)
            }}
          >
            <Trash2 size={16} /> Excluir minha conta
          </Button>
        </div>
        <p className="mt-3 text-xs text-gray-500">O bloqueio é automático após 15 minutos sem uso. Não existe recuperação de senha: sem ela, os dados não podem ser abertos.</p>
      </Card>

      <Modal
        open={delOpen}
        onClose={() => setDelOpen(false)}
        title="Excluir minha conta"
        footer={
          <>
            <Button variant="secondary" onClick={() => setDelOpen(false)}>
              Cancelar
            </Button>
            <Button variant="danger" disabled={busy || !delPw} onClick={remove}>
              Excluir definitivamente
            </Button>
          </>
        }
      >
        <div className="space-y-3">
          <Notice tone="danger">Isso apaga o usuário e todos os dados dele neste navegador. Não pode ser desfeito. Exporte um backup antes, se quiser guardar algo.</Notice>
          <Field label="Digite sua senha para confirmar" error={delErr}>
            <Input type="password" value={delPw} onChange={(e) => setDelPw(e.target.value)} autoComplete="current-password" invalid={!!delErr} />
          </Field>
        </div>
      </Modal>
    </>
  )
}
