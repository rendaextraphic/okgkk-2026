import { useCallback, useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { Eye, EyeOff, Lock, ShieldCheck } from 'lucide-react'
import { AuthContext, type AuthCtx } from './context'
import * as vault from './vault'
import { cryptoAvailable } from '../lib/crypto'
import { Button, Field, Input, Notice } from '../components/ui'

/** Tempo sem uso até bloquear sozinho (minutos). */
const IDLE_MINUTES = 15

function PasswordInput({
  value,
  onChange,
  autoComplete,
  invalid,
  id,
}: {
  value: string
  onChange: (v: string) => void
  autoComplete: string
  invalid?: boolean
  id?: string
}) {
  const [show, setShow] = useState(false)
  return (
    <div className="relative">
      <Input
        id={id}
        type={show ? 'text' : 'password'}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        autoComplete={autoComplete}
        invalid={invalid}
        className="pr-10"
      />
      <button
        type="button"
        onClick={() => setShow((s) => !s)}
        aria-label={show ? 'Ocultar senha' : 'Mostrar senha'}
        className="absolute inset-y-0 right-0 flex w-10 items-center justify-center text-gray-400 hover:text-gray-700"
      >
        {show ? <EyeOff size={16} /> : <Eye size={16} />}
      </button>
    </div>
  )
}

function LoginScreen({ onSession, notice }: { onSession: (s: vault.Session) => void; notice?: string | null }) {
  const firstTime = useMemo(() => !vault.hasUsers(), [])
  const legacy = useMemo(() => firstTime && vault.hasLegacyData(), [firstTime])
  const [mode, setMode] = useState<'entrar' | 'criar'>(firstTime ? 'criar' : 'entrar')
  const [name, setName] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const switchMode = (m: 'entrar' | 'criar') => {
    setMode(m)
    setError(null)
    setPassword('')
    setConfirm('')
  }

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    if (busy) return
    setError(null)
    if (mode === 'criar') {
      const problem = vault.validateNewCredentials(name, password, confirm)
      if (problem) return setError(problem)
    } else if (!name.trim() || !password) {
      return setError('Informe usuário e senha.')
    }
    setBusy(true)
    try {
      const r = mode === 'criar' ? await vault.createUser(name, password) : await vault.login(name, password)
      if (r.ok) onSession(r.session)
      else setError(r.error)
    } catch {
      setError('Não foi possível concluir. Tente novamente.')
    } finally {
      setBusy(false)
      setPassword('')
      setConfirm('')
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="mb-6 flex flex-col items-center text-center">
          <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-accent text-white">
            <Lock size={22} aria-hidden />
          </div>
          <h1 className="text-xl font-semibold tracking-tight text-gray-900">Meu Controle</h1>
          <p className="mt-1 text-sm text-gray-500">{mode === 'criar' ? 'Crie seu acesso para proteger seus dados' : 'Entre para ver seus dados'}</p>
        </div>

        <form onSubmit={submit} className="card space-y-4 p-5" noValidate>
          {notice && <Notice tone="info">{notice}</Notice>}
          {legacy && mode === 'criar' && (
            <Notice tone="warn">Encontramos dados já salvos neste navegador, sem proteção. Ao criar o acesso, eles serão trancados com a sua senha.</Notice>
          )}

          <Field label="Usuário">
            <Input value={name} onChange={(e) => setName(e.target.value)} autoComplete="username" autoCapitalize="none" autoFocus maxLength={40} />
          </Field>
          <Field label="Senha" hint={mode === 'criar' ? 'Mínimo de 8 caracteres. Use uma frase ou misture letras e números.' : undefined}>
            <PasswordInput value={password} onChange={setPassword} autoComplete={mode === 'criar' ? 'new-password' : 'current-password'} />
          </Field>
          {mode === 'criar' && (
            <Field label="Repita a senha">
              <PasswordInput value={confirm} onChange={setConfirm} autoComplete="new-password" />
            </Field>
          )}

          {mode === 'criar' && (
            <Notice tone="warn">
              <strong>Não há “esqueci a senha”.</strong> Os dados são criptografados com ela; se perdê-la, ninguém consegue recuperá-los. Guarde a senha e faça backups.
            </Notice>
          )}
          {error && <Notice tone="danger">{error}</Notice>}

          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? 'Verificando…' : mode === 'criar' ? 'Criar acesso' : 'Entrar'}
          </Button>
        </form>

        <p className="mt-4 text-center text-sm text-gray-500">
          {mode === 'entrar' ? (
            <>
              Primeira vez neste navegador?{' '}
              <button type="button" className="font-medium text-gray-900 underline" onClick={() => switchMode('criar')}>
                Criar acesso
              </button>
            </>
          ) : (
            !firstTime && (
              <>
                Já tem acesso?{' '}
                <button type="button" className="font-medium text-gray-900 underline" onClick={() => switchMode('entrar')}>
                  Entrar
                </button>
              </>
            )
          )}
        </p>
        <p className="mt-6 flex items-start justify-center gap-1.5 text-center text-xs text-gray-400">
          <ShieldCheck size={13} className="mt-0.5 shrink-0" aria-hidden />
          Seus dados ficam só neste aparelho, criptografados com a sua senha.
        </p>
      </div>
    </div>
  )
}

export function AuthGate({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<vault.Session | null>(null)
  const [notice, setNotice] = useState<string | null>(null)

  const logout = useCallback((message?: string) => {
    vault.logout()
    setSession(null)
    setNotice(message ?? null)
  }, [])

  // Bloqueio automático por inatividade (conta o tempo mesmo com a aba em segundo plano)
  useEffect(() => {
    if (!session) return
    let last = Date.now()
    const touch = () => {
      last = Date.now()
    }
    const check = () => {
      if (Date.now() - last > IDLE_MINUTES * 60_000) logout(`Sessão bloqueada após ${IDLE_MINUTES} minutos sem uso.`)
    }
    const events = ['pointerdown', 'keydown', 'scroll', 'touchstart'] as const
    events.forEach((ev) => window.addEventListener(ev, touch, { passive: true }))
    const onVisible = () => {
      if (document.visibilityState === 'visible') check()
    }
    document.addEventListener('visibilitychange', onVisible)
    const id = setInterval(check, 15_000)
    return () => {
      events.forEach((ev) => window.removeEventListener(ev, touch))
      document.removeEventListener('visibilitychange', onVisible)
      clearInterval(id)
    }
  }, [session, logout])

  const ctx = useMemo<AuthCtx | null>(
    () =>
      session
        ? {
            name: session.name,
            initialRaw: session.initialRaw,
            logout: () => logout(),
            changePassword: (o, n) => vault.changePassword(o, n),
            deleteAccount: async (p) => {
              const r = await vault.deleteAccount(p)
              if (r.ok) logout('Conta excluída.')
              return r
            },
          }
        : null,
    [session, logout],
  )

  if (!cryptoAvailable()) {
    return (
      <div className="flex min-h-screen items-center justify-center px-4">
        <Notice tone="danger" className="max-w-md">
          Este navegador não oferece criptografia segura. Abra o site por um endereço <strong>https://</strong> (ou localhost) em um navegador atualizado.
        </Notice>
      </div>
    )
  }

  if (!session || !ctx) {
    return (
      <LoginScreen
        onSession={(s) => {
          setNotice(null)
          setSession(s)
        }}
        notice={notice}
      />
    )
  }
  // key = id: trocar de conta recria todo o app (nada do usuário anterior fica na memória)
  return (
    <AuthContext.Provider value={ctx} key={session.id}>
      {children}
    </AuthContext.Provider>
  )
}
