import { createContext, useContext } from 'react'

export interface AuthCtx {
  /** Nome do usuário logado. */
  name: string
  /** Dados já descriptografados na hora do login (ou null em conta nova). */
  initialRaw: unknown | null
  logout: () => void
  changePassword: (oldPassword: string, newPassword: string) => Promise<{ ok: true } | { ok: false; error: string }>
  deleteAccount: (password: string) => Promise<{ ok: true } | { ok: false; error: string }>
}

export const AuthContext = createContext<AuthCtx | null>(null)

export function useAuth(): AuthCtx {
  const c = useContext(AuthContext)
  if (!c) throw new Error('useAuth deve ser usado dentro de <AuthGate>')
  return c
}
