/**
 * Cofre de usuários: contas locais + dados criptografados por usuário.
 *
 * - Nenhum nome de usuário é gravado em texto: o registro usa o hash do nome.
 * - Cada conta tem sal próprio; a senha nunca é gravada. Para validar o login,
 *   tenta-se abrir um valor de verificação criptografado.
 * - Os dados de cada conta ficam em uma chave própria do LocalStorage, cifrados.
 */
import { DEFAULT_ITERATIONS, deriveKey, fromB64, open, randomBytes, seal, sha256Hex, toB64 } from '../lib/crypto'

export const LEGACY_KEY = 'meu-controle:v1'
const USERS_KEY = 'meu-controle:users:v1'
const DATA_PREFIX = 'meu-controle:v1:u:'
const LOCK_PREFIX = 'meu-controle:lock:'
const CHECK_VALUE = 'meu-controle-ok'

export const MIN_PASSWORD = 8

let iterations = DEFAULT_ITERATIONS
/** Só para testes: reduz o custo do PBKDF2. */
export function _setIterationsForTests(n: number) {
  iterations = n
}

interface UserRecord {
  id: string
  salt: string
  iter: number
  check: string
  createdAt: string
}

export interface Session {
  id: string
  name: string
  /** Dados já descriptografados (ou null em conta nova). */
  initialRaw: unknown | null
}

interface Active {
  id: string
  name: string
  key: CryptoKey
}

let active: Active | null = null
let queue: Promise<unknown> = Promise.resolve()

/** Executa as operações de gravação uma de cada vez (evita corrida ao trocar a senha). */
function enqueue<T>(fn: () => Promise<T>): Promise<T> {
  const run = queue.then(fn, fn)
  queue = run.catch(() => undefined)
  return run
}

const normalize = (name: string) => name.trim().normalize('NFKC').toLowerCase()
const userId = async (name: string) => (await sha256Hex(`meu-controle|${normalize(name)}`)).slice(0, 32)
export const dataKeyFor = (id: string) => `${DATA_PREFIX}${id}`

function readUsers(): UserRecord[] {
  try {
    const raw = localStorage.getItem(USERS_KEY)
    const list = raw ? JSON.parse(raw) : []
    return Array.isArray(list) ? list : []
  } catch {
    return []
  }
}
const writeUsers = (list: UserRecord[]) => localStorage.setItem(USERS_KEY, JSON.stringify(list))

export function hasUsers(): boolean {
  return readUsers().length > 0
}
export function hasLegacyData(): boolean {
  try {
    return !!localStorage.getItem(LEGACY_KEY)
  } catch {
    return false
  }
}
export function activeDataKey(): string | null {
  return active ? dataKeyFor(active.id) : null
}

/* Proteção contra tentativas em sequência ---------------------------- */

interface Lock {
  count: number
  until: number
}
function readLock(id: string): Lock {
  try {
    const l = JSON.parse(localStorage.getItem(LOCK_PREFIX + id) || 'null')
    if (l && typeof l.count === 'number' && typeof l.until === 'number') return l
  } catch {
    /* ignora */
  }
  return { count: 0, until: 0 }
}
/** Segundos restantes de bloqueio (0 = liberado). */
export async function lockSecondsLeft(name: string): Promise<number> {
  const l = readLock(await userId(name))
  return Math.max(0, Math.ceil((l.until - Date.now()) / 1000))
}
function registerFailure(id: string) {
  const l = readLock(id)
  const count = l.count + 1
  // a partir da 5ª tentativa errada: 15s, 30s, 60s... até 15 min
  const wait = count >= 5 ? Math.min(15 * 60, 15 * 2 ** (count - 5)) : 0
  localStorage.setItem(LOCK_PREFIX + id, JSON.stringify({ count, until: wait ? Date.now() + wait * 1000 : 0 }))
}
const clearFailures = (id: string) => localStorage.removeItem(LOCK_PREFIX + id)

/* Contas ---------------------------------------------------------------- */

export type AuthResult = { ok: true; session: Session } | { ok: false; error: string }

export function validateNewCredentials(name: string, password: string, confirm: string): string | null {
  if (name.trim().length < 3) return 'O usuário precisa ter pelo menos 3 caracteres.'
  if (name.trim().length > 40) return 'O usuário pode ter no máximo 40 caracteres.'
  if (password.length < MIN_PASSWORD) return `A senha precisa ter pelo menos ${MIN_PASSWORD} caracteres.`
  if (password.length > 200) return 'A senha é muito longa.'
  if (normalize(password) === normalize(name)) return 'A senha não pode ser igual ao usuário.'
  if (password !== confirm) return 'As senhas não conferem.'
  return null
}

export async function createUser(name: string, password: string): Promise<AuthResult> {
  const id = await userId(name)
  const users = readUsers()
  if (users.some((u) => u.id === id)) return { ok: false, error: 'Esse usuário já existe neste navegador.' }

  const salt = randomBytes(16)
  const key = await deriveKey(password, salt, iterations)
  const rec: UserRecord = { id, salt: toB64(salt), iter: iterations, check: await seal(key, CHECK_VALUE), createdAt: new Date().toISOString() }

  // Primeira conta: protege os dados antigos (sem senha) que já estavam neste navegador.
  let initialRaw: unknown | null = null
  let migrated = false
  if (users.length === 0 && hasLegacyData()) {
    try {
      initialRaw = JSON.parse(localStorage.getItem(LEGACY_KEY) as string)
      localStorage.setItem(dataKeyFor(id), await seal(key, initialRaw))
      // confirma que abre antes de apagar o original em texto
      await open(key, localStorage.getItem(dataKeyFor(id)) as string)
      migrated = true
    } catch {
      initialRaw = null
    }
  }

  writeUsers([...users, rec])
  if (migrated) {
    localStorage.removeItem(LEGACY_KEY)
    for (let i = localStorage.length - 1; i >= 0; i--) {
      const k = localStorage.key(i)
      if (k && k.startsWith(`${LEGACY_KEY}:corrompido:`)) localStorage.removeItem(k)
    }
  }
  active = { id, name: name.trim(), key }
  return { ok: true, session: { id, name: name.trim(), initialRaw } }
}

const GENERIC_FAIL = 'Usuário ou senha incorretos.'

export async function login(name: string, password: string): Promise<AuthResult> {
  const id = await userId(name)
  const wait = readLock(id).until - Date.now()
  if (wait > 0) return { ok: false, error: `Muitas tentativas. Aguarde ${Math.ceil(wait / 1000)} s para tentar de novo.` }

  const rec = readUsers().find((u) => u.id === id)
  if (!rec) {
    // gasta o mesmo tempo para não revelar se o usuário existe
    await deriveKey(password, randomBytes(16), iterations)
    registerFailure(id)
    return { ok: false, error: GENERIC_FAIL }
  }
  const key = await deriveKey(password, fromB64(rec.salt), rec.iter)
  try {
    if ((await open<string>(key, rec.check)) !== CHECK_VALUE) throw new Error('check')
  } catch {
    registerFailure(id)
    return { ok: false, error: GENERIC_FAIL }
  }

  let initialRaw: unknown | null = null
  const stored = localStorage.getItem(dataKeyFor(id))
  if (stored) {
    try {
      initialRaw = await open(key, stored)
    } catch {
      return { ok: false, error: 'Os dados desta conta estão danificados e não puderam ser abertos.' }
    }
  }
  clearFailures(id)
  active = { id, name: name.trim(), key }
  return { ok: true, session: { id, name: name.trim(), initialRaw } }
}

export function logout() {
  active = null
}

/* Dados da sessão ativa --------------------------------------------------- */

/** Grava (criptografado) os dados da sessão ativa. Lança erro se não for possível. */
export function saveData(data: unknown): Promise<void> {
  return enqueue(async () => {
    const a = active
    if (!a) throw new Error('sem sessão')
    localStorage.setItem(dataKeyFor(a.id), await seal(a.key, data))
  })
}

/** Abre um valor vindo de outra aba (evento "storage"). Retorna null se não for possível. */
export async function openExternal(sealed: string): Promise<unknown | null> {
  if (!active) return null
  try {
    return await open(active.key, sealed)
  } catch {
    return null
  }
}

/** Guarda (criptografada) uma cópia de dados ilegíveis para não perdê-los. */
export function saveCorruptedCopy(raw: unknown): Promise<void> {
  return enqueue(async () => {
    if (!active) return
    localStorage.setItem(`${dataKeyFor(active.id)}:corrompido:${Date.now()}`, await seal(active.key, raw))
  })
}

export async function changePassword(oldPassword: string, newPassword: string): Promise<{ ok: true } | { ok: false; error: string }> {
  if (!active) return { ok: false, error: 'Sessão encerrada.' }
  const { id } = active
  const rec = readUsers().find((u) => u.id === id)
  if (!rec) return { ok: false, error: 'Conta não encontrada.' }
  try {
    const oldKey = await deriveKey(oldPassword, fromB64(rec.salt), rec.iter)
    if ((await open<string>(oldKey, rec.check)) !== CHECK_VALUE) throw new Error('check')
  } catch {
    return { ok: false, error: 'Senha atual incorreta.' }
  }
  const salt = randomBytes(16)
  const newKey = await deriveKey(newPassword, salt, iterations)
  const newRec: UserRecord = { ...rec, salt: toB64(salt), iter: iterations, check: await seal(newKey, CHECK_VALUE) }
  try {
    await enqueue(async () => {
      if (!active || active.id !== id) throw new Error('sessão mudou')
      // recifra os dados e as cópias de segurança com a nova chave, antes de trocar o registro
      const prefix = dataKeyFor(id)
      const writes: [string, string][] = []
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i)
        if (!k || (k !== prefix && !k.startsWith(`${prefix}:corrompido:`))) continue
        const v = localStorage.getItem(k)
        if (v) writes.push([k, await seal(newKey, await open(active.key, v))])
      }
      for (const [k, v] of writes) localStorage.setItem(k, v)
      writeUsers(readUsers().map((u) => (u.id === id ? newRec : u)))
      active = { ...active, key: newKey }
    })
  } catch {
    return { ok: false, error: 'Não foi possível trocar a senha. Nada foi alterado.' }
  }
  return { ok: true }
}

/** Exclui a conta ativa e todos os dados dela (exige a senha). */
export async function deleteAccount(password: string): Promise<{ ok: true } | { ok: false; error: string }> {
  if (!active) return { ok: false, error: 'Sessão encerrada.' }
  const { id } = active
  const rec = readUsers().find((u) => u.id === id)
  if (!rec) return { ok: false, error: 'Conta não encontrada.' }
  try {
    const k = await deriveKey(password, fromB64(rec.salt), rec.iter)
    if ((await open<string>(k, rec.check)) !== CHECK_VALUE) throw new Error('check')
  } catch {
    return { ok: false, error: 'Senha incorreta.' }
  }
  await enqueue(async () => {
    const prefix = dataKeyFor(id)
    for (let i = localStorage.length - 1; i >= 0; i--) {
      const k = localStorage.key(i)
      if (k && (k === prefix || k.startsWith(`${prefix}:`))) localStorage.removeItem(k)
    }
    writeUsers(readUsers().filter((u) => u.id !== id))
    clearFailures(id)
    active = null
  })
  return { ok: true }
}
