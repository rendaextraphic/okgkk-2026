import { useMemo, useState } from 'react'
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { ChevronLeft, ChevronRight, Pencil, PiggyBank, Plus, Target, Trash2 } from 'lucide-react'
import { useApp } from '../store/store'
import type { Goal } from '../types'
import { buildAlerts, computePayroll, effectivePayroll, expensesInRange, extraIncome, isFixedExpense, monthSummary, sum, totalsByCategory } from '../lib/calc'
import { addMonthKey, daysBetween, monthLabel, monthRange } from '../lib/dates'
import { brl, formatDate, parseNumber, pct } from '../lib/format'
import { Badge, Button, Card, ConfirmDialog, EmptyState, Field, Input, Modal, Notice, PageHeader, ProgressBar, Stat, Table, Textarea } from '../components/ui'
import { axisMoney, ChartBox, COLORS, MoneyTooltip } from '../components/charts'

export function Planejamento() {
  const { data, actions, today, notify } = useApp()
  const [month, setMonth] = useState(today.slice(0, 7))
  const [goalEdit, setGoalEdit] = useState<Goal | 'new' | null>(null)
  const [goalDel, setGoalDel] = useState<Goal | null>(null)
  const [depositGoal, setDepositGoal] = useState<Goal | null>(null)

  const s = data.settings
  const range = monthRange(month)
  const sum_ = useMemo(() => monthSummary(data, month, today), [data, month, today])
  const eff = useMemo(() => effectivePayroll(data, month), [data, month])
  const calc = useMemo(() => computePayroll(data, month), [data, month])
  const alerts = useMemo(() => buildAlerts(data, month, today, brl), [data, month, today])
  const list = useMemo(() => expensesInRange(data.expenses, range), [data.expenses, month])
  const fixed = sum(list.filter(isFixedExpense).map((e) => e.amount))
  const variable = sum(list.filter((e) => !isFixedExpense(e)).map((e) => e.amount))
  const extras = extraIncome(data.transactions, range)
  const commitments = sum_.outflow
  const available = Math.round((sum_.income - commitments - s.monthlyGoal) * 100) / 100
  const cats = useMemo(() => totalsByCategory(list), [list])
  const budgetRows = useMemo(
    () => {
      const names = [...new Set([...Object.keys(s.budgets).filter((c) => s.budgets[c] > 0), ...cats.map((c) => c.category)])]
      return names.map((c) => ({ category: c, spent: cats.find((x) => x.category === c)?.total ?? 0, budget: s.budgets[c] ?? 0 })).sort((a, b) => b.spent - a.spent)
    },
    [cats, s.budgets],
  )

  const chart = [
    { nome: 'Receitas', Valor: sum_.income, fill: COLORS.income },
    { nome: 'Despesas fixas', Valor: fixed, fill: COLORS.expense },
    { nome: 'Variáveis', Valor: variable, fill: '#c07a6b' },
    { nome: 'Dívidas', Valor: sum_.debtTotal, fill: '#7f2d20' },
  ]

  return (
    <>
      <PageHeader
        title="Planejamento"
        subtitle="Visualize o mês, organize compromissos e acompanhe metas. O sistema apenas mostra números e sugestões: nada é movimentado ou pago automaticamente."
      />

      <div className="mb-5 flex flex-wrap items-center gap-2">
        <Button variant="secondary" size="sm" aria-label="Mês anterior" onClick={() => setMonth(addMonthKey(month, -1))}>
          <ChevronLeft size={15} />
        </Button>
        <Input type="month" aria-label="Mês" value={month} onChange={(e) => e.target.value && setMonth(e.target.value)} className="w-44 py-1.5" />
        <Button variant="secondary" size="sm" aria-label="Próximo mês" onClick={() => setMonth(addMonthKey(month, 1))}>
          <ChevronRight size={15} />
        </Button>
        <span className="text-sm font-medium capitalize text-gray-700">{monthLabel(month)}</span>
        <Badge tone={eff.confirmed ? 'income' : 'neutral'}>{eff.confirmed ? 'Salário confirmado' : 'Salário estimado'}</Badge>
      </div>

      {alerts.length > 0 ? (
        <div className="mb-5 space-y-2">
          {alerts.map((a, i) => (
            <Notice key={i} tone={a.level === 'danger' ? 'danger' : 'warn'}>
              {a.text}
            </Notice>
          ))}
        </div>
      ) : (
        <Notice tone="ok" className="mb-5">
          Nenhum alerta para {monthLabel(month)}.
        </Notice>
      )}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Salário líquido estimado" tone="income" value={brl(eff.net)} hint={eff.confirmed ? 'Folha confirmada' : 'Estimativa'} />
        <Stat label="Produtividade prevista" value={brl(calc.productionEligible)} hint={calc.productionPending ? `Pendente ${brl(calc.productionPending)}` : 'Já incluída no salário'} />
        <Stat label="Receitas extras" tone="income" value={brl(extras)} />
        <Stat label="Total de receitas" tone="income" value={brl(sum_.income)} />
        <Stat label="Despesas fixas" tone="expense" value={brl(fixed)} hint="Recorrentes" />
        <Stat label="Despesas variáveis" tone="expense" value={brl(variable)} hint="Únicas e parceladas" />
        <Stat label="Parcelas de dívidas" tone="expense" value={brl(sum_.debtTotal)} hint={`Pago ${brl(sum_.debtPaid)} · a vencer ${brl(sum_.debtPending)}`} />
        <Stat label="Total de compromissos" tone="expense" value={brl(commitments)} />
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-3">
        <Card title="Saldo previsto">
          <p className={`num text-3xl font-semibold ${sum_.balance >= 0 ? 'text-income' : 'text-expense'}`}>{brl(sum_.balance)}</p>
          <p className="mt-1 text-xs text-gray-500">Receitas menos compromissos do mês.</p>
          <dl className="num mt-4 space-y-1.5 text-sm">
            <div className="flex justify-between">
              <dt className="text-gray-500">Meta de economia</dt>
              <dd className="font-medium">{s.monthlyGoal > 0 ? brl(s.monthlyGoal) : 'não definida'}</dd>
            </div>
            <div className="flex justify-between border-t border-gray-100 pt-1.5">
              <dt className="text-gray-500">Disponível para gastos</dt>
              <dd className={`font-semibold ${available >= 0 ? 'text-gray-900' : 'text-expense'}`}>{brl(available)}</dd>
            </div>
          </dl>
          {s.monthlyGoal > 0 && (
            <div className="mt-4">
              <ProgressBar value={(Math.max(0, sum_.balance) / s.monthlyGoal) * 100} tone={sum_.balance >= s.monthlyGoal ? 'income' : 'warn'} label="Progresso da meta mensal" />
              <p className="mt-1 text-xs text-gray-500">
                {sum_.balance >= s.monthlyGoal ? 'Meta mensal atingida pelo saldo previsto.' : `Faltam ${brl(s.monthlyGoal - Math.max(0, sum_.balance))} para a meta.`}
              </p>
            </div>
          )}
          <p className="mt-3 text-xs text-gray-500">A meta é definida em Configurações.</p>
        </Card>

        <Card title="Salário comprometido">
          <p className="num text-3xl font-semibold">{sum_.salaryNet > 0 ? pct(sum_.committedPct, 0) : '—'}</p>
          <div className="mt-3">
            <ProgressBar value={sum_.committedPct} tone={sum_.committedPct >= 100 ? 'expense' : sum_.committedPct >= 70 ? 'warn' : 'neutral'} label="Percentual do salário comprometido" />
          </div>
          <p className="mt-2 text-xs text-gray-500">
            {brl(commitments)} de {brl(sum_.salaryNet)} do salário líquido.
          </p>
        </Card>

        <Card title="Distribuição do mês" subtitle="Receitas e compromissos">
          <ChartBox height={170}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart} layout="vertical" margin={{ top: 0, right: 8, left: 8, bottom: 0 }}>
                <CartesianGrid horizontal={false} stroke="#eef0f2" />
                <XAxis type="number" tickFormatter={axisMoney} tickLine={false} axisLine={false} />
                <YAxis type="category" dataKey="nome" width={92} tickLine={false} axisLine={false} />
                <Tooltip content={<MoneyTooltip />} cursor={{ fill: 'rgba(17,24,39,0.04)' }} />
                <Bar dataKey="Valor" radius={[0, 4, 4, 0]} maxBarSize={18}>
                  {chart.map((c, i) => (
                    <Cell key={i} fill={c.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartBox>
        </Card>
      </div>

      <Card title="Orçamento por categoria" subtitle="Defina limites em Configurações → Orçamentos" className="mt-5" pad={false}>
        {budgetRows.length === 0 ? (
          <p className="p-5 text-sm text-gray-500">Sem despesas neste mês e sem orçamentos definidos.</p>
        ) : (
          <Table head={['Categoria', { label: 'Gasto previsto', className: 'text-right' }, { label: 'Orçamento', className: 'text-right' }, 'Uso']}>
            {budgetRows.map((r) => {
              const ratio = r.budget > 0 ? (r.spent / r.budget) * 100 : 0
              return (
                <tr key={r.category}>
                  <td className="td font-medium">{r.category}</td>
                  <td className={`td num text-right ${r.budget > 0 && r.spent > r.budget ? 'font-medium text-expense' : ''}`}>{brl(r.spent)}</td>
                  <td className="td num text-right text-gray-500">{r.budget > 0 ? brl(r.budget) : '—'}</td>
                  <td className="td min-w-[9rem]">
                    {r.budget > 0 ? (
                      <div className="flex items-center gap-2">
                        <ProgressBar value={ratio} tone={ratio > 100 ? 'expense' : ratio >= 80 ? 'warn' : 'income'} label={`${r.category}: ${pct(ratio)} do orçamento`} />
                        <span className="num w-12 text-right text-xs text-gray-500">{pct(ratio)}</span>
                      </div>
                    ) : (
                      <span className="text-xs text-gray-400">sem limite</span>
                    )}
                  </td>
                </tr>
              )
            })}
          </Table>
        )}
      </Card>

      <Card title="Sugestões de organização" subtitle="Baseadas nos seus números. São apenas ideias de visualização, sem execução automática." className="mt-5">
        <Suggestions month={month} />
      </Card>

      <div className="mt-8 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Metas financeiras</h2>
          <p className="text-sm text-gray-500">Guarde um valor até uma data. Você atualiza o quanto já separou.</p>
        </div>
        <Button onClick={() => setGoalEdit('new')}>
          <Plus size={16} /> Nova meta
        </Button>
      </div>

      <div className="mt-3">
        {data.goals.length === 0 ? (
          <EmptyState icon={<Target size={20} />} title="Nenhuma meta criada" text="Ex.: reserva de emergência de R$ 3.000 até dezembro." action={<Button onClick={() => setGoalEdit('new')}>Criar meta</Button>} />
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {data.goals.map((g) => {
              const ratio = g.target > 0 ? (g.saved / g.target) * 100 : 0
              const left = Math.max(0, g.target - g.saved)
              const days = g.deadline ? daysBetween(today, g.deadline) : null
              const monthsLeft = days === null ? null : Math.max(1, Math.ceil(days / 30))
              const done = g.saved >= g.target
              return (
                <Card key={g.id}>
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <h3 className="truncate font-semibold text-gray-900">{g.name}</h3>
                      <p className="text-xs text-gray-500">{g.deadline ? `Até ${formatDate(g.deadline)}` : 'Sem prazo'}</p>
                    </div>
                    <Badge tone={done ? 'income' : days !== null && days < 0 ? 'expense' : 'neutral'}>{done ? 'Concluída' : days !== null && days < 0 ? 'Prazo vencido' : 'Em andamento'}</Badge>
                  </div>
                  <div className="num mt-3 flex items-end justify-between">
                    <p className="text-2xl font-semibold text-income">{brl(g.saved)}</p>
                    <p className="text-xs text-gray-500">de {brl(g.target)}</p>
                  </div>
                  <div className="mt-2">
                    <ProgressBar value={ratio} tone="income" label={`${g.name}: ${pct(ratio)}`} />
                    <p className="mt-1 text-xs text-gray-500">
                      {pct(Math.min(ratio, 100), 0)}
                      {!done && monthsLeft !== null && days! >= 0 && <> · guarde cerca de <span className="num font-medium">{brl(left / monthsLeft)}</span> por mês</>}
                    </p>
                  </div>
                  {g.notes && <p className="mt-2 text-xs text-gray-500">{g.notes}</p>}
                  <div className="mt-3 flex gap-2 border-t border-gray-100 pt-3">
                    <Button size="sm" onClick={() => setDepositGoal(g)}>
                      <PiggyBank size={14} /> Atualizar valor guardado
                    </Button>
                    <Button variant="secondary" size="sm" aria-label={`Editar ${g.name}`} onClick={() => setGoalEdit(g)}>
                      <Pencil size={14} />
                    </Button>
                    <Button variant="ghost" size="sm" aria-label={`Excluir ${g.name}`} onClick={() => setGoalDel(g)}>
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </Card>
              )
            })}
          </div>
        )}
      </div>

      <GoalForm goal={goalEdit} onClose={() => setGoalEdit(null)} />
      <DepositForm goal={depositGoal} onClose={() => setDepositGoal(null)} />
      <ConfirmDialog
        open={!!goalDel}
        danger
        title="Excluir meta"
        confirmLabel="Excluir"
        text={goalDel ? `Excluir a meta "${goalDel.name}"?` : ''}
        onClose={() => setGoalDel(null)}
        onConfirm={() => {
          if (goalDel) {
            actions.deleteGoal(goalDel.id)
            notify('Meta excluída.')
          }
        }}
      />
    </>
  )
}

function Suggestions({ month }: { month: string }) {
  const { data, today } = useApp()
  const range = monthRange(month)
  const s = monthSummary(data, month, today)
  const list = expensesInRange(data.expenses, range)
  const tips: string[] = []
  const upcoming = list.filter((e) => e.status === 'pendente').sort((a, b) => a.dueDate.localeCompare(b.dueDate))
  if (upcoming.length) {
    const top = [...upcoming].sort((a, b) => b.amount - a.amount)[0]
    tips.push(`A maior conta pendente do mês é "${top.name}" (${brl(top.amount)}, vence em ${formatDate(top.dueDate)}). Reserve esse valor primeiro.`)
  }
  const cats = totalsByCategory(list)
  if (cats[0] && s.outflow > 0) tips.push(`${cats[0].category} concentra ${pct((cats[0].total / s.outflow) * 100, 0)} dos compromissos do mês (${brl(cats[0].total)}).`)
  if (s.committedPct >= 70 && s.salaryNet > 0) tips.push(`${pct(s.committedPct, 0)} do salário líquido já está comprometido. Avalie adiar despesas variáveis ou renegociar parcelas.`)
  const hasPendingProd = data.productivity.length > 0 && data.settings.prodPayMode !== 'integral'
  if (hasPendingProd) tips.push('Parte da produtividade está marcada como pendente: ela só entra na folha quando o pagamento for confirmado.')
  if (data.settings.monthlyGoal > 0 && s.balance >= data.settings.monthlyGoal) tips.push('A meta de economia do mês está coberta pelo saldo previsto. Considere separar esse valor em uma meta.')
  if (!tips.length) tips.push('Cadastre despesas, dívidas e produtividade para receber sugestões baseadas nos seus números.')
  return (
    <ul className="space-y-2 text-sm text-gray-700">
      {tips.map((t, i) => (
        <li key={i} className="flex gap-2">
          <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-gray-400" aria-hidden />
          {t}
        </li>
      ))}
    </ul>
  )
}

function GoalForm({ goal, onClose }: { goal: Goal | 'new' | null; onClose: () => void }) {
  const { actions, notify } = useApp()
  const existing = goal && goal !== 'new' ? goal : null
  const [name, setName] = useState('')
  const [target, setTarget] = useState('')
  const [saved, setSaved] = useState('')
  const [deadline, setDeadline] = useState('')
  const [notes, setNotes] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [key, setKey] = useState<unknown>(null)
  if (goal !== key) {
    setKey(goal)
    if (goal) {
      setName(existing?.name ?? '')
      setTarget(existing ? String(existing.target).replace('.', ',') : '')
      setSaved(existing ? String(existing.saved).replace('.', ',') : '')
      setDeadline(existing?.deadline ?? '')
      setNotes(existing?.notes ?? '')
      setErrors({})
    }
  }
  const save = () => {
    const e: Record<string, string> = {}
    const t = parseNumber(target)
    const sv = saved.trim() ? parseNumber(saved) : 0
    if (!name.trim()) e.name = 'Informe o nome da meta.'
    if (!Number.isFinite(t) || t <= 0) e.target = 'Informe o valor da meta.'
    if (!Number.isFinite(sv) || sv < 0) e.saved = 'Valor inválido.'
    setErrors(e)
    if (Object.keys(e).length) return
    const payload = { name: name.trim(), target: t, saved: sv, deadline, notes: notes.trim() }
    if (existing) actions.updateGoal(existing.id, payload)
    else actions.addGoal(payload)
    notify(existing ? 'Meta atualizada.' : 'Meta criada.')
    onClose()
  }
  return (
    <Modal
      open={goal !== null}
      onClose={onClose}
      title={existing ? 'Editar meta' : 'Nova meta'}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={save}>Salvar</Button>
        </>
      }
    >
      <form
        className="grid gap-4 sm:grid-cols-2"
        noValidate
        onSubmit={(e) => {
          e.preventDefault()
          save()
        }}
      >
        <Field label="Nome da meta" error={errors.name} className="sm:col-span-2">
          <Input value={name} onChange={(e) => setName(e.target.value)} invalid={!!errors.name} maxLength={80} placeholder="Ex.: Reserva de emergência" />
        </Field>
        <Field label="Valor a guardar (R$)" error={errors.target}>
          <Input inputMode="decimal" value={target} onChange={(e) => setTarget(e.target.value)} invalid={!!errors.target} />
        </Field>
        <Field label="Já guardado (R$)" error={errors.saved}>
          <Input inputMode="decimal" value={saved} onChange={(e) => setSaved(e.target.value)} invalid={!!errors.saved} />
        </Field>
        <Field label="Prazo (opcional)" className="sm:col-span-2">
          <Input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} />
        </Field>
        <Field label="Observações" className="sm:col-span-2">
          <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} maxLength={300} />
        </Field>
        <button type="submit" className="hidden" aria-hidden tabIndex={-1} />
      </form>
    </Modal>
  )
}

function DepositForm({ goal, onClose }: { goal: Goal | null; onClose: () => void }) {
  const { actions, notify } = useApp()
  const [value, setValue] = useState('')
  const [err, setErr] = useState('')
  const [key, setKey] = useState<Goal | null>(null)
  if (goal !== key) {
    setKey(goal)
    if (goal) {
      setValue(String(goal.saved).replace('.', ','))
      setErr('')
    }
  }
  const save = () => {
    if (!goal) return
    const v = parseNumber(value)
    if (!Number.isFinite(v) || v < 0) return setErr('Informe um valor igual ou maior que zero.')
    actions.updateGoal(goal.id, { saved: v })
    notify('Valor guardado atualizado.')
    onClose()
  }
  return (
    <Modal
      open={!!goal}
      onClose={onClose}
      title="Atualizar valor guardado"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={save}>Salvar</Button>
        </>
      }
    >
      {goal && (
        <form
          className="space-y-3"
          noValidate
          onSubmit={(e) => {
            e.preventDefault()
            save()
          }}
        >
          <p className="text-sm text-gray-600">
            {goal.name} · meta <span className="num font-medium">{brl(goal.target)}</span>
          </p>
          <Field label="Total já guardado (R$)" error={err}>
            <Input inputMode="decimal" value={value} onChange={(e) => { setValue(e.target.value); setErr('') }} invalid={!!err} />
          </Field>
          <p className="text-xs text-gray-500">O valor da meta é apenas um controle. Para registrar a saída do dinheiro, lance uma transferência ou saída no livro-caixa.</p>
          <button type="submit" className="hidden" aria-hidden tabIndex={-1} />
        </form>
      )}
    </Modal>
  )
}
