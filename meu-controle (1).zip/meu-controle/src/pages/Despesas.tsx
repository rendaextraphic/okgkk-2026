import { useMemo, useState } from 'react'
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { Check, Pencil, Plus, Repeat, Search, Trash2, Undo2 } from 'lucide-react'
import { periodToRange, useApp, type Period } from '../store/store'
import type { Expense, ExpenseStatus, Recurrence } from '../types'
import { expenseStatus, expensesInRange, sum, totalsByCategory } from '../lib/calc'
import { monthLabel, monthRange, shortMonth, daysBetween } from '../lib/dates'
import { brl, formatDate, num, parseNumber, pct } from '../lib/format'
import { PAYMENT_METHODS } from '../lib/defaults'
import { Badge, Button, Card, ConfirmDialog, EmptyState, Field, Input, Modal, PageHeader, ProgressBar, Select, Stat, Table, Tabs, Textarea } from '../components/ui'
import { PeriodFilter } from '../components/PeriodFilter'
import { axisMoney, ChartBox, COLORS, MoneyTooltip } from '../components/charts'

const REC_LABEL: Record<Recurrence, string> = { unica: 'Única', semanal: 'Semanal', mensal: 'Mensal', anual: 'Anual' }

type StatusFilter = 'todas' | 'pendente' | 'paga' | 'atrasada'

export function Despesas() {
  const { data, actions, today, period: globalPeriod, notify } = useApp()
  const [period, setPeriod] = useState<Period>(globalPeriod)
  const range = periodToRange(period)
  const [category, setCategory] = useState('todas')
  const [status, setStatus] = useState<StatusFilter>('todas')
  const [query, setQuery] = useState('')
  const [tab, setTab] = useState<'lista' | 'futuras' | 'historico' | 'comparativo'>('lista')
  const [editing, setEditing] = useState<Expense | 'new' | null>(null)
  const [paying, setPaying] = useState<Expense | null>(null)
  const [deleting, setDeleting] = useState<Expense | null>(null)

  const all = data.expenses
  const inPeriod = useMemo(() => expensesInRange(all, range), [all, range.from, range.to])
  const filtered = useMemo(
    () =>
      inPeriod
        .filter((e) => (category === 'todas' || e.category === category) && (status === 'todas' || expenseStatus(e, today) === status) && (!query.trim() || e.name.toLowerCase().includes(query.trim().toLowerCase())))
        .sort((a, b) => a.dueDate.localeCompare(b.dueDate) || a.name.localeCompare(b.name)),
    [inPeriod, category, status, query, today],
  )

  const year = range.from.slice(0, 4)
  const yearList = useMemo(() => all.filter((e) => e.dueDate.startsWith(year)), [all, year])
  const k = useMemo(() => {
    const paid = sum(inPeriod.filter((e) => e.status === 'paga').map((e) => e.amount))
    const late = sum(inPeriod.filter((e) => expenseStatus(e, today) === 'atrasada').map((e) => e.amount))
    const total = sum(inPeriod.map((e) => e.amount))
    return { total, paid, late, open: Math.round((total - paid) * 100) / 100 }
  }, [inPeriod, today])

  const future = useMemo(
    () => all.filter((e) => e.status === 'pendente' && e.dueDate >= today).sort((a, b) => a.dueDate.localeCompare(b.dueDate)),
    [all, today],
  )
  const history = useMemo(
    () => all.filter((e) => e.status === 'paga' && e.paidDate >= range.from && e.paidDate <= range.to).sort((a, b) => b.paidDate.localeCompare(a.paidDate)),
    [all, range.from, range.to],
  )

  const byCategory = useMemo(() => {
    const planned = totalsByCategory(inPeriod)
    return planned.map((p) => {
      const paid = sum(inPeriod.filter((e) => e.category === p.category && e.status === 'paga').map((e) => e.amount))
      return { category: p.category, planned: p.total, paid, budget: data.settings.budgets[p.category] ?? 0 }
    })
  }, [inPeriod, data.settings.budgets])

  const monthly = useMemo(
    () =>
      Array.from({ length: 12 }, (_, i) => {
        const m = `${year}-${String(i + 1).padStart(2, '0')}`
        const list = expensesInRange(all, monthRange(m))
        const planned = sum(list.map((e) => e.amount))
        const paid = sum(list.filter((e) => e.status === 'paga').map((e) => e.amount))
        return { m, label: shortMonth(m), Planejado: planned, Realizado: paid, Pendente: Math.round((planned - paid) * 100) / 100 }
      }),
    [all, year],
  )

  const catOptions = data.settings.expenseCategories

  const renderRow = (e: Expense, showPaid = false) => {
    const st = expenseStatus(e, today)
    return (
      <tr key={e.id} className="hover:bg-gray-50/60">
        <td className="td num whitespace-nowrap">{formatDate(e.dueDate)}</td>
        <td className="td">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="font-medium text-gray-900">{e.name}</span>
            {e.recurrence !== 'unica' && (
              <Badge tone="info">
                <Repeat size={10} aria-hidden /> {REC_LABEL[e.recurrence]}
              </Badge>
            )}
            {e.installment && <Badge>{`${e.installment.n}/${e.installment.of}`}</Badge>}
          </div>
          {e.notes && <p className="max-w-xs truncate text-xs text-gray-500">{e.notes}</p>}
        </td>
        <td className="td text-gray-600">{e.category}</td>
        <td className="td num text-right font-medium text-expense">{brl(e.amount)}</td>
        <td className="td">
          <Badge tone={st === 'paga' ? 'income' : st === 'atrasada' ? 'expense' : 'neutral'}>{st === 'paga' ? 'Paga' : st === 'atrasada' ? 'Atrasada' : 'Pendente'}</Badge>
        </td>
        {showPaid && <td className="td num">{formatDate(e.paidDate)}</td>}
        <td className="td whitespace-nowrap text-right">
          {e.status === 'pendente' ? (
            <Button variant="secondary" size="sm" onClick={() => setPaying(e)} aria-label={`Marcar ${e.name} como paga`}>
              <Check size={14} /> Pagar
            </Button>
          ) : (
            <Button
              variant="ghost"
              size="sm"
              aria-label={`Desfazer pagamento de ${e.name}`}
              onClick={() => {
                actions.unpayExpense(e.id)
                notify('Pagamento desfeito e lançamento removido do livro-caixa.', 'info')
              }}
            >
              <Undo2 size={14} />
            </Button>
          )}
          <Button variant="ghost" size="sm" aria-label={`Editar ${e.name}`} onClick={() => setEditing(e)}>
            <Pencil size={14} />
          </Button>
          <Button variant="ghost" size="sm" aria-label={`Excluir ${e.name}`} onClick={() => setDeleting(e)}>
            <Trash2 size={14} />
          </Button>
        </td>
      </tr>
    )
  }

  const baseHead = ['Vencimento', 'Despesa', 'Categoria', { label: 'Valor', className: 'text-right' }, 'Status']

  return (
    <>
      <PageHeader
        title="Despesas"
        subtitle="Contas únicas, recorrentes e parceladas. Ao marcar como paga, a saída entra no livro-caixa uma única vez."
        actions={
          <Button onClick={() => setEditing('new')}>
            <Plus size={16} /> Nova despesa
          </Button>
        }
      />

      <div className="mb-5">
        <PeriodFilter value={period} onChange={setPeriod} />
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <Stat label="Total no período" tone="expense" value={brl(k.total)} hint={`${inPeriod.length} despesa(s)`} />
        <Stat label="Pago" tone="income" value={brl(k.paid)} />
        <Stat label="A pagar" value={brl(k.open)} />
        <Stat label="Em atraso" tone={k.late > 0 ? 'expense' : 'neutral'} value={brl(k.late)} />
        <Stat label={`Total em ${year}`} value={brl(sum(yearList.map((e) => e.amount)))} hint={`Pago ${brl(sum(yearList.filter((e) => e.status === 'paga').map((e) => e.amount)))}`} />
      </div>

      <div className="mt-6">
        <Tabs
          value={tab}
          onChange={setTab}
          tabs={[
            { value: 'lista', label: 'Despesas' },
            { value: 'futuras', label: `Futuras (${future.length})` },
            { value: 'historico', label: 'Histórico de pagamentos' },
            { value: 'comparativo', label: 'Planejado × realizado' },
          ]}
        />

        {tab === 'lista' && (
          <>
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" aria-hidden />
                <Input aria-label="Buscar despesa" placeholder="Buscar…" value={query} onChange={(e) => setQuery(e.target.value)} className="w-48 py-1.5 pl-8" />
              </div>
              <Select aria-label="Filtrar por categoria" value={category} onChange={(e) => setCategory(e.target.value)} className="w-52 py-1.5">
                <option value="todas">Todas as categorias</option>
                {catOptions.map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </Select>
              <Select aria-label="Filtrar por status" value={status} onChange={(e) => setStatus(e.target.value as StatusFilter)} className="w-40 py-1.5">
                <option value="todas">Todos os status</option>
                <option value="pendente">Pendentes</option>
                <option value="atrasada">Atrasadas</option>
                <option value="paga">Pagas</option>
              </Select>
              <span className="text-xs text-gray-500">
                {filtered.length} resultado(s) · {brl(sum(filtered.map((e) => e.amount)))}
              </span>
            </div>
            {inPeriod.length === 0 ? (
              <EmptyState title="Nenhuma despesa neste período" text="Cadastre contas únicas, fixas (recorrentes) ou parceladas para acompanhar vencimentos." action={<Button onClick={() => setEditing('new')}>Cadastrar despesa</Button>} />
            ) : filtered.length === 0 ? (
              <EmptyState title="Nada encontrado com esses filtros" text="Ajuste a categoria, o status ou a busca." />
            ) : (
              <Card pad={false}>
                <Table head={[...baseHead, { label: 'Ações', className: 'text-right' }]}>{filtered.map((e) => renderRow(e))}</Table>
              </Card>
            )}
          </>
        )}

        {tab === 'futuras' &&
          (future.length === 0 ? (
            <EmptyState title="Sem despesas futuras" text="Despesas pendentes com vencimento de hoje em diante aparecem aqui. Contas recorrentes são geradas automaticamente para os próximos meses." />
          ) : (
            <Card pad={false}>
              <Table head={[...baseHead, { label: 'Ações', className: 'text-right' }]}>{future.slice(0, 200).map((e) => renderRow(e))}</Table>
              {future.length > 200 && <p className="px-5 py-3 text-xs text-gray-500">Mostrando as 200 primeiras de {future.length}.</p>}
            </Card>
          ))}

        {tab === 'historico' &&
          (history.length === 0 ? (
            <EmptyState title="Nenhum pagamento no período" text="As despesas marcadas como pagas aparecem aqui, pela data de pagamento." />
          ) : (
            <Card pad={false}>
              <Table head={['Pago em', 'Despesa', 'Categoria', 'Forma', { label: 'Valor', className: 'text-right' }, 'Vencimento', 'Pontualidade']}>
                {history.map((e) => {
                  const diff = daysBetween(e.dueDate, e.paidDate)
                  return (
                    <tr key={e.id} className="hover:bg-gray-50/60">
                      <td className="td num">{formatDate(e.paidDate)}</td>
                      <td className="td font-medium">{e.name}</td>
                      <td className="td text-gray-600">{e.category}</td>
                      <td className="td text-gray-600">{e.method || '—'}</td>
                      <td className="td num text-right text-expense">{brl(e.amount)}</td>
                      <td className="td num">{formatDate(e.dueDate)}</td>
                      <td className="td">
                        <Badge tone={diff > 0 ? 'expense' : 'income'}>{diff > 0 ? `${diff} dia(s) de atraso` : diff < 0 ? `${-diff} dia(s) antes` : 'No dia'}</Badge>
                      </td>
                    </tr>
                  )
                })}
                <tr className="bg-gray-50 font-semibold">
                  <td className="td" colSpan={4}>
                    Total pago
                  </td>
                  <td className="td num text-right text-expense">{brl(sum(history.map((e) => e.amount)))}</td>
                  <td className="td" colSpan={2} />
                </tr>
              </Table>
            </Card>
          ))}

        {tab === 'comparativo' && (
          <div className="space-y-4">
            <Card title="Por categoria" subtitle="Dentro do período selecionado" pad={false}>
              {byCategory.length === 0 ? (
                <p className="p-5 text-sm text-gray-500">Sem despesas no período.</p>
              ) : (
                <Table head={['Categoria', { label: 'Planejado', className: 'text-right' }, { label: 'Realizado', className: 'text-right' }, { label: 'Falta pagar', className: 'text-right' }, { label: 'Orçamento', className: 'text-right' }, 'Execução']}>
                  {byCategory.map((c) => {
                    const ratio = c.planned > 0 ? (c.paid / c.planned) * 100 : 0
                    const over = c.budget > 0 && c.planned > c.budget
                    return (
                      <tr key={c.category}>
                        <td className="td font-medium">{c.category}</td>
                        <td className="td num text-right">{brl(c.planned)}</td>
                        <td className="td num text-right text-income">{brl(c.paid)}</td>
                        <td className="td num text-right">{brl(c.planned - c.paid)}</td>
                        <td className={`td num text-right ${over ? 'font-medium text-expense' : 'text-gray-500'}`}>{c.budget > 0 ? brl(c.budget) : '—'}</td>
                        <td className="td min-w-[8rem]">
                          <div className="flex items-center gap-2">
                            <ProgressBar value={ratio} tone="income" label={`${c.category}: ${pct(ratio)} pago`} />
                            <span className="num w-10 text-right text-xs text-gray-500">{pct(ratio)}</span>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </Table>
              )}
            </Card>
            <Card title={`Totais mensais de ${year}`} subtitle="Planejado (por vencimento) versus realizado (pago)">
              <ChartBox height={240}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={monthly} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
                    <CartesianGrid vertical={false} stroke="#eef0f2" />
                    <XAxis dataKey="label" tickLine={false} axisLine={false} />
                    <YAxis tickFormatter={axisMoney} tickLine={false} axisLine={false} />
                    <Tooltip content={<MoneyTooltip />} cursor={{ fill: 'rgba(17,24,39,0.04)' }} />
                    <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                    <Bar dataKey="Planejado" fill={COLORS.sep} radius={[4, 4, 0, 0]} maxBarSize={20} />
                    <Bar dataKey="Realizado" fill={COLORS.expense} radius={[4, 4, 0, 0]} maxBarSize={20} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartBox>
              <div className="mt-4">
                <Table head={['Mês', { label: 'Planejado', className: 'text-right' }, { label: 'Realizado', className: 'text-right' }, { label: 'Pendente', className: 'text-right' }]}>
                  {monthly.map((m) => (
                    <tr key={m.m}>
                      <td className="td capitalize">{monthLabel(m.m)}</td>
                      <td className="td num text-right">{brl(m.Planejado)}</td>
                      <td className="td num text-right text-income">{brl(m.Realizado)}</td>
                      <td className="td num text-right">{brl(m.Pendente)}</td>
                    </tr>
                  ))}
                  <tr className="bg-gray-50 font-semibold">
                    <td className="td">Total do ano</td>
                    <td className="td num text-right">{brl(sum(monthly.map((m) => m.Planejado)))}</td>
                    <td className="td num text-right text-income">{brl(sum(monthly.map((m) => m.Realizado)))}</td>
                    <td className="td num text-right">{brl(sum(monthly.map((m) => m.Pendente)))}</td>
                  </tr>
                </Table>
              </div>
            </Card>
          </div>
        )}
      </div>

      <ExpenseForm expense={editing} onClose={() => setEditing(null)} />
      <PayModal expense={paying} onClose={() => setPaying(null)} />
      <DeleteExpense expense={deleting} onClose={() => setDeleting(null)} />
    </>
  )
}

function PayModal({ expense, onClose }: { expense: Expense | null; onClose: () => void }) {
  const { actions, today, notify } = useApp()
  const [date, setDate] = useState(today)
  const [method, setMethod] = useState('')
  const [key, setKey] = useState<Expense | null>(null)
  if (expense !== key) {
    setKey(expense)
    if (expense) {
      setDate(today)
      setMethod(expense.method)
    }
  }
  const submit = () => {
    if (!expense) return
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return notify('Informe a data do pagamento.', 'error')
    actions.payExpense(expense.id, date, method)
    notify(`"${expense.name}" marcada como paga (${brl(expense.amount)}) e lançada no livro-caixa.`)
    onClose()
  }
  return (
    <Modal
      open={!!expense}
      onClose={onClose}
      title="Registrar pagamento"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={submit}>Confirmar pagamento</Button>
        </>
      }
    >
      {expense && (
        <div className="space-y-4">
          <p className="text-sm text-gray-600">
            <span className="font-medium text-gray-900">{expense.name}</span> · vencimento {formatDate(expense.dueDate)} · <span className="num font-medium">{brl(expense.amount)}</span>
          </p>
          <Field label="Data do pagamento">
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          <Field label="Forma de pagamento">
            <Select value={method} onChange={(e) => setMethod(e.target.value)}>
              <option value="">Não informada</option>
              {PAYMENT_METHODS.map((m) => (
                <option key={m}>{m}</option>
              ))}
            </Select>
          </Field>
        </div>
      )}
    </Modal>
  )
}

function DeleteExpense({ expense, onClose }: { expense: Expense | null; onClose: () => void }) {
  const { actions, notify } = useApp()
  const [scope, setScope] = useState<'one' | 'future'>('one')
  const [key, setKey] = useState<Expense | null>(null)
  if (expense !== key) {
    setKey(expense)
    setScope('one')
  }
  const inSeries = !!expense?.seriesId
  return (
    <ConfirmDialog
      open={!!expense}
      danger
      title="Excluir despesa"
      confirmLabel="Excluir"
      text={expense ? `Excluir "${expense.name}" (${formatDate(expense.dueDate)}, ${brl(expense.amount)})?${expense.status === 'paga' ? ' O lançamento da saída no livro-caixa também será removido.' : ''}` : ''}
      onClose={onClose}
      onConfirm={() => {
        if (expense) {
          actions.deleteExpense(expense.id, scope)
          notify(scope === 'future' ? 'Despesa e próximas ocorrências pendentes excluídas.' : 'Despesa excluída.')
        }
      }}
    >
      {inSeries && (
        <fieldset className="mt-4 space-y-2 text-sm">
          <legend className="mb-1 text-xs font-medium text-gray-600">Esta despesa faz parte de uma série {expense?.installment ? 'parcelada' : 'recorrente'}.</legend>
          <label className="flex items-center gap-2">
            <input type="radio" name="scope" checked={scope === 'one'} onChange={() => setScope('one')} /> Excluir somente esta
          </label>
          <label className="flex items-center gap-2">
            <input type="radio" name="scope" checked={scope === 'future'} onChange={() => setScope('future')} /> Excluir esta e as próximas pendentes (as já pagas são mantidas)
          </label>
        </fieldset>
      )}
    </ConfirmDialog>
  )
}

function ExpenseForm({ expense, onClose }: { expense: Expense | 'new' | null; onClose: () => void }) {
  const { data, actions, today, notify } = useApp()
  const open = expense !== null
  const existing = expense && expense !== 'new' ? expense : null
  const cats = data.settings.expenseCategories

  const [name, setName] = useState('')
  const [category, setCategory] = useState('')
  const [amount, setAmount] = useState('')
  const [due, setDue] = useState('')
  const [status, setStatus] = useState<ExpenseStatus>('pendente')
  const [paidDate, setPaidDate] = useState('')
  const [method, setMethod] = useState('')
  const [recurrence, setRecurrence] = useState<Recurrence>('unica')
  const [installments, setInstallments] = useState('1')
  const [notes, setNotes] = useState('')
  const [propagate, setPropagate] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [key, setKey] = useState<unknown>(null)

  if (expense !== key) {
    setKey(expense)
    if (expense) {
      setName(existing?.name ?? '')
      setCategory(existing?.category ?? cats[0] ?? 'Outros')
      setAmount(existing ? String(existing.amount).replace('.', ',') : '')
      setDue(existing?.dueDate ?? today)
      setStatus(existing?.status ?? 'pendente')
      setPaidDate(existing?.paidDate ?? '')
      setMethod(existing?.method ?? '')
      setRecurrence(existing?.recurrence ?? 'unica')
      setInstallments('1')
      setNotes(existing?.notes ?? '')
      setPropagate(false)
      setErrors({})
    }
  }

  const inSeries = !!existing?.seriesId
  const isInstallment = !!existing?.installment
  const instN = Number(installments)

  const save = () => {
    const e: Record<string, string> = {}
    const amountN = parseNumber(amount)
    if (!name.trim()) e.name = 'Informe o nome da despesa.'
    else if (name.trim().length > 80) e.name = 'Use até 80 caracteres.'
    if (!Number.isFinite(amountN) || amountN <= 0) e.amount = 'Informe um valor maior que zero.'
    else if (amountN > 10_000_000) e.amount = 'Valor muito alto. Confira.'
    if (!/^\d{4}-\d{2}-\d{2}$/.test(due)) e.due = 'Informe a data de vencimento.'
    if (status === 'paga' && !/^\d{4}-\d{2}-\d{2}$/.test(paidDate)) e.paid = 'Informe a data do pagamento.'
    if (!existing && recurrence === 'unica' && (!Number.isInteger(instN) || instN < 1 || instN > 60)) e.inst = 'Use de 1 a 60 parcelas.'
    setErrors(e)
    if (Object.keys(e).length) return

    const base = {
      name: name.trim(),
      category,
      amount: amountN,
      dueDate: due,
      paidDate: status === 'paga' ? paidDate : '',
      method,
      recurrence,
      status,
      notes: notes.trim(),
    }
    if (existing) {
      actions.updateExpense(existing.id, base, propagate)
      notify('Despesa atualizada.')
    } else {
      actions.addExpense({ ...base, installments: recurrence === 'unica' ? instN : 1 })
      notify(recurrence !== 'unica' ? 'Despesa recorrente criada. As próximas ocorrências foram geradas.' : instN > 1 ? `${instN} parcelas criadas.` : 'Despesa cadastrada.')
    }
    onClose()
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      wide
      title={existing ? 'Editar despesa' : 'Nova despesa'}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={save}>Salvar</Button>
        </>
      }
    >
      <form
        className="grid gap-4 sm:grid-cols-2"
        noValidate
        onSubmit={(ev) => {
          ev.preventDefault()
          save()
        }}
      >
        <Field label="Nome da despesa" error={errors.name} className="sm:col-span-2">
          <Input value={name} onChange={(e) => setName(e.target.value)} invalid={!!errors.name} maxLength={80} placeholder="Ex.: Aluguel" />
        </Field>
        <Field label="Categoria">
          <Select value={category} onChange={(e) => setCategory(e.target.value)}>
            {[...new Set([...cats, category].filter(Boolean))].map((c) => (
              <option key={c}>{c}</option>
            ))}
          </Select>
        </Field>
        <Field label={!existing && recurrence === 'unica' && instN > 1 ? 'Valor de cada parcela (R$)' : 'Valor (R$)'} error={errors.amount}>
          <Input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} invalid={!!errors.amount} placeholder="0,00" />
        </Field>
        <Field label={!existing && recurrence === 'unica' && instN > 1 ? 'Vencimento da 1ª parcela' : 'Data de vencimento'} error={errors.due}>
          <Input type="date" value={due} onChange={(e) => setDue(e.target.value)} invalid={!!errors.due} />
        </Field>
        <Field label="Forma de pagamento">
          <Select value={method} onChange={(e) => setMethod(e.target.value)}>
            <option value="">Não informada</option>
            {PAYMENT_METHODS.map((m) => (
              <option key={m}>{m}</option>
            ))}
          </Select>
        </Field>

        <Field label="Recorrência" hint={inSeries && !isInstallment ? 'Para alterar a recorrência, exclua a série e crie outra.' : recurrence !== 'unica' && !existing ? 'As próximas ocorrências são geradas automaticamente, sem duplicar.' : undefined}>
          <Select value={recurrence} onChange={(e) => setRecurrence(e.target.value as Recurrence)} disabled={inSeries}>
            {(Object.keys(REC_LABEL) as Recurrence[]).map((r) => (
              <option key={r} value={r}>
                {REC_LABEL[r]}
              </option>
            ))}
          </Select>
        </Field>

        {!existing && recurrence === 'unica' ? (
          <Field label="Parcelamento (nº de parcelas)" error={errors.inst} hint="1 = sem parcelamento. Cria uma despesa por mês.">
            <Input inputMode="numeric" value={installments} onChange={(e) => setInstallments(e.target.value)} invalid={!!errors.inst} />
          </Field>
        ) : (
          <div />
        )}

        {(existing || (recurrence === 'unica' && instN <= 1)) && (
          <>
            <Field label="Status">
              <Select
                value={status}
                onChange={(e) => {
                  const v = e.target.value as ExpenseStatus
                  setStatus(v)
                  if (v === 'paga' && !paidDate) setPaidDate(today)
                }}
              >
                <option value="pendente">Pendente (vira atrasada após o vencimento)</option>
                <option value="paga">Paga</option>
              </Select>
            </Field>
            <Field label="Data do pagamento" error={errors.paid}>
              <Input type="date" value={paidDate} onChange={(e) => setPaidDate(e.target.value)} disabled={status !== 'paga'} invalid={!!errors.paid} />
            </Field>
          </>
        )}

        <Field label="Observações" className="sm:col-span-2">
          <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} maxLength={300} />
        </Field>

        {inSeries && (
          <label className="flex items-start gap-2 text-sm text-gray-700 sm:col-span-2">
            <input type="checkbox" className="mt-1" checked={propagate} onChange={(e) => setPropagate(e.target.checked)} />
            Aplicar nome, categoria, valor, forma de pagamento e observações às próximas ocorrências pendentes desta série
          </label>
        )}
        <button type="submit" className="hidden" aria-hidden tabIndex={-1} />
      </form>
    </Modal>
  )
}
