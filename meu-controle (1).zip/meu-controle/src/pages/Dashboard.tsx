import { useMemo } from 'react'
import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { ArrowDownRight, ArrowUpRight, CalendarClock, CircleDollarSign, Landmark, PackageCheck, PiggyBank, Receipt, Rocket, Wallet } from 'lucide-react'
import { useApp } from '../store/store'
import {
  buildAlerts,
  calcDebt,
  computePayroll,
  effectivePayroll,
  expenseStatus,
  expensesInRange,
  filterProductivity,
  nextPayDate,
  productivitySeries,
  rangeSummary,
  realizedBalance,
  referenceMonthForPayDate,
  sum,
  summarizeProductivity,
  totalsByCategory,
} from '../lib/calc'
import { addDays, addMonthKey, monthLabel, monthRange, monthsBetween, shortMonth } from '../lib/dates'
import { brl, formatDate, pct } from '../lib/format'
import { Badge, Button, Card, EmptyState, Notice, PageHeader, ProgressBar, Stat } from '../components/ui'
import { PeriodFilter } from '../components/PeriodFilter'
import { axisMoney, ChartBox, COLORS, MoneyTooltip, PIE_COLORS } from '../components/charts'
import type { Route } from '../components/Layout'

export function Dashboard({ go }: { go: (r: Route) => void }) {
  const { data, today, period, setPeriod, range } = useApp()
  const s = data.settings

  const summary = useMemo(() => rangeSummary(data, range, today), [data, range, today])

  const alertMonth = period.mode === 'mes' ? period.month : today.slice(0, 7)
  const alerts = useMemo(() => buildAlerts(data, alertMonth, today, brl), [data, alertMonth, today])

  const nightWarn = useMemo(() => computePayroll(data, alertMonth).warnings.find((w) => w.startsWith('Adicional noturno')), [data, alertMonth])

  const prodEntries = useMemo(() => filterProductivity(data.productivity, range), [data.productivity, range])
  const prodSum = useMemo(() => summarizeProductivity(prodEntries), [prodEntries])

  const debtStats = useMemo(() => {
    const calcs = data.debts.map((d) => ({ d, c: calcDebt(d, data.debtPayments, today) }))
    return {
      open: sum(calcs.filter((x) => x.c.status !== 'quitada').map((x) => x.c.remaining)),
      paidAll: sum(data.debtPayments.map((p) => p.amount)),
      paidRange: sum(data.debtPayments.filter((p) => p.date >= range.from && p.date <= range.to).map((p) => p.amount)),
      calcs,
    }
  }, [data.debts, data.debtPayments, today, range])

  // Gráfico mensal
  const chartMonths = useMemo(() => {
    if (period.mode === 'ano') return monthsBetween(range.from, range.to)
    if (period.mode === 'mes') return Array.from({ length: 6 }, (_, i) => addMonthKey(period.month, i - 5))
    const all = monthsBetween(range.from, range.to)
    return all.slice(-12)
  }, [period, range])

  const monthly = useMemo(() => {
    let cumPlan = 0
    return chartMonths.map((m) => {
      const r = rangeSummary(data, monthRange(m), today)
      cumPlan = Math.round((cumPlan + r.balance) * 100) / 100
      const end = monthRange(m).to
      const realized = realizedBalance(data.transactions.filter((t) => t.date <= end))
      return { label: shortMonth(m), Receitas: r.income, Despesas: r.outflow, previsto: cumPlan, realizado: realized }
    })
  }, [chartMonths, data, today])

  const categories = useMemo(() => totalsByCategory(expensesInRange(data.expenses, range)), [data.expenses, range])
  const prodSeries = useMemo(() => productivitySeries(prodEntries, range), [prodEntries, range])

  const upcoming = useMemo(
    () =>
      data.expenses
        .filter((e) => e.status === 'pendente' && e.dueDate <= addDays(today, 30))
        .sort((a, b) => a.dueDate.localeCompare(b.dueDate))
        .slice(0, 6),
    [data.expenses, today],
  )
  const dueDebts = useMemo(
    () =>
      debtStats.calcs
        .filter((x) => x.c.status !== 'quitada' && x.d.nextDue && x.d.nextDue <= addDays(today, 30))
        .sort((a, b) => a.d.nextDue.localeCompare(b.d.nextDue))
        .slice(0, 5),
    [debtStats, today],
  )
  const recent = useMemo(
    () => [...data.transactions].filter((t) => t.kind !== 'incorporada').sort((a, b) => b.date.localeCompare(a.date)).slice(0, 7),
    [data.transactions],
  )

  const payDate = nextPayDate(s, today)
  const refMonth = referenceMonthForPayDate(payDate, s.payMonthOffset)
  const nextPay = effectivePayroll(data, refMonth)

  const isEmpty =
    !data.productivity.length && !data.expenses.length && !data.debts.length && !data.transactions.length && !data.payrolls.length

  const committed = summary.committedPct
  const committedTone = committed >= 100 ? 'expense' : committed >= 70 ? 'warn' : 'neutral'
  const periodLabel = period.mode === 'mes' ? monthLabel(period.month) : period.mode === 'ano' ? String(period.year) : `${formatDate(range.from)} a ${formatDate(range.to)}`

  return (
    <>
      <PageHeader title="Visão geral" subtitle={`Resumo financeiro de ${periodLabel}.`} actions={<PeriodFilter value={period} onChange={setPeriod} />} />

      {isEmpty && (
        <Card className="mb-5">
          <EmptyState
            icon={<Rocket size={20} />}
            title="Comece cadastrando suas informações"
            text="O painel só mostra dados reais. Os valores de salário já vêm da configuração inicial; registre produtividade, despesas ou dívidas para ver o restante ganhar vida."
            action={
              <div className="flex flex-wrap justify-center gap-2">
                <Button onClick={() => go('produtividade')}>Registrar produtividade</Button>
                <Button variant="secondary" onClick={() => go('despesas')}>
                  Cadastrar despesa
                </Button>
                <Button variant="secondary" onClick={() => go('configuracoes')}>
                  Ajustar salário
                </Button>
              </div>
            }
          />
        </Card>
      )}

      {nightWarn && (
        <Notice tone="info" className="mb-4">
          O adicional noturno ({s.nightPct}%) ainda não entrou no salário estimado: informe as horas noturnas por dia e os dias trabalhados.{' '}
          <button type="button" className="font-medium underline" onClick={() => go('configuracoes')}>
            Configurar agora
          </button>
        </Notice>
      )}

      {alerts.length > 0 && (
        <div className="mb-5 space-y-2">
          {alerts.slice(0, 4).map((a, i) => (
            <Notice key={i} tone={a.level === 'danger' ? 'danger' : 'warn'}>
              {a.text}
            </Notice>
          ))}
          {alerts.length > 4 && (
            <button type="button" className="text-xs font-medium text-gray-600 underline" onClick={() => go('planejamento')}>
              Ver todos os {alerts.length} alertas no Planejamento
            </button>
          )}
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Salário-base" icon={<Wallet size={16} />} value={brl(summary.baseSalary)} hint={summary.months.length > 1 ? `${summary.months.length} meses` : 'Mensal'} />
        <Stat
          label="Salário estimado (líquido)"
          icon={<CircleDollarSign size={16} />}
          value={brl(summary.salaryNet)}
          hint={`Bruto ${brl(summary.salaryGross)} · ${summary.salaryConfirmed ? 'confirmado' : 'estimativa'}`}
        />
        <Stat label="Receitas extras" icon={<ArrowUpRight size={16} />} tone="income" value={brl(summary.extras)} hint="Fora do salário" />
        <Stat
          label="Despesas do período"
          icon={<Receipt size={16} />}
          tone="expense"
          value={brl(summary.expensesPlanned)}
          hint={`Pago ${brl(summary.expensesPaid)} · pendente ${brl(summary.expensesPending)}`}
        />
        <Stat label="Dívidas em aberto" icon={<Landmark size={16} />} tone="expense" value={brl(debtStats.open)} hint={`${debtStats.calcs.filter((x) => x.c.status !== 'quitada').length} dívida(s) ativa(s)`} />
        <Stat
          label="Saldo previsto após despesas"
          icon={<PiggyBank size={16} />}
          tone={summary.balance >= 0 ? 'income' : 'expense'}
          value={brl(summary.balance)}
          hint={`Inclui parcelas de dívidas (${brl(summary.debtTotal)})`}
        />
        <Stat
          label="Produtividade acumulada"
          icon={<PackageCheck size={16} />}
          value={brl(prodSum.totalValue)}
          hint={`${prodSum.confQty} conferências · ${prodSum.sepQty} separações`}
        />
        <Stat label="Total já pago em dívidas" icon={<ArrowDownRight size={16} />} value={brl(debtStats.paidAll)} hint={`No período: ${brl(debtStats.paidRange)}`} />
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <Card title="Salário comprometido" subtitle="Despesas e parcelas de dívidas em relação ao salário líquido do período">
          <div className="flex items-end justify-between">
            <p className="num text-3xl font-semibold">{summary.salaryNet > 0 ? pct(committed, 0) : '—'}</p>
            <p className="text-right text-xs text-gray-500">
              {brl(summary.outflow)} de {brl(summary.salaryNet)}
            </p>
          </div>
          <div className="mt-3">
            <ProgressBar value={committed} tone={committedTone} label="Percentual do salário comprometido" />
          </div>
          <p className="mt-3 text-xs text-gray-500">
            {committed >= 100 ? 'Os compromissos superam o salário líquido previsto.' : `Livre após compromissos: ${brl(summary.salaryNet - summary.outflow)}.`}
          </p>
        </Card>

        <Card title="Próximo pagamento" subtitle={`Competência de ${monthLabel(refMonth)}`} action={<Badge tone={nextPay.confirmed ? 'income' : 'neutral'}>{nextPay.confirmed ? 'Folha confirmada' : 'Estimativa'}</Badge>}>
          <div className="flex items-end justify-between gap-3">
            <div>
              <p className="num text-3xl font-semibold">{brl(nextPay.net)}</p>
              <p className="mt-1 flex items-center gap-1.5 text-xs text-gray-500">
                <CalendarClock size={13} aria-hidden /> Previsto para {formatDate(nextPay.record?.expectedDate || payDate)}
              </p>
            </div>
            <dl className="num text-right text-xs text-gray-500">
              <div>Bruto {brl(nextPay.gross)}</div>
              <div>Descontos {brl(nextPay.deductions)}</div>
            </dl>
          </div>
          <Button variant="secondary" size="sm" className="mt-3" onClick={() => go('salario')}>
            Ver detalhamento
          </Button>
        </Card>
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        <Card title="Receitas × despesas por mês" subtitle="Competência; despesas incluem parcelas de dívidas">
          <ChartBox empty={isEmpty && !data.settings.baseSalary ? 'Sem dados' : undefined}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthly} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke={COLORS.grid} />
                <XAxis dataKey="label" tickLine={false} axisLine={false} />
                <YAxis tickFormatter={axisMoney} tickLine={false} axisLine={false} />
                <Tooltip content={<MoneyTooltip />} cursor={{ fill: 'rgba(17,24,39,0.04)' }} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="Receitas" fill={COLORS.income} radius={[4, 4, 0, 0]} maxBarSize={28} />
                <Bar dataKey="Despesas" fill={COLORS.expense} radius={[4, 4, 0, 0]} maxBarSize={28} />
              </BarChart>
            </ResponsiveContainer>
          </ChartBox>
        </Card>

        <Card title="Evolução do saldo" subtitle="Previsto acumulado no gráfico × saldo realizado do livro-caixa">
          <ChartBox>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthly} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke={COLORS.grid} />
                <XAxis dataKey="label" tickLine={false} axisLine={false} />
                <YAxis tickFormatter={axisMoney} tickLine={false} axisLine={false} />
                <Tooltip content={<MoneyTooltip />} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                <Line type="monotone" dataKey="previsto" name="Previsto acumulado" stroke={COLORS.ink} strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="realizado" name="Realizado (caixa)" stroke={COLORS.income} strokeWidth={2} strokeDasharray="5 4" dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </ChartBox>
        </Card>

        <Card title="Despesas por categoria" subtitle={periodLabel}>
          <ChartBox empty={categories.length === 0 ? 'Nenhuma despesa no período. Cadastre despesas para ver a distribuição.' : undefined}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie isAnimationActive={false} data={categories} dataKey="total" nameKey="category" innerRadius="55%" outerRadius="85%" paddingAngle={2} stroke="none">
                  {categories.map((_, i) => (
                    <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<MoneyTooltip />} />
                <Legend iconType="circle" iconSize={8} layout="vertical" align="right" verticalAlign="middle" wrapperStyle={{ fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </ChartBox>
        </Card>

        <Card title="Produtividade diária" subtitle="Valor gerado por conferência e separação">
          <ChartBox empty={prodEntries.length === 0 ? 'Nenhuma produtividade registrada no período.' : undefined}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={prodSeries} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke={COLORS.grid} />
                <XAxis dataKey="label" tickLine={false} axisLine={false} interval="preserveStartEnd" />
                <YAxis tickFormatter={axisMoney} tickLine={false} axisLine={false} />
                <Tooltip content={<MoneyTooltip />} cursor={{ fill: 'rgba(17,24,39,0.04)' }} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="conf" name="Conferência" stackId="a" fill={COLORS.conf} maxBarSize={22} />
                <Bar dataKey="sep" name="Separação" stackId="a" fill={COLORS.sep} radius={[4, 4, 0, 0]} maxBarSize={22} />
              </BarChart>
            </ResponsiveContainer>
          </ChartBox>
        </Card>
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-3">
        <Card title="Próximas contas a vencer" subtitle="Até 30 dias, incluindo atrasadas">
          {upcoming.length === 0 ? (
            <p className="text-sm text-gray-500">Nenhuma conta pendente nos próximos 30 dias.</p>
          ) : (
            <ul className="divide-y divide-gray-100">
              {upcoming.map((e) => {
                const late = expenseStatus(e, today) === 'atrasada'
                return (
                  <li key={e.id} className="flex items-center justify-between gap-3 py-2.5">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-gray-900">{e.name}</p>
                      <p className="text-xs text-gray-500">
                        {formatDate(e.dueDate)} · {e.category}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="num text-sm font-medium text-expense">{brl(e.amount)}</p>
                      {late && <Badge tone="expense">Atrasada</Badge>}
                    </div>
                  </li>
                )
              })}
            </ul>
          )}
        </Card>

        <Card title="Dívidas com vencimento próximo" subtitle="Próximos 30 dias, incluindo atrasadas">
          {dueDebts.length === 0 ? (
            <p className="text-sm text-gray-500">Nenhuma parcela de dívida vencendo em breve.</p>
          ) : (
            <ul className="divide-y divide-gray-100">
              {dueDebts.map(({ d, c }) => (
                <li key={d.id} className="flex items-center justify-between gap-3 py-2.5">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-gray-900">{d.name}</p>
                    <p className="text-xs text-gray-500">
                      {formatDate(d.nextDue)} · {d.creditor || 'sem credor'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="num text-sm font-medium text-expense">{brl(Math.min(d.installmentValue || c.remaining, c.remaining))}</p>
                    {c.status === 'atrasada' && <Badge tone="expense">Atrasada</Badge>}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card title="Últimas movimentações" action={<Button variant="ghost" size="sm" onClick={() => go('caixa')}>Ver tudo</Button>}>
          {recent.length === 0 ? (
            <p className="text-sm text-gray-500">Nenhuma movimentação registrada ainda.</p>
          ) : (
            <ul className="divide-y divide-gray-100">
              {recent.map((t) => (
                <li key={t.id} className="flex items-center justify-between gap-3 py-2.5">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-gray-900">{t.description}</p>
                    <p className="text-xs text-gray-500">
                      {formatDate(t.date)} · {t.status === 'previsto' ? 'previsto' : t.category}
                    </p>
                  </div>
                  <p className={`num text-sm font-medium ${t.type === 'entrada' ? 'text-income' : 'text-expense'}`}>
                    {t.type === 'entrada' ? '+' : '−'}
                    {brl(t.amount)}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </>
  )
}
