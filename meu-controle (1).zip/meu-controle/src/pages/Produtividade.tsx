import { useMemo, useState } from 'react'
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { ChevronLeft, ChevronRight, Download, FileText, Pencil, Plus, Trash2, Trophy } from 'lucide-react'
import { useApp } from '../store/store'
import type { ActivityType, ProductivityEntry, Range } from '../types'
import { ACTIVITY_LABEL } from '../types'
import {
  entryValue,
  filterProductivity,
  payFactor,
  pctChange,
  productionValue,
  productivityByDay,
  productivitySeries,
  summarizeProductivity,
} from '../lib/calc'
import { addDays, addMonths, monthKey, monthLabel, monthRange, startOfWeek, weekdayShort } from '../lib/dates'
import { brl, formatDate, num, parseNumber, pct } from '../lib/format'
import { downloadFile, toCSV } from '../lib/csv'
import { Badge, Button, Card, ConfirmDialog, EmptyState, Field, Input, Modal, Notice, PageHeader, Segmented, Select, Stat, Table, Tabs, Textarea } from '../components/ui'
import { axisMoney, ChartBox, COLORS, MoneyTooltip } from '../components/charts'

type View = 'dia' | 'semana' | 'mes'

function rangeFor(view: View, anchor: string): Range {
  if (view === 'dia') return { from: anchor, to: anchor }
  if (view === 'semana') {
    const s = startOfWeek(anchor)
    return { from: s, to: addDays(s, 6) }
  }
  return monthRange(monthKey(anchor))
}

function shift(view: View, anchor: string, dir: 1 | -1): string {
  if (view === 'dia') return addDays(anchor, dir)
  if (view === 'semana') return addDays(anchor, 7 * dir)
  return addMonths(anchor, dir)
}

export function Produtividade() {
  const { data, actions, today, notify } = useApp()
  const s = data.settings
  const [view, setView] = useState<View>('mes')
  const [anchor, setAnchor] = useState(today)
  const [typeFilter, setTypeFilter] = useState<ActivityType | 'todas'>('todas')
  const [tab, setTab] = useState<'registros' | 'dias'>('registros')
  const [editing, setEditing] = useState<ProductivityEntry | 'new' | null>(null)
  const [toDelete, setToDelete] = useState<ProductivityEntry | null>(null)
  const [busy, setBusy] = useState(false)

  const range = rangeFor(view, anchor)
  const prevRange = rangeFor(view, shift(view, anchor, -1))
  const entries = useMemo(() => filterProductivity(data.productivity, range, typeFilter), [data.productivity, range.from, range.to, typeFilter])
  const prevEntries = useMemo(() => filterProductivity(data.productivity, prevRange, typeFilter), [data.productivity, prevRange.from, prevRange.to, typeFilter])
  const sum = useMemo(() => summarizeProductivity(entries), [entries])
  const prevSum = useMemo(() => summarizeProductivity(prevEntries), [prevEntries])
  const delta = pctChange(sum.totalValue, prevSum.totalValue)

  const monthR = monthRange(monthKey(anchor))
  const monthEntries = useMemo(() => filterProductivity(data.productivity, monthR), [data.productivity, monthR.from])
  const monthSum = useMemo(() => summarizeProductivity(monthEntries), [monthEntries])
  const eligible = Math.round(monthSum.totalValue * payFactor(s) * 100) / 100

  const days = useMemo(() => productivityByDay(entries), [entries])
  const series = useMemo(() => productivitySeries(entries, range), [entries, range.from, range.to])
  const sorted = useMemo(() => [...entries].sort((a, b) => b.date.localeCompare(a.date) || a.type.localeCompare(b.type)), [entries])

  const rangeLabel =
    view === 'dia' ? formatDate(range.from) : view === 'semana' ? `${formatDate(range.from)} a ${formatDate(range.to)}` : monthLabel(monthKey(anchor))

  const exportCSV = () => {
    const rows: (string | number)[][] = [['Data', 'Atividade', 'Quantidade', 'Valor unitário', 'Total', 'Observações']]
    for (const e of [...entries].sort((a, b) => a.date.localeCompare(b.date)))
      rows.push([formatDate(e.date), ACTIVITY_LABEL[e.type], e.qty, e.unitValue, entryValue(e), e.notes ?? ''])
    downloadFile(`produtividade_${range.from}_${range.to}.csv`, toCSV(rows), 'text/csv;charset=utf-8')
    notify('CSV da produtividade exportado.')
  }

  const exportPDF = async () => {
    setBusy(true)
    try {
      const { buildReport, reportFileName } = await import('../reports/build')
      const opts = { kind: 'produtividade' as const, range, month: monthKey(anchor), year: Number(anchor.slice(0, 4)), activityFilter: typeFilter }
      const doc = buildReport(data, opts, today)
      doc.save(reportFileName(opts))
      notify('PDF da produtividade gerado.')
    } catch (e) {
      notify('Não foi possível gerar o PDF.', 'error')
      console.error(e)
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <PageHeader
        title="Produtividade"
        subtitle="Registre conferências e separações. O valor gerado entra na remuneração do mês, sem ser contado de novo como receita extra."
        actions={
          <>
            <Button variant="secondary" onClick={exportCSV} disabled={!entries.length}>
              <Download size={16} /> CSV
            </Button>
            <Button variant="secondary" onClick={exportPDF} disabled={!entries.length || busy}>
              <FileText size={16} /> {busy ? 'Gerando…' : 'PDF'}
            </Button>
            <Button onClick={() => setEditing('new')}>
              <Plus size={16} /> Novo registro
            </Button>
          </>
        }
      />

      <div className="mb-5 flex flex-wrap items-center gap-2">
        <Segmented
          label="Visão"
          value={view}
          onChange={setView}
          options={[
            { value: 'dia', label: 'Dia' },
            { value: 'semana', label: 'Semana' },
            { value: 'mes', label: 'Mês' },
          ]}
        />
        <div className="flex items-center gap-1">
          <Button variant="secondary" size="sm" aria-label="Período anterior" onClick={() => setAnchor(shift(view, anchor, -1))}>
            <ChevronLeft size={15} />
          </Button>
          <Input type="date" aria-label="Data de referência" value={anchor} onChange={(e) => e.target.value && setAnchor(e.target.value)} className="w-40 py-1.5" />
          <Button variant="secondary" size="sm" aria-label="Próximo período" onClick={() => setAnchor(shift(view, anchor, 1))}>
            <ChevronRight size={15} />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setAnchor(today)}>
            Hoje
          </Button>
        </div>
        <Select aria-label="Filtrar por atividade" value={typeFilter} onChange={(e) => setTypeFilter(e.target.value as ActivityType | 'todas')} className="w-44 py-1.5">
          <option value="todas">Todas as atividades</option>
          <option value="conferencia">Conferência</option>
          <option value="separacao">Separação</option>
        </Select>
        <span className="text-sm font-medium capitalize text-gray-700">{rangeLabel}</span>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Conferências" value={num(sum.confQty)} hint={`Gerou ${brl(sum.confValue)}`} />
        <Stat label="Separações" value={num(sum.sepQty)} hint={`Gerou ${brl(sum.sepValue)}`} />
        <Stat
          label={`Total ${view === 'dia' ? 'do dia' : view === 'semana' ? 'da semana' : 'do mês'}`}
          tone="income"
          value={brl(sum.totalValue)}
          hint={
            delta === null ? (
              'Sem período anterior para comparar'
            ) : (
              <span className={delta >= 0 ? 'text-income' : 'text-expense'}>
                {delta >= 0 ? '▲' : '▼'} {pct(Math.abs(delta), 1)} vs. período anterior ({brl(prevSum.totalValue)})
              </span>
            )
          }
        />
        <Stat
          label="Média por dia trabalhado"
          value={brl(sum.avgPerDay)}
          hint={
            sum.bestDay ? (
              <span className="inline-flex items-center gap-1">
                <Trophy size={12} aria-hidden /> Melhor dia: {formatDate(sum.bestDay.date)} ({brl(sum.bestDay.value)})
              </span>
            ) : (
              'Sem registros'
            )
          }
        />
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-3">
        <Card title="Pagamento da produtividade" subtitle={`Mês de ${monthLabel(monthKey(anchor))}`} className="lg:col-span-1">
          <div className="space-y-3">
            <Segmented
              label="Situação do pagamento"
              value={s.prodPayMode}
              onChange={(v) => actions.updateSettings({ prodPayMode: v })}
              options={[
                { value: 'integral', label: 'Integral' },
                { value: 'parcial', label: 'Parcial' },
                { value: 'pendente', label: 'Pendente' },
              ]}
            />
            {s.prodPayMode === 'parcial' && (
              <Field label="Percentual pago">
                <Input
                  type="number"
                  min={0}
                  max={100}
                  step="1"
                  value={s.prodPartialPct}
                  onChange={(e) => actions.updateSettings({ prodPartialPct: Math.min(100, Math.max(0, Number(e.target.value) || 0)) })}
                />
              </Field>
            )}
            <dl className="num space-y-1 text-sm">
              <div className="flex justify-between">
                <dt className="text-gray-500">Produzido no mês</dt>
                <dd className="font-medium">{brl(monthSum.totalValue)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-gray-500">Entra na folha</dt>
                <dd className="font-medium text-income">{brl(eligible)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-gray-500">Pendente</dt>
                <dd className="font-medium text-amber-700">{brl(monthSum.totalValue - eligible)}</dd>
              </div>
            </dl>
            <p className="text-xs text-gray-500">Vale para todas as competências. O valor que entra na folha já compõe o salário estimado.</p>
          </div>
        </Card>

        <Card title="Evolução no período" subtitle="Valor gerado por atividade" className="lg:col-span-2">
          <ChartBox height={220} empty={!entries.length ? 'Sem registros neste período.' : undefined}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={series} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke="#eef0f2" />
                <XAxis dataKey="label" tickLine={false} axisLine={false} interval="preserveStartEnd" />
                <YAxis tickFormatter={axisMoney} tickLine={false} axisLine={false} />
                <Tooltip content={<MoneyTooltip />} cursor={{ fill: 'rgba(17,24,39,0.04)' }} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="conf" name="Conferência" stackId="a" fill={COLORS.conf} maxBarSize={24} />
                <Bar dataKey="sep" name="Separação" stackId="a" fill={COLORS.sep} radius={[4, 4, 0, 0]} maxBarSize={24} />
              </BarChart>
            </ResponsiveContainer>
          </ChartBox>
        </Card>
      </div>

      <div className="mt-6">
        <Tabs
          value={tab}
          onChange={setTab}
          tabs={[
            { value: 'registros', label: `Registros (${entries.length})` },
            { value: 'dias', label: 'Resumo por dia' },
          ]}
        />
        {entries.length === 0 ? (
          <EmptyState
            title="Nenhum registro neste período"
            text="Adicione quanto você conferiu ou separou. É possível lançar várias atividades no mesmo dia."
            action={<Button onClick={() => setEditing('new')}>Registrar produtividade</Button>}
          />
        ) : tab === 'registros' ? (
          <Card pad={false}>
            <Table head={['Data', 'Atividade', { label: 'Qtd.', className: 'text-right' }, { label: 'Valor unit.', className: 'text-right' }, { label: 'Total', className: 'text-right' }, 'Observações', { label: 'Ações', className: 'text-right' }]}>
              {sorted.map((e) => (
                <tr key={e.id} className="hover:bg-gray-50/60">
                  <td className="td num whitespace-nowrap">
                    {formatDate(e.date)} <span className="text-xs text-gray-400">{weekdayShort(e.date)}</span>
                  </td>
                  <td className="td">
                    <Badge tone={e.type === 'conferencia' ? 'neutral' : 'info'}>{ACTIVITY_LABEL[e.type]}</Badge>
                  </td>
                  <td className="td num text-right">{num(e.qty)}</td>
                  <td className="td num text-right">{brl(e.unitValue)}</td>
                  <td className="td num text-right font-medium text-income">{brl(entryValue(e))}</td>
                  <td className="td max-w-[14rem] truncate text-gray-500" title={e.notes}>
                    {e.notes || '—'}
                  </td>
                  <td className="td whitespace-nowrap text-right">
                    <Button variant="ghost" size="sm" aria-label={`Editar registro de ${formatDate(e.date)}`} onClick={() => setEditing(e)}>
                      <Pencil size={14} />
                    </Button>
                    <Button variant="ghost" size="sm" aria-label={`Excluir registro de ${formatDate(e.date)}`} onClick={() => setToDelete(e)}>
                      <Trash2 size={14} />
                    </Button>
                  </td>
                </tr>
              ))}
            </Table>
          </Card>
        ) : (
          <Card pad={false}>
            <Table
              head={[
                'Dia',
                { label: 'Conferências', className: 'text-right' },
                { label: 'Separações', className: 'text-right' },
                { label: 'Valor conferência', className: 'text-right' },
                { label: 'Valor separação', className: 'text-right' },
                { label: 'Total do dia', className: 'text-right' },
              ]}
            >
              {[...days].reverse().map((d) => (
                <tr key={d.date} className="hover:bg-gray-50/60">
                  <td className="td num">
                    {formatDate(d.date)} <span className="text-xs text-gray-400">{weekdayShort(d.date)}</span>
                  </td>
                  <td className="td num text-right">{num(d.confQty)}</td>
                  <td className="td num text-right">{num(d.sepQty)}</td>
                  <td className="td num text-right">{brl(d.conf)}</td>
                  <td className="td num text-right">{brl(d.sep)}</td>
                  <td className="td num text-right font-semibold text-income">{brl(d.total)}</td>
                </tr>
              ))}
              <tr className="bg-gray-50 font-semibold">
                <td className="td">Total</td>
                <td className="td num text-right">{num(sum.confQty)}</td>
                <td className="td num text-right">{num(sum.sepQty)}</td>
                <td className="td num text-right">{brl(sum.confValue)}</td>
                <td className="td num text-right">{brl(sum.sepValue)}</td>
                <td className="td num text-right text-income">{brl(sum.totalValue)}</td>
              </tr>
            </Table>
          </Card>
        )}
      </div>

      <ProdForm
        entry={editing}
        defaultDate={view === 'dia' ? anchor : today}
        onClose={() => setEditing(null)}
      />

      <ConfirmDialog
        open={!!toDelete}
        danger
        title="Excluir registro"
        text={toDelete ? `Excluir ${num(toDelete.qty)} ${ACTIVITY_LABEL[toDelete.type].toLowerCase()}(ões) de ${formatDate(toDelete.date)} (${brl(entryValue(toDelete))})? Esta ação não pode ser desfeita.` : ''}
        confirmLabel="Excluir"
        onClose={() => setToDelete(null)}
        onConfirm={() => {
          if (toDelete) {
            actions.deleteProductivity(toDelete.id)
            notify('Registro excluído.')
          }
        }}
      />
    </>
  )
}

function ProdForm({ entry, defaultDate, onClose }: { entry: ProductivityEntry | 'new' | null; defaultDate: string; onClose: () => void }) {
  const { data, actions, notify } = useApp()
  const s = data.settings
  const open = entry !== null
  const existing = entry && entry !== 'new' ? entry : null

  const [date, setDate] = useState('')
  const [type, setType] = useState<ActivityType | ''>('')
  const [qty, setQty] = useState('')
  const [unit, setUnit] = useState('')
  const [unitTouched, setUnitTouched] = useState(false)
  const [notes, setNotes] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [key, setKey] = useState<unknown>(null)

  // Reinicia o formulário quando o modal abre
  if (entry !== key) {
    setKey(entry)
    if (entry) {
      setDate(existing?.date ?? defaultDate)
      setType(existing?.type ?? '')
      setQty(existing ? String(existing.qty) : '')
      setUnit(existing ? String(existing.unitValue).replace('.', ',') : '')
      setUnitTouched(!!existing)
      setNotes(existing?.notes ?? '')
      setErrors({})
    }
  }

  const rateFor = (t: ActivityType) => (t === 'conferencia' ? s.rateConferencia : s.rateSeparacao)
  const pickType = (t: ActivityType | '') => {
    setType(t)
    if (t && !unitTouched) setUnit(String(rateFor(t)).replace('.', ','))
  }

  const qtyN = parseNumber(qty)
  const unitN = parseNumber(unit)
  const total = Number.isFinite(qtyN) && Number.isFinite(unitN) ? productionValue(qtyN, unitN) : 0

  const validate = () => {
    const e: Record<string, string> = {}
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) e.date = 'Informe uma data válida.'
    if (!type) e.type = 'Escolha o tipo de atividade.'
    if (!Number.isFinite(qtyN) || qtyN <= 0) e.qty = 'Informe uma quantidade maior que zero.'
    else if (!Number.isInteger(qtyN)) e.qty = 'Use um número inteiro de unidades.'
    else if (qtyN > 100000) e.qty = 'Quantidade muito alta. Confira o valor.'
    if (!Number.isFinite(unitN) || unitN <= 0) e.unit = 'Informe o valor por unidade.'
    else if (unitN > 10000) e.unit = 'Valor unitário muito alto. Confira o valor.'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const save = (again: boolean) => {
    if (!validate()) return
    const payload = { date, type: type as ActivityType, qty: qtyN, unitValue: unitN, notes: notes.trim() || undefined }
    if (existing) {
      actions.updateProductivity(existing.id, payload)
      notify('Registro atualizado.')
      onClose()
    } else {
      actions.addProductivity(payload)
      notify(`${num(qtyN)} ${ACTIVITY_LABEL[payload.type].toLowerCase()}(ões) registradas: ${brl(total)}.`)
      if (again) {
        setType('')
        setQty('')
        setNotes('')
        setUnitTouched(false)
        setUnit('')
        setErrors({})
      } else onClose()
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={existing ? 'Editar registro' : 'Novo registro de produtividade'}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          {!existing && (
            <Button variant="secondary" onClick={() => save(true)}>
              Salvar e adicionar outra
            </Button>
          )}
          <Button onClick={() => save(false)}>Salvar</Button>
        </>
      }
    >
      <form
        className="grid gap-4 sm:grid-cols-2"
        onSubmit={(ev) => {
          ev.preventDefault()
          save(false)
        }}
        noValidate
      >
        <Field label="Data do trabalho" error={errors.date}>
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} invalid={!!errors.date} />
        </Field>
        <Field label="Tipo de atividade" error={errors.type}>
          <Select value={type} onChange={(e) => pickType(e.target.value as ActivityType | '')} invalid={!!errors.type}>
            <option value="">Selecione…</option>
            <option value="conferencia">Conferência</option>
            <option value="separacao">Separação</option>
          </Select>
        </Field>
        <Field label="Quantidade produzida" error={errors.qty}>
          <Input inputMode="numeric" placeholder="Ex.: 30" value={qty} onChange={(e) => setQty(e.target.value)} invalid={!!errors.qty} />
        </Field>
        <Field label="Valor unitário (R$)" error={errors.unit} hint={type ? `Padrão em Configurações: ${brl(rateFor(type))}` : undefined}>
          <Input
            inputMode="decimal"
            placeholder="5,00"
            value={unit}
            onChange={(e) => {
              setUnit(e.target.value)
              setUnitTouched(true)
            }}
            invalid={!!errors.unit}
          />
        </Field>
        <Field label="Observações (opcional)" className="sm:col-span-2">
          <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} maxLength={300} />
        </Field>
        <div className="sm:col-span-2">
          <Notice tone="info">
            Valor da produção: <strong className="num">{brl(total)}</strong>
            {Number.isFinite(qtyN) && Number.isFinite(unitN) && qtyN > 0 && unitN > 0 ? (
              <span className="num text-gray-600">
                {' '}
                ({num(qtyN)} × {brl(unitN)})
              </span>
            ) : null}
          </Notice>
        </div>
        <button type="submit" className="hidden" aria-hidden tabIndex={-1} />
      </form>
    </Modal>
  )
}
