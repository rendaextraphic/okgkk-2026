import { useMemo, useState } from 'react'
import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { HandCoins, Pencil, Plus, Trash2 } from 'lucide-react'
import { useApp } from '../store/store'
import type { Debt, DebtStatus, Priority } from '../types'
import { calcDebt, debtOutflow, pendingInstallments, simulatePayoff, sum, type DebtCalc } from '../lib/calc'
import { addMonths, monthLabel, monthRange } from '../lib/dates'
import { brl, formatDate, num, parseNumber, pct, round2 } from '../lib/format'
import { DEBT_CATEGORIES } from '../lib/defaults'
import { Badge, Button, Card, ConfirmDialog, EmptyState, Field, Input, Modal, Notice, PageHeader, ProgressBar, Select, Stat, Table, Tabs, Textarea } from '../components/ui'
import { axisMoney, ChartBox, COLORS, MoneyTooltip } from '../components/charts'

const PRIORITY_LABEL: Record<Priority, string> = { baixa: 'Baixa', media: 'Média', alta: 'Alta' }
const STATUS_TONE = { quitada: 'income', atrasada: 'expense', negociacao: 'warn', em_dia: 'neutral' } as const
const STATUS_LABEL = { quitada: 'Quitada', atrasada: 'Atrasada', negociacao: 'Em negociação', em_dia: 'Em dia' } as const

export function Dividas() {
  const { data, actions, today, notify } = useApp()
  const [tab, setTab] = useState<'dividas' | 'pagamentos' | 'plano'>('dividas')
  const [editing, setEditing] = useState<Debt | 'new' | null>(null)
  const [paying, setPaying] = useState<Debt | null>(null)
  const [deleting, setDeleting] = useState<Debt | null>(null)
  const [delPay, setDelPay] = useState<string | null>(null)

  const rows = useMemo(
    () => data.debts.map((d) => ({ d, c: calcDebt(d, data.debtPayments, today) })),
    [data.debts, data.debtPayments, today],
  )
  const k = useMemo(() => {
    const open = rows.filter((r) => r.c.status !== 'quitada')
    const monthR = monthRange(today.slice(0, 7))
    const out = debtOutflow(data, monthR, today)
    const latest = open.map((r) => r.c.payoffDate).filter(Boolean).sort().pop() ?? null
    return {
      open: sum(open.map((r) => r.c.remaining)),
      paid: sum(rows.map((r) => r.c.paidTotal)),
      dueMonth: out.pending,
      late: rows.filter((r) => r.c.status === 'atrasada').length,
      done: rows.filter((r) => r.c.status === 'quitada').length,
      latest: open.length ? latest : null,
      missingForecast: open.some((r) => !r.c.payoffDate),
    }
  }, [rows, data, today])

  const sorted = useMemo(() => {
    const order = { atrasada: 0, negociacao: 1, em_dia: 2, quitada: 3 }
    const pr = { alta: 0, media: 1, baixa: 2 }
    return [...rows].sort((a, b) => order[a.c.status] - order[b.c.status] || pr[a.d.priority] - pr[b.d.priority] || a.d.nextDue.localeCompare(b.d.nextDue))
  }, [rows])

  const payments = useMemo(
    () => [...data.debtPayments].sort((a, b) => b.date.localeCompare(a.date)),
    [data.debtPayments],
  )

  return (
    <>
      <PageHeader
        title="Dívidas"
        subtitle="Cadastre cada dívida e registre pagamentos parciais ou totais. Cada pagamento vira uma saída única no livro-caixa."
        actions={
          <Button onClick={() => setEditing('new')}>
            <Plus size={16} /> Nova dívida
          </Button>
        }
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-3 xl:grid-cols-6">
        <Stat label="Dívida em aberto" tone="expense" value={brl(k.open)} />
        <Stat label="Total pago" tone="income" value={brl(k.paid)} />
        <Stat label="Parcelas a vencer no mês" value={brl(k.dueMonth)} hint={monthLabel(today.slice(0, 7))} />
        <Stat label="Dívidas atrasadas" tone={k.late ? 'expense' : 'neutral'} value={num(k.late)} />
        <Stat label="Dívidas quitadas" tone="income" value={num(k.done)} />
        <Stat
          label="Previsão de quitação"
          value={k.latest ? formatDate(k.latest) : '—'}
          hint={k.latest ? (k.missingForecast ? 'Parte das dívidas sem dados suficientes' : 'Todas as dívidas ativas') : 'Dados insuficientes'}
        />
      </div>

      <div className="mt-6">
        <Tabs
          value={tab}
          onChange={setTab}
          tabs={[
            { value: 'dividas', label: `Dívidas (${rows.length})` },
            { value: 'pagamentos', label: `Pagamentos (${payments.length})` },
            { value: 'plano', label: 'Planejamento de quitação' },
          ]}
        />

        {tab === 'dividas' &&
          (rows.length === 0 ? (
            <EmptyState
              title="Nenhuma dívida cadastrada"
              text="Cadastre valor, parcelas e vencimento. O saldo, o percentual quitado e a previsão são calculados automaticamente."
              action={<Button onClick={() => setEditing('new')}>Cadastrar dívida</Button>}
            />
          ) : (
            <div className="grid gap-4 lg:grid-cols-2">
              {sorted.map(({ d, c }) => (
                <DebtCard key={d.id} d={d} c={c} onPay={() => setPaying(d)} onEdit={() => setEditing(d)} onDelete={() => setDeleting(d)} />
              ))}
            </div>
          ))}

        {tab === 'pagamentos' &&
          (payments.length === 0 ? (
            <EmptyState title="Nenhum pagamento registrado" text="Use o botão “Pagar” em uma dívida para registrar um pagamento parcial ou total." />
          ) : (
            <Card pad={false}>
              <Table head={['Data', 'Dívida', 'Credor', { label: 'Valor', className: 'text-right' }, 'Observações', { label: 'Ações', className: 'text-right' }]}>
                {payments.map((p) => {
                  const d = data.debts.find((x) => x.id === p.debtId)
                  return (
                    <tr key={p.id} className="hover:bg-gray-50/60">
                      <td className="td num">{formatDate(p.date)}</td>
                      <td className="td font-medium">{d?.name ?? '—'}</td>
                      <td className="td text-gray-600">{d?.creditor || '—'}</td>
                      <td className="td num text-right text-expense">{brl(p.amount)}</td>
                      <td className="td max-w-[14rem] truncate text-gray-500">{p.notes || '—'}</td>
                      <td className="td text-right">
                        <Button variant="ghost" size="sm" aria-label={`Excluir pagamento de ${formatDate(p.date)}`} onClick={() => setDelPay(p.id)}>
                          <Trash2 size={14} />
                        </Button>
                      </td>
                    </tr>
                  )
                })}
                <tr className="bg-gray-50 font-semibold">
                  <td className="td" colSpan={3}>
                    Total pago
                  </td>
                  <td className="td num text-right text-expense">{brl(sum(payments.map((p) => p.amount)))}</td>
                  <td className="td" colSpan={2} />
                </tr>
              </Table>
            </Card>
          ))}

        {tab === 'plano' && <Planner rows={rows.filter((r) => r.c.status !== 'quitada')} />}
      </div>

      <DebtForm debt={editing} onClose={() => setEditing(null)} />
      <PayDebt debt={paying} onClose={() => setPaying(null)} />
      <ConfirmDialog
        open={!!deleting}
        danger
        title="Excluir dívida"
        confirmLabel="Excluir"
        text={deleting ? `Excluir "${deleting.name}"? Os pagamentos registrados e seus lançamentos no livro-caixa também serão removidos.` : ''}
        onClose={() => setDeleting(null)}
        onConfirm={() => {
          if (deleting) {
            actions.deleteDebt(deleting.id)
            notify('Dívida excluída.')
          }
        }}
      />
      <ConfirmDialog
        open={!!delPay}
        danger
        title="Excluir pagamento"
        confirmLabel="Excluir"
        text="O saldo da dívida será recalculado e o lançamento no livro-caixa removido."
        onClose={() => setDelPay(null)}
        onConfirm={() => {
          if (delPay) {
            actions.deleteDebtPayment(delPay)
            notify('Pagamento excluído.')
          }
        }}
      />
    </>
  )
}

function DebtCard({ d, c, onPay, onEdit, onDelete }: { d: Debt; c: DebtCalc; onPay: () => void; onEdit: () => void; onDelete: () => void }) {
  const done = c.status === 'quitada'
  return (
    <Card className={done ? 'opacity-80' : ''}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="truncate text-base font-semibold text-gray-900">{d.name}</h3>
          <p className="text-xs text-gray-500">
            {d.creditor || 'Sem credor'} · {d.category || 'Sem categoria'}
          </p>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-1">
          <Badge tone={STATUS_TONE[c.status]}>{STATUS_LABEL[c.status]}</Badge>
          <Badge tone={d.priority === 'alta' ? 'expense' : d.priority === 'media' ? 'warn' : 'neutral'}>Prioridade {PRIORITY_LABEL[d.priority].toLowerCase()}</Badge>
        </div>
      </div>

      <div className="mt-4 flex items-end justify-between">
        <div>
          <p className="text-xs text-gray-500">Saldo restante</p>
          <p className={`num text-2xl font-semibold ${done ? 'text-income' : 'text-expense'}`}>{brl(c.remaining)}</p>
        </div>
        <p className="num text-right text-xs text-gray-500">
          de {brl(c.totalOwed)}
          <br />
          pago {brl(c.paidTotal)}
        </p>
      </div>

      <div className="mt-3">
        <ProgressBar value={c.pct} tone={done ? 'income' : c.status === 'atrasada' ? 'expense' : 'neutral'} label={`${d.name}: ${pct(c.pct)} quitado`} />
        <div className="mt-1 flex justify-between text-xs text-gray-500">
          <span>{pct(c.pct, 1)} quitado</span>
          <span>
            {d.totalInstallments > 0 ? `${c.paidInstallments}/${d.totalInstallments} parcelas` : `${c.paidInstallments} parcela(s) pagas`}
            {!done && c.remainingInstallments > 0 ? ` · faltam ${c.remainingInstallments}` : ''}
          </span>
        </div>
      </div>

      <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
        <div className="flex justify-between">
          <dt className="text-gray-500">Parcela</dt>
          <dd className="num font-medium">{d.installmentValue ? brl(d.installmentValue) : '—'}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="text-gray-500">Próximo venc.</dt>
          <dd className={`num font-medium ${c.status === 'atrasada' ? 'text-expense' : ''}`}>{done ? '—' : formatDate(d.nextDue)}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="text-gray-500">Juros</dt>
          <dd className="num font-medium">{d.interestRate > 0 ? `${num(d.interestRate, 2)}% a.m.` : 'não informado'}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="text-gray-500">Previsão de quitação</dt>
          <dd className="num font-medium">{done ? 'Quitada' : c.payoffDate ? formatDate(c.payoffDate) : '—'}</dd>
        </div>
      </dl>
      {d.notes && <p className="mt-2 line-clamp-2 text-xs text-gray-500">{d.notes}</p>}

      <div className="mt-4 flex flex-wrap gap-2 border-t border-gray-100 pt-3">
        <Button size="sm" onClick={onPay} disabled={done}>
          <HandCoins size={14} /> Registrar pagamento
        </Button>
        <Button variant="secondary" size="sm" onClick={onEdit} aria-label={`Editar ${d.name}`}>
          <Pencil size={14} /> Editar
        </Button>
        <Button variant="ghost" size="sm" onClick={onDelete} aria-label={`Excluir ${d.name}`}>
          <Trash2 size={14} />
        </Button>
      </div>
    </Card>
  )
}

function PayDebt({ debt, onClose }: { debt: Debt | null; onClose: () => void }) {
  const { data, actions, today, notify } = useApp()
  const [amount, setAmount] = useState('')
  const [date, setDate] = useState(today)
  const [notes, setNotes] = useState('')
  const [err, setErr] = useState('')
  const [key, setKey] = useState<Debt | null>(null)
  const c = debt ? calcDebt(debt, data.debtPayments, today) : null

  if (debt !== key) {
    setKey(debt)
    if (debt) {
      const calc = calcDebt(debt, data.debtPayments, today)
      const next = pendingInstallments(debt, calc)[0]?.amount ?? calc.remaining
      setAmount(String(round2(Math.min(next, calc.remaining))).replace('.', ','))
      setDate(today)
      setNotes('')
      setErr('')
    }
  }

  const submit = () => {
    if (!debt) return
    const v = parseNumber(amount)
    if (!Number.isFinite(v) || v <= 0) return setErr('Informe um valor maior que zero.')
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return setErr('Informe a data do pagamento.')
    const e = actions.addDebtPayment({ debtId: debt.id, amount: v, date, notes: notes.trim() })
    if (e) return setErr(e)
    notify(`Pagamento de ${brl(v)} registrado em "${debt.name}".`)
    onClose()
  }

  return (
    <Modal
      open={!!debt}
      onClose={onClose}
      title="Registrar pagamento"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={submit}>Registrar</Button>
        </>
      }
    >
      {debt && c && (
        <form
          className="space-y-4"
          noValidate
          onSubmit={(e) => {
            e.preventDefault()
            submit()
          }}
        >
          <p className="text-sm text-gray-600">
            <span className="font-medium text-gray-900">{debt.name}</span> · saldo <span className="num font-medium text-expense">{brl(c.remaining)}</span>
          </p>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Valor pago (R$)" error={err && /valor|saldo|quitada/i.test(err) ? err : undefined}>
              <Input inputMode="decimal" value={amount} onChange={(e) => { setAmount(e.target.value); setErr('') }} invalid={!!err} />
            </Field>
            <Field label="Data" error={err && /data/i.test(err) ? err : undefined}>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </Field>
          </div>
          <div className="flex flex-wrap gap-2">
            {debt.installmentValue > 0 && (
              <Button variant="secondary" size="sm" onClick={() => setAmount(String(Math.min(debt.installmentValue, c.remaining)).replace('.', ','))}>
                Uma parcela
              </Button>
            )}
            <Button variant="secondary" size="sm" onClick={() => setAmount(String(c.remaining).replace('.', ','))}>
              Quitar tudo ({brl(c.remaining)})
            </Button>
          </div>
          <Field label="Observações (opcional)">
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} maxLength={300} />
          </Field>
          {err && !/valor|saldo|quitada|data/i.test(err) && <Notice tone="danger">{err}</Notice>}
          <p className="text-xs text-gray-500">O pagamento é contado uma única vez, como saída em “Pagamento de dívidas”. Não cadastre a mesma parcela também como despesa.</p>
          <button type="submit" className="hidden" aria-hidden tabIndex={-1} />
        </form>
      )}
    </Modal>
  )
}

function DebtForm({ debt, onClose }: { debt: Debt | 'new' | null; onClose: () => void }) {
  const { data, actions, today, notify } = useApp()
  const existing = debt && debt !== 'new' ? debt : null
  const [f, setF] = useState<Record<string, string>>({})
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [key, setKey] = useState<unknown>(null)
  const money = (n: number) => (n ? String(n).replace('.', ',') : '')

  if (debt !== key) {
    setKey(debt)
    if (debt) {
      setF({
        name: existing?.name ?? '',
        creditor: existing?.creditor ?? '',
        category: existing?.category ?? DEBT_CATEGORIES[0],
        original: money(existing?.originalAmount ?? 0),
        current: money(existing?.currentAmount ?? 0),
        down: money(existing?.downPayment ?? 0),
        total: existing ? String(existing.totalInstallments || '') : '',
        inst: money(existing?.installmentValue ?? 0),
        paidInit: existing ? String(existing.paidInstallmentsInitial || '') : '',
        rate: money(existing?.interestRate ?? 0),
        contract: existing?.contractDate ?? today,
        next: existing?.nextDue ?? '',
        status: existing?.status ?? 'ativa',
        priority: existing?.priority ?? 'media',
        notes: existing?.notes ?? '',
      })
      setErrors({})
    }
  }
  const set = (k: string) => (e: { target: { value: string } }) => setF((p) => ({ ...p, [k]: e.target.value }))

  const used = existing ? data.debtPayments.filter((p) => p.debtId === existing.id).length : 0

  const save = () => {
    const e: Record<string, string> = {}
    const opt = (k: string) => (f[k]?.trim() ? parseNumber(f[k]) : 0)
    const original = parseNumber(f.original)
    const current = opt('current')
    const down = opt('down')
    const inst = opt('inst')
    const total = f.total?.trim() ? Number(f.total) : 0
    const paidInit = f.paidInit?.trim() ? Number(f.paidInit) : 0
    const rate = opt('rate')
    if (!f.name?.trim()) e.name = 'Informe o nome da dívida.'
    if (!Number.isFinite(original) || original <= 0) e.original = 'Informe o valor original.'
    if (!Number.isFinite(current) || current < 0) e.current = 'Valor inválido.'
    if (!Number.isFinite(down) || down < 0) e.down = 'Valor inválido.'
    else if (Number.isFinite(original) && down > original) e.down = 'A entrada não pode superar o valor original.'
    if (!Number.isFinite(inst) || inst < 0) e.inst = 'Valor inválido.'
    if (!Number.isInteger(total) || total < 0 || total > 600) e.total = 'Use um número inteiro de 0 a 600.'
    if (!Number.isInteger(paidInit) || paidInit < 0) e.paidInit = 'Use um número inteiro.'
    else if (total > 0 && paidInit > total) e.paidInit = 'Não pode superar o total de parcelas.'
    if (!Number.isFinite(rate) || rate < 0 || rate > 100) e.rate = 'Informe de 0 a 100.'
    if (f.next && !/^\d{4}-\d{2}-\d{2}$/.test(f.next)) e.next = 'Data inválida.'
    if (!Object.keys(e).length && inst > 0 && !f.next) e.next = 'Informe o vencimento da próxima parcela.'
    setErrors(e)
    if (Object.keys(e).length) return
    const payload: Omit<Debt, 'id'> = {
      name: f.name.trim(),
      creditor: f.creditor.trim(),
      category: f.category,
      originalAmount: original,
      currentAmount: current,
      downPayment: down,
      totalInstallments: total,
      installmentValue: inst,
      paidInstallmentsInitial: paidInit,
      interestRate: rate,
      contractDate: f.contract,
      nextDue: f.next,
      status: f.status as DebtStatus,
      priority: f.priority as Priority,
      notes: f.notes.trim(),
    }
    if (existing) {
      actions.updateDebt(existing.id, payload)
      notify('Dívida atualizada.')
    } else {
      actions.addDebt(payload)
      notify('Dívida cadastrada.')
    }
    onClose()
  }

  const L = (k: string) => errors[k]
  return (
    <Modal
      open={debt !== null}
      onClose={onClose}
      wide
      title={existing ? 'Editar dívida' : 'Nova dívida'}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={save}>Salvar</Button>
        </>
      }
    >
      <form
        className="grid gap-4 sm:grid-cols-2"
        noValidate
        onSubmit={(e) => {
          e.preventDefault()
          save()
        }}
      >
        <Field label="Nome da dívida" error={L('name')}>
          <Input value={f.name ?? ''} onChange={set('name')} invalid={!!L('name')} maxLength={80} placeholder="Ex.: Empréstimo pessoal" />
        </Field>
        <Field label="Credor">
          <Input value={f.creditor ?? ''} onChange={set('creditor')} maxLength={80} />
        </Field>
        <Field label="Categoria">
          <Select value={f.category ?? ''} onChange={set('category')}>
            {[...new Set([...DEBT_CATEGORIES, f.category].filter(Boolean))].map((c) => (
              <option key={c}>{c}</option>
            ))}
          </Select>
        </Field>
        <Field label="Valor original (R$)" error={L('original')}>
          <Input inputMode="decimal" value={f.original ?? ''} onChange={set('original')} invalid={!!L('original')} />
        </Field>
        <Field label="Valor atualizado (R$)" error={L('current')} hint="Deixe vazio para usar o valor original menos a entrada.">
          <Input inputMode="decimal" value={f.current ?? ''} onChange={set('current')} invalid={!!L('current')} />
        </Field>
        <Field label="Valor de entrada (R$)" error={L('down')}>
          <Input inputMode="decimal" value={f.down ?? ''} onChange={set('down')} invalid={!!L('down')} />
        </Field>
        <Field label="Quantidade total de parcelas" error={L('total')}>
          <Input inputMode="numeric" value={f.total ?? ''} onChange={set('total')} invalid={!!L('total')} />
        </Field>
        <Field label="Valor da parcela (R$)" error={L('inst')}>
          <Input inputMode="decimal" value={f.inst ?? ''} onChange={set('inst')} invalid={!!L('inst')} />
        </Field>
        <Field label="Parcelas já pagas antes do cadastro" error={L('paidInit')} hint={used ? `Já há ${used} pagamento(s) registrado(s) no sistema, somados a este valor.` : 'Pagamentos feitos daqui para frente são registrados no botão “Registrar pagamento”.'}>
          <Input inputMode="numeric" value={f.paidInit ?? ''} onChange={set('paidInit')} invalid={!!L('paidInit')} />
        </Field>
        <Field label="Taxa de juros (% ao mês)" error={L('rate')} hint="Opcional. Usada apenas nas simulações.">
          <Input inputMode="decimal" value={f.rate ?? ''} onChange={set('rate')} invalid={!!L('rate')} />
        </Field>
        <Field label="Data da contratação">
          <Input type="date" value={f.contract ?? ''} onChange={set('contract')} />
        </Field>
        <Field label="Vencimento da próxima parcela" error={L('next')}>
          <Input type="date" value={f.next ?? ''} onChange={set('next')} invalid={!!L('next')} />
        </Field>
        <Field label="Situação">
          <Select value={f.status ?? 'ativa'} onChange={set('status')}>
            <option value="ativa">Ativa</option>
            <option value="negociacao">Em negociação</option>
          </Select>
        </Field>
        <Field label="Prioridade">
          <Select value={f.priority ?? 'media'} onChange={set('priority')}>
            <option value="alta">Alta</option>
            <option value="media">Média</option>
            <option value="baixa">Baixa</option>
          </Select>
        </Field>
        <Field label="Observações" className="sm:col-span-2">
          <Textarea value={f.notes ?? ''} onChange={set('notes')} rows={2} maxLength={400} />
        </Field>
        <button type="submit" className="hidden" aria-hidden tabIndex={-1} />
      </form>
    </Modal>
  )
}

/* Planejamento de quitação ---------------------------------------- */

function Planner({ rows }: { rows: { d: Debt; c: DebtCalc }[] }) {
  const { today } = useApp()
  const [id, setId] = useState<string>('todas')
  const [extra, setExtra] = useState('')
  const [lump, setLump] = useState('')
  const [rateTxt, setRateTxt] = useState('')

  if (rows.length === 0) return <EmptyState title="Nada a planejar" text="Quando houver dívidas em aberto, você poderá simular pagamentos extras aqui." />

  const selected = id === 'todas' ? rows : rows.filter((r) => r.d.id === id)
  const balance = sum(selected.map((r) => r.c.remaining))
  const payment = sum(selected.map((r) => Math.min(r.d.installmentValue || 0, r.c.remaining)))
  const knownRate = id !== 'todas' ? selected[0]?.d.interestRate ?? 0 : 0
  const extraN = extra.trim() ? parseNumber(extra) : 0
  const lumpN = lump.trim() ? parseNumber(lump) : 0
  const rateN = rateTxt.trim() ? parseNumber(rateTxt) : knownRate
  const invalid = [extraN, lumpN, rateN].some((n) => !Number.isFinite(n) || n < 0)
  const base = { balance, payment, extraMonthly: 0, lumpSum: 0, monthlyRate: invalid ? 0 : rateN }
  const a = simulatePayoff(base)
  const b = simulatePayoff({ ...base, extraMonthly: invalid ? 0 : extraN, lumpSum: invalid ? 0 : lumpN })
  const hasScenario = !invalid && (extraN > 0 || lumpN > 0)

  const len = Math.max(a.balances.length, b.balances.length, 1)
  const series = Array.from({ length: Math.min(len, 120) + 1 }, (_, i) => ({
    mes: i === 0 ? 'Hoje' : monthLabel(addMonths(`${today.slice(0, 7)}-01`, i).slice(0, 7)).slice(0, 3) + '/' + addMonths(`${today.slice(0, 7)}-01`, i).slice(2, 4),
    atual: i === 0 ? balance : a.balances[i - 1] ?? 0,
    cenario: i === 0 ? Math.max(0, balance - (hasScenario ? lumpN : 0)) : b.balances[i - 1] ?? 0,
  }))

  const monthsLabel = (r: ReturnType<typeof simulatePayoff>) => (!r.ok ? 'Não quita' : r.months === 0 ? 'Imediato' : `${r.months} mes(es)`)
  const dateFor = (r: ReturnType<typeof simulatePayoff>) => (r.ok && r.months > 0 ? formatDate(addMonths(today, r.months)) : '—')

  return (
    <div className="space-y-4">
      <Card title="Simulação" subtitle="Compara o ritmo atual de parcelas com um cenário de pagamentos extras. Nada é pago automaticamente.">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Dívida">
            <Select value={id} onChange={(e) => setId(e.target.value)}>
              <option value="todas">Todas as dívidas em aberto</option>
              {rows.map((r) => (
                <option key={r.d.id} value={r.d.id}>
                  {r.d.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Pagamento extra por mês (R$)">
            <Input inputMode="decimal" value={extra} onChange={(e) => setExtra(e.target.value)} placeholder="0,00" />
          </Field>
          <Field label="Pagamento único agora (R$)">
            <Input inputMode="decimal" value={lump} onChange={(e) => setLump(e.target.value)} placeholder="0,00" />
          </Field>
          <Field label="Juros % ao mês (opcional)" hint={knownRate > 0 ? `Usando a taxa cadastrada (${num(knownRate, 2)}%).` : 'Vazio = sem juros.'}>
            <Input inputMode="decimal" value={rateTxt} onChange={(e) => setRateTxt(e.target.value)} placeholder={knownRate > 0 ? String(knownRate).replace('.', ',') : '0'} />
          </Field>
        </div>
        {invalid && <Notice tone="danger" className="mt-3">Confira os valores informados: use apenas números maiores ou iguais a zero.</Notice>}
        {payment <= 0 && <Notice tone="warn" className="mt-3">As dívidas selecionadas não têm valor de parcela. Informe um pagamento extra mensal para simular.</Notice>}
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <Card title="Ritmo atual">
          <Scenario r={a} months={monthsLabel(a)} date={dateFor(a)} payment={payment} />
        </Card>
        <Card title="Cenário com extras" subtitle={hasScenario ? undefined : 'Informe um valor extra para comparar.'}>
          {hasScenario ? (
            <>
              <Scenario r={b} months={monthsLabel(b)} date={dateFor(b)} payment={payment + extraN} />
              {a.ok && b.ok && (
                <p className="mt-3 rounded-xl bg-emerald-50 px-3 py-2 text-sm text-emerald-900">
                  Antecipa a quitação em <strong>{Math.max(0, a.months - b.months)} mes(es)</strong>
                  {a.totalInterest > 0 && <> e economiza <strong className="num">{brl(Math.max(0, a.totalInterest - b.totalInterest))}</strong> em juros</>}.
                </p>
              )}
            </>
          ) : (
            <p className="text-sm text-gray-500">Sem cenário simulado.</p>
          )}
        </Card>
      </div>

      <Card title="Evolução do saldo devedor" subtitle="Projeção mês a mês">
        <ChartBox height={240} empty={!a.ok && !b.ok && a.balances.length === 0 ? 'Informe parcelas ou pagamentos extras para ver a projeção.' : undefined}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={series} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
              <CartesianGrid vertical={false} stroke="#eef0f2" />
              <XAxis dataKey="mes" tickLine={false} axisLine={false} interval="preserveStartEnd" />
              <YAxis tickFormatter={axisMoney} tickLine={false} axisLine={false} />
              <Tooltip content={<MoneyTooltip />} />
              <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
              <Line type="monotone" dataKey="atual" name="Ritmo atual" stroke={COLORS.expense} strokeWidth={2} dot={false} />
              {hasScenario && <Line type="monotone" dataKey="cenario" name="Com extras" stroke={COLORS.income} strokeWidth={2} dot={false} />}
            </LineChart>
          </ResponsiveContainer>
        </ChartBox>
      </Card>
    </div>
  )
}

function Scenario({ r, months, date, payment }: { r: ReturnType<typeof simulatePayoff>; months: string; date: string; payment: number }) {
  return (
    <dl className="space-y-2 text-sm">
      <div className="flex justify-between">
        <dt className="text-gray-500">Pagamento mensal</dt>
        <dd className="num font-medium">{brl(payment)}</dd>
      </div>
      <div className="flex justify-between">
        <dt className="text-gray-500">Prazo para quitar</dt>
        <dd className={`num font-medium ${r.ok ? '' : 'text-expense'}`}>{months}</dd>
      </div>
      <div className="flex justify-between">
        <dt className="text-gray-500">Previsão de quitação</dt>
        <dd className="num font-medium">{date}</dd>
      </div>
      <div className="flex justify-between">
        <dt className="text-gray-500">Total pago</dt>
        <dd className="num font-medium">{brl(r.totalPaid)}</dd>
      </div>
      <div className="flex justify-between">
        <dt className="text-gray-500">Juros estimados</dt>
        <dd className="num font-medium">{brl(r.totalInterest)}</dd>
      </div>
      {!r.ok && <p className="text-xs text-expense">Com este pagamento a dívida não é quitada. Aumente o valor mensal.</p>}
    </dl>
  )
}
