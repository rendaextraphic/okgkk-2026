import { useRef, useState, type ChangeEvent } from 'react'
import { Download, Plus, RotateCcw, ShieldAlert, Trash2, Upload, X } from 'lucide-react'
import { useApp } from '../store/store'
import type { Item, Settings } from '../types'
import { uid, parseNumber, brl, num } from '../lib/format'
import { hourlyRate } from '../lib/calc'
import { downloadFile, toCSV } from '../lib/csv'
import { formatDate } from '../lib/format'
import { AccessCard } from '../auth/AccessCard'
import { Button, Card, ConfirmDialog, Field, Input, Modal, Notice, PageHeader, Segmented, Select, Tabs } from '../components/ui'

type Tab = 'remuneracao' | 'regras' | 'categorias' | 'planejamento' | 'aparencia' | 'dados'

/** Campo numérico com texto livre: só grava quando o valor é válido. */
function NumField({
  label,
  value,
  onCommit,
  min = 0,
  max = 1_000_000_000,
  hint,
  integer,
  suffix,
}: {
  label: string
  value: number
  onCommit: (n: number) => void
  min?: number
  max?: number
  hint?: string
  integer?: boolean
  suffix?: string
}) {
  const [text, setText] = useState<string | null>(null)
  const shown = text ?? String(value).replace('.', ',')
  const n = parseNumber(shown)
  const err = text !== null && (!Number.isFinite(n) || n < min || n > max || (integer && !Number.isInteger(n)))
  return (
    <Field label={label} hint={hint} error={err ? `Informe ${integer ? 'um inteiro' : 'um número'} entre ${num(min, 2)} e ${num(max, 0)}.` : null}>
      <div className="relative">
        <Input
          inputMode="decimal"
          value={shown}
          invalid={err}
          onChange={(e) => {
            setText(e.target.value)
            const v = parseNumber(e.target.value)
            if (Number.isFinite(v) && v >= min && v <= max && (!integer || Number.isInteger(v))) onCommit(v)
          }}
          onBlur={() => setText(null)}
          className={suffix ? 'pr-10' : ''}
        />
        {suffix && <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">{suffix}</span>}
      </div>
    </Field>
  )
}

function Toggle({ checked, onChange, label, hint }: { checked: boolean; onChange: (v: boolean) => void; label: string; hint?: string }) {
  return (
    <label className="flex cursor-pointer items-start gap-3">
      <input type="checkbox" role="switch" className="mt-1 h-4 w-4" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span>
        <span className="block text-sm font-medium text-gray-800">{label}</span>
        {hint && <span className="block text-xs text-gray-500">{hint}</span>}
      </span>
    </label>
  )
}

function ItemList({ title, items, onChange, addLabel }: { title: string; items: Item[]; onChange: (i: Item[]) => void; addLabel: string }) {
  return (
    <div>
      <p className="mb-2 text-xs font-medium text-gray-600">{title}</p>
      {items.length === 0 && <p className="mb-2 text-sm text-gray-500">Nenhum item.</p>}
      <ul className="space-y-2">
        {items.map((it, i) => (
          <li key={it.id} className="flex gap-2">
            <Input aria-label="Nome" placeholder="Nome" value={it.name} maxLength={60} onChange={(e) => onChange(items.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))} />
            <Input
              aria-label="Valor"
              className="w-32"
              inputMode="decimal"
              defaultValue={String(it.amount).replace('.', ',')}
              onChange={(e) => {
                const v = parseNumber(e.target.value)
                if (Number.isFinite(v) && v >= 0) onChange(items.map((x, j) => (j === i ? { ...x, amount: v } : x)))
              }}
            />
            <Button variant="ghost" aria-label="Remover item" onClick={() => onChange(items.filter((_, j) => j !== i))}>
              <Trash2 size={15} />
            </Button>
          </li>
        ))}
      </ul>
      <Button variant="secondary" size="sm" className="mt-2" onClick={() => onChange([...items, { id: uid(), name: '', amount: 0 }])}>
        <Plus size={14} /> {addLabel}
      </Button>
    </div>
  )
}

function StringList({ title, items, onChange, hint, protect }: { title: string; items: string[]; onChange: (i: string[]) => void; hint?: string; protect?: (name: string) => string | null }) {
  const [value, setValue] = useState('')
  const [err, setErr] = useState('')
  const add = () => {
    const v = value.trim()
    if (!v) return setErr('Digite um nome.')
    if (items.some((i) => i.toLowerCase() === v.toLowerCase())) return setErr('Esse nome já existe.')
    onChange([...items, v])
    setValue('')
    setErr('')
  }
  return (
    <div>
      <p className="mb-1 text-xs font-medium text-gray-600">{title}</p>
      {hint && <p className="mb-2 text-xs text-gray-500">{hint}</p>}
      <ul className="mb-3 flex flex-wrap gap-2">
        {items.map((c) => {
          const blocked = protect?.(c) ?? null
          return (
            <li key={c} className="inline-flex items-center gap-1 rounded-full bg-gray-100 py-1 pl-3 pr-1.5 text-xs text-gray-800">
              {c}
              <button
                type="button"
                aria-label={`Remover ${c}`}
                title={blocked ?? 'Remover'}
                disabled={!!blocked}
                onClick={() => onChange(items.filter((x) => x !== c))}
                className="rounded-full p-1 text-gray-500 hover:bg-gray-200 disabled:cursor-not-allowed disabled:opacity-30"
              >
                <X size={12} />
              </button>
            </li>
          )
        })}
      </ul>
      <div className="flex max-w-sm gap-2">
        <Input
          aria-label={`Adicionar a ${title}`}
          value={value}
          maxLength={40}
          invalid={!!err}
          onChange={(e) => {
            setValue(e.target.value)
            setErr('')
          }}
          onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), add())}
          placeholder="Nova…"
        />
        <Button variant="secondary" onClick={add}>
          Adicionar
        </Button>
      </div>
      {err && (
        <p role="alert" className="mt-1 text-xs font-medium text-expense">
          {err}
        </p>
      )}
    </div>
  )
}

export function Configuracoes() {
  const { data, actions, notify } = useApp()
  const s = data.settings
  const up = (patch: Partial<Settings>) => actions.updateSettings(patch)
  const [tab, setTab] = useState<Tab>('remuneracao')
  const [confirm, setConfirm] = useState<'reset' | 'wipe' | null>(null)
  const [wipeText, setWipeText] = useState('')
  const [importErr, setImportErr] = useState<string[] | null>(null)
  const [pending, setPending] = useState<{ text: string; name: string } | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  const used = (name: string, list: 'expense' | 'income'): string | null => {
    if (list === 'expense' && data.expenses.some((e) => e.category === name)) return 'Categoria em uso por despesas.'
    if (data.transactions.some((t) => t.category === name)) return 'Categoria em uso por lançamentos.'
    if (['Outros', 'Despesas pessoais', 'Pagamento de dívidas', 'Salário', 'Transferências', 'Renda extra'].includes(name)) return 'Categoria padrão do sistema.'
    return null
  }

  const exportJSON = () => {
    downloadFile(`meu-controle-backup-${new Date().toISOString().slice(0, 10)}.json`, actions.exportJSON(), 'application/json')
    notify('Backup exportado. Guarde o arquivo em local seguro.')
  }

  const exportCSV = () => {
    const rows: (string | number)[][] = [['Data', 'Tipo', 'Descrição', 'Categoria', 'Valor', 'Conta', 'Origem/Destino', 'Situação', 'Observação']]
    for (const t of [...data.transactions].sort((a, b) => a.date.localeCompare(b.date)))
      rows.push([formatDate(t.date), t.type === 'entrada' ? 'Entrada' : 'Saída', t.description, t.category, t.type === 'entrada' ? t.amount : -t.amount, t.account, t.origin, t.status === 'efetivado' ? 'Efetivado' : 'Previsto', t.notes])
    downloadFile('movimentacoes.csv', toCSV(rows), 'text/csv;charset=utf-8')
    notify('CSV de movimentações exportado.')
  }

  const onFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]
    e.target.value = ''
    if (!f) return
    setImportErr(null)
    if (f.size > 20 * 1024 * 1024) return setImportErr(['Arquivo muito grande (limite de 20 MB).'])
    try {
      setPending({ text: await f.text(), name: f.name })
    } catch {
      setImportErr(['Não foi possível ler o arquivo.'])
    }
  }

  const applyImport = () => {
    if (!pending) return
    const r = actions.importJSON(pending.text)
    if (r.ok) {
      notify('Backup restaurado com sucesso.')
      setImportErr(null)
    } else setImportErr(r.errors)
    setPending(null)
  }

  const hr = hourlyRate(s)

  return (
    <>
      <PageHeader title="Configurações" subtitle="Todos os valores são editáveis. As alterações valem para os cálculos de todas as competências, exceto os parâmetros específicos de cada mês." />

      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { value: 'remuneracao', label: 'Remuneração' },
          { value: 'regras', label: 'Regras de cálculo' },
          { value: 'categorias', label: 'Categorias e contas' },
          { value: 'planejamento', label: 'Metas e orçamentos' },
          { value: 'aparencia', label: 'Aparência e formatos' },
          { value: 'dados', label: 'Dados e backup' },
        ]}
      />

      {tab === 'remuneracao' && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Salário e adicionais">
            <div className="grid gap-4 sm:grid-cols-2">
              <NumField label="Salário-base mensal (R$)" value={s.baseSalary} onCommit={(v) => up({ baseSalary: v })} />
              <NumField label="Adicional noturno (%)" value={s.nightPct} max={500} onCommit={(v) => up({ nightPct: v })} suffix="%" />
              <NumField label="Assiduidade (R$)" value={s.attendance} onCommit={(v) => up({ attendance: v })} />
              <div className="flex items-end pb-2">
                <Toggle checked={s.attendanceEnabled} onChange={(v) => up({ attendanceEnabled: v })} label="Assiduidade ativa" hint="Desative nos meses em que não for paga." />
              </div>
            </div>
          </Card>

          <Card title="Valor por unidade" subtitle="Padrão sugerido ao registrar produtividade">
            <div className="grid gap-4 sm:grid-cols-2">
              <NumField label="Conferência (R$ por unidade)" value={s.rateConferencia} onCommit={(v) => up({ rateConferencia: v })} max={10000} />
              <NumField label="Separação (R$ por unidade)" value={s.rateSeparacao} onCommit={(v) => up({ rateSeparacao: v })} max={10000} />
            </div>
            <p className="mt-3 text-xs text-gray-500">Registros já lançados mantêm o valor unitário usado na data. Edite o registro para recalcular.</p>
          </Card>

          <Card title="Vale-transporte e descontos">
            <div className="space-y-4">
              <Field label="Vale-transporte">
                <Select value={s.vtMode} onChange={(e) => up({ vtMode: e.target.value as Settings['vtMode'] })}>
                  <option value="percentual">Percentual do salário-base</option>
                  <option value="valor">Valor fixo</option>
                  <option value="nenhum">Não há desconto</option>
                </Select>
              </Field>
              {s.vtMode === 'percentual' && <NumField label="Percentual (%)" value={s.vtPercent} max={100} suffix="%" onCommit={(v) => up({ vtPercent: v })} hint={`Desconto atual: ${brl((s.baseSalary * s.vtPercent) / 100)}`} />}
              {s.vtMode === 'valor' && <NumField label="Valor do desconto (R$)" value={s.vtFixed} onCommit={(v) => up({ vtFixed: v })} />}
              <NumField label="Adiantamentos padrão por mês (R$)" value={s.advances} onCommit={(v) => up({ advances: v })} hint="Ajustável mês a mês na tela Salário." />
              <ItemList title="Outros descontos" items={s.otherDeductions} onChange={(i) => up({ otherDeductions: i })} addLabel="Adicionar desconto" />
            </div>
          </Card>

          <Card title="INSS e descontos legais" subtitle="O sistema não aplica alíquotas por conta própria">
            <div className="space-y-4">
              <Notice tone="warn">Informe o que consta no seu holerite. Tabelas e alíquotas mudam todo ano e dependem do seu contrato; sem preencher aqui, o valor aparece como “a confirmar”.</Notice>
              <Field label="Como informar">
                <Select value={s.inss.mode} onChange={(e) => up({ inss: { ...s.inss, mode: e.target.value as Settings['inss']['mode'] } })}>
                  <option value="nenhum">Não calcular (a confirmar)</option>
                  <option value="valor">Valor fixo em R$</option>
                  <option value="percentual">Percentual efetivo sobre o bruto</option>
                </Select>
              </Field>
              {s.inss.mode !== 'nenhum' && (
                <>
                  <NumField label={s.inss.mode === 'valor' ? 'Valor (R$)' : 'Percentual (%)'} value={s.inss.value} max={s.inss.mode === 'valor' ? 1_000_000 : 100} onCommit={(v) => up({ inss: { ...s.inss, value: v } })} />
                  <Field label="Competência / regra aplicada (anotação)">
                    <Input value={s.inss.competence} maxLength={80} onChange={(e) => up({ inss: { ...s.inss, competence: e.target.value } })} placeholder="Ex.: tabela vigente em 10/2026" />
                  </Field>
                </>
              )}
            </div>
          </Card>

          <Card title="Outros adicionais" className="lg:col-span-2">
            <ItemList title="Somados ao total bruto todo mês" items={s.otherAdditions} onChange={(i) => up({ otherAdditions: i })} addLabel="Adicionar adicional" />
            <div className="mt-5 grid gap-4 sm:grid-cols-3">
              <div className="sm:col-span-3">
                <Toggle checked={s.overtimeEnabled} onChange={(v) => up({ overtimeEnabled: v })} label="Habilitar horas extras" hint="Calculadas sobre o valor da hora normal acrescido do percentual." />
              </div>
              {s.overtimeEnabled && (
                <>
                  <NumField label="Horas extras no mês (padrão)" value={s.overtimeHours} max={744} onCommit={(v) => up({ overtimeHours: v })} />
                  <NumField label="Acréscimo (%)" value={s.overtimePct} max={500} suffix="%" onCommit={(v) => up({ overtimePct: v })} />
                </>
              )}
            </div>
          </Card>
        </div>
      )}

      {tab === 'regras' && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Jornada e valor da hora">
            <div className="grid gap-4 sm:grid-cols-2">
              <NumField label="Jornada mensal (horas)" value={s.monthlyHours} min={1} max={744} onCommit={(v) => up({ monthlyHours: v })} hint="Divisor do salário. Ex.: 220 h para 44 h semanais." />
              <NumField label="Valor da hora normal (R$)" value={s.hourlyRateOverride} onCommit={(v) => up({ hourlyRateOverride: v })} hint="Deixe 0 para calcular pelo salário-base." />
            </div>
            <p className="mt-3 rounded-xl bg-gray-50 px-3 py-2 text-sm">
              Hora normal usada nos cálculos: <strong className="num">{brl(hr)}</strong>
            </p>
          </Card>

          <Card title="Adicional noturno" subtitle="Calculado sobre as horas noturnas realizadas, nunca sobre o salário inteiro">
            <div className="grid gap-4 sm:grid-cols-2">
              <NumField label="Horas noturnas por dia" value={s.nightHoursPerDay} max={24} onCommit={(v) => up({ nightHoursPerDay: v })} />
              <NumField label="Dias trabalhados no mês" value={s.workedDays} max={31} integer onCommit={(v) => up({ workedDays: v })} />
            </div>
            <div className="mt-4">
              <Toggle checked={s.nightReducedHour} onChange={(v) => up({ nightReducedHour: v })} label="Aplicar hora noturna reduzida (52 min 30 s)" hint="Marque se o seu contrato ou convenção prevê. Aumenta as horas equivalentes." />
            </div>
            <p className="mt-3 rounded-xl bg-gray-50 px-3 py-2 text-sm">
              Estimativa mensal: <strong className="num">{num(s.nightHoursPerDay * s.workedDays, 1)} h</strong> × {brl(hr)} × {num(s.nightPct, 1)}% ={' '}
              <strong className="num">{brl(hr * (s.nightPct / 100) * (s.nightReducedHour ? (s.nightHoursPerDay * s.workedDays * 60) / 52.5 : s.nightHoursPerDay * s.workedDays))}</strong>
            </p>
            <p className="mt-2 text-xs text-gray-500">Ajuste as horas de cada mês na tela Salário. Confira a regra no seu contrato.</p>
          </Card>

          <Card title="Período da folha e pagamento">
            <div className="grid gap-4 sm:grid-cols-2">
              <NumField label="Dia de início da folha" value={s.payrollStartDay} min={1} max={28} integer onCommit={(v) => up({ payrollStartDay: v })} hint="1 = mês-calendário. Ex.: 21 → de 21 a 20." />
              <NumField label="Dia previsto de pagamento" value={s.payDay} min={1} max={28} integer onCommit={(v) => up({ payDay: v })} />
              <Field label="Pagamento da competência">
                <Select value={String(s.payMonthOffset)} onChange={(e) => up({ payMonthOffset: Number(e.target.value) as 0 | 1 })}>
                  <option value="0">No próprio mês</option>
                  <option value="1">No mês seguinte</option>
                </Select>
              </Field>
            </div>
          </Card>

          <Card title="Produtividade na folha">
            <Field label="Situação do pagamento">
              <Segmented
                label="Situação do pagamento da produtividade"
                value={s.prodPayMode}
                onChange={(v) => up({ prodPayMode: v })}
                options={[
                  { value: 'integral', label: 'Integral' },
                  { value: 'parcial', label: 'Parcial' },
                  { value: 'pendente', label: 'Pendente' },
                ]}
              />
            </Field>
            {s.prodPayMode === 'parcial' && (
              <div className="mt-3 max-w-[12rem]">
                <NumField label="Percentual pago (%)" value={s.prodPartialPct} max={100} suffix="%" onCommit={(v) => up({ prodPartialPct: v })} />
              </div>
            )}
            <p className="mt-3 text-xs text-gray-500">A produtividade elegível compõe o bruto. Ela não deve ser lançada de novo como receita extra.</p>
          </Card>
        </div>
      )}

      {tab === 'categorias' && (
        <div className="grid gap-4">
          <Card title="Categorias de despesas">
            <StringList title="Categorias" items={s.expenseCategories} onChange={(i) => up({ expenseCategories: i })} protect={(n) => used(n, 'expense')} hint="Categorias em uso não podem ser removidas." />
          </Card>
          <Card title="Categorias do livro-caixa">
            <StringList title="Categorias de lançamentos" items={s.incomeCategories} onChange={(i) => up({ incomeCategories: i })} protect={(n) => used(n, 'income')} />
          </Card>
          <Card title="Contas e carteiras">
            <StringList
              title="Contas"
              items={s.accounts}
              onChange={(i) => up({ accounts: i })}
              protect={(n) => (data.transactions.some((t) => t.account === n) ? 'Conta com lançamentos.' : s.accounts.length <= 1 ? 'É necessário ter pelo menos uma conta.' : n === s.accounts[0] ? 'Conta padrão dos lançamentos automáticos.' : null)}
              hint="A primeira conta recebe os lançamentos automáticos de salário, despesas e dívidas."
            />
          </Card>
        </div>
      )}

      {tab === 'planejamento' && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Meta mensal de economia">
            <NumField label="Valor a economizar por mês (R$)" value={s.monthlyGoal} onCommit={(v) => up({ monthlyGoal: v })} hint="0 desativa o alerta de meta." />
          </Card>
          <Card title="Orçamento por categoria" subtitle="Limite mensal. 0 remove o limite.">
            <div className="grid gap-3 sm:grid-cols-2">
              {s.expenseCategories.map((c) => (
                <NumField
                  key={c}
                  label={c}
                  value={s.budgets[c] ?? 0}
                  onCommit={(v) => {
                    const b = { ...s.budgets }
                    if (v > 0) b[c] = v
                    else delete b[c]
                    up({ budgets: b })
                  }}
                />
              ))}
            </div>
          </Card>
        </div>
      )}

      {tab === 'aparencia' && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title="Relatórios">
            <Field label="Nome exibido nos relatórios" hint="Aparece no cabeçalho dos PDFs.">
              <Input value={s.displayName} maxLength={60} onChange={(e) => up({ displayName: e.target.value })} placeholder="Seu nome" />
            </Field>
          </Card>
          <Card title="Formatos">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Moeda">
                <Select value={s.currency} onChange={(e) => up({ currency: e.target.value as Settings['currency'] })}>
                  <option value="BRL">Real (R$)</option>
                  <option value="USD">Dólar (US$)</option>
                  <option value="EUR">Euro (€)</option>
                </Select>
              </Field>
              <Field label="Datas na tela" hint="Os PDFs sempre usam DD/MM/AAAA.">
                <Select value={s.dateFormat} onChange={(e) => up({ dateFormat: e.target.value as Settings['dateFormat'] })}>
                  <option value="br">DD/MM/AAAA</option>
                  <option value="iso">AAAA-MM-DD</option>
                </Select>
              </Field>
            </div>
          </Card>
          <Card title="Aparência" className="lg:col-span-2">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Cor de destaque">
                <Segmented
                  label="Cor de destaque"
                  value={s.accent}
                  onChange={(v) => up({ accent: v })}
                  options={[
                    { value: 'grafite', label: 'Grafite' },
                    { value: 'verde', label: 'Verde' },
                    { value: 'azul', label: 'Azul' },
                  ]}
                />
              </Field>
              <Field label="Tamanho do texto">
                <Segmented
                  label="Tamanho do texto"
                  value={s.textSize}
                  onChange={(v) => up({ textSize: v })}
                  options={[
                    { value: 'normal', label: 'Normal' },
                    { value: 'grande', label: 'Grande' },
                  ]}
                />
              </Field>
            </div>
          </Card>
        </div>
      )}

      {tab === 'dados' && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card className="lg:col-span-2">
            <div className="flex gap-3">
              <ShieldAlert size={20} className="mt-0.5 shrink-0 text-amber-600" aria-hidden />
              <div className="text-sm text-gray-700">
                <p className="font-semibold text-gray-900">Seus dados ficam apenas neste navegador</p>
                <p className="mt-1">
                  O sistema usa o armazenamento local do navegador (LocalStorage). Não há sincronização entre dispositivos, nem criptografia, e os dados podem ser perdidos se você limpar os dados do site, trocar de navegador/computador ou usar uma janela anônima. Exporte um backup com frequência.
                </p>
              </div>
            </div>
          </Card>

          <Card title="Exportar">
            <div className="flex flex-wrap gap-2">
              <Button onClick={exportJSON}>
                <Download size={16} /> Backup completo (JSON)
              </Button>
              <Button variant="secondary" onClick={exportCSV} disabled={!data.transactions.length}>
                <Download size={16} /> Movimentações (CSV)
              </Button>
            </div>
            <p className="mt-3 text-xs text-gray-500">O JSON contém todos os dados e configurações e pode ser restaurado aqui. O CSV abre no Excel. Atenção: os arquivos exportados NÃO são criptografados; guarde-os em local seguro.</p>
          </Card>

          <Card title="Importar backup">
            <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={onFile} aria-label="Selecionar arquivo de backup" />
            <Button variant="secondary" onClick={() => fileRef.current?.click()}>
              <Upload size={16} /> Selecionar arquivo JSON
            </Button>
            <p className="mt-3 text-xs text-gray-500">O arquivo é validado antes de ser aplicado. A importação substitui todos os dados atuais.</p>
            {importErr && (
              <Notice tone="danger" className="mt-3">
                <p className="font-medium">Não foi possível importar:</p>
                <ul className="mt-1 list-disc pl-4 text-xs">
                  {importErr.map((e) => (
                    <li key={e}>{e}</li>
                  ))}
                </ul>
              </Notice>
            )}
          </Card>

          <AccessCard />

          <Card title="Restaurar padrões das configurações">
            <p className="text-sm text-gray-600">Volta salário, adicionais, valores por unidade e demais configurações aos valores iniciais. Registros e lançamentos não são apagados.</p>
            <Button variant="secondary" className="mt-3" onClick={() => setConfirm('reset')}>
              <RotateCcw size={16} /> Restaurar configurações iniciais
            </Button>
          </Card>

          <Card title="Apagar todos os dados">
            <p className="text-sm text-gray-600">Remove definitivamente registros, despesas, dívidas, lançamentos, metas e configurações deste navegador.</p>
            <Button variant="danger" className="mt-3" onClick={() => { setWipeText(''); setConfirm('wipe') }}>
              <Trash2 size={16} /> Apagar tudo
            </Button>
          </Card>
        </div>
      )}

      <ConfirmDialog
        open={confirm === 'reset'}
        title="Restaurar configurações iniciais"
        text="Todas as configurações voltarão aos valores iniciais (salário-base R$ 2.120,00, adicional noturno 20%, assiduidade R$ 200,00 e R$ 5,00 por unidade). Seus registros continuam intactos."
        confirmLabel="Restaurar"
        onClose={() => setConfirm(null)}
        onConfirm={() => {
          actions.resetSettings()
          notify('Configurações restauradas.')
        }}
      />

      <Modal
        open={confirm === 'wipe'}
        onClose={() => setConfirm(null)}
        title="Apagar todos os dados"
        footer={
          <>
            <Button variant="secondary" onClick={() => setConfirm(null)}>
              Cancelar
            </Button>
            <Button
              variant="danger"
              disabled={wipeText.trim().toUpperCase() !== 'APAGAR'}
              onClick={() => {
                actions.wipeAll()
                setConfirm(null)
                notify('Todos os dados foram apagados.', 'info')
              }}
            >
              Apagar definitivamente
            </Button>
          </>
        }
      >
        <div className="space-y-3">
          <Notice tone="danger">Esta ação não pode ser desfeita. Exporte um backup antes, se quiser guardar algo.</Notice>
          <Field label="Digite APAGAR para confirmar">
            <Input value={wipeText} onChange={(e) => setWipeText(e.target.value)} autoComplete="off" />
          </Field>
        </div>
      </Modal>

      <ConfirmDialog
        open={!!pending}
        danger
        title="Substituir todos os dados?"
        text={pending ? `O arquivo "${pending.name}" será validado e substituirá todos os dados atuais deste navegador. Recomendamos exportar um backup do estado atual antes.` : ''}
        confirmLabel="Importar e substituir"
        onClose={() => setPending(null)}
        onConfirm={applyImport}
      />
    </>
  )
}
