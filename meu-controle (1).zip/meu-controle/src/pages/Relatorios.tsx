import { useEffect, useMemo, useRef, useState } from 'react'
import { Download, ExternalLink, FileText, Loader2, Printer, RefreshCw } from 'lucide-react'
import { useApp } from '../store/store'
import type { ActivityType, Range } from '../types'
import { addMonthKey, monthLabel, monthRange } from '../lib/dates'
import { formatDateBR } from '../lib/format'
import type { ReportKind, ReportOptions } from '../reports/build'
import { Button, Card, Field, Input, Notice, PageHeader, Select, Textarea, cx } from '../components/ui'

const KINDS: { kind: ReportKind; label: string; hint: string }[] = [
  { kind: 'completo', label: 'Relatório financeiro completo', hint: 'Tudo em um só documento: resumo, folha, produtividade, despesas, dívidas e caixa.' },
  { kind: 'salario', label: 'Salário e folha', hint: 'Detalhamento do cálculo e comparação entre estimado e recebido.' },
  { kind: 'produtividade', label: 'Produtividade', hint: 'Conferências e separações, médias e histórico.' },
  { kind: 'despesas', label: 'Despesas', hint: 'Totais por categoria e lista detalhada.' },
  { kind: 'dividas', label: 'Dívidas', hint: 'Saldos, parcelas pagas e pendentes e pagamentos.' },
  { kind: 'movimentacoes', label: 'Receitas e movimentações', hint: 'Livro-caixa, saldos por conta e previsto × realizado.' },
  { kind: 'planejamento', label: 'Planejamento mensal', hint: 'Compromissos, alertas, orçamentos e metas do mês.' },
  { kind: 'anual', label: 'Anual consolidado', hint: 'Visão mês a mês do ano inteiro.' },
]

type RangeMode = 'mes' | 'ano' | 'personalizado'

export function Relatorios() {
  const { data, today, notify } = useApp()
  const [kind, setKind] = useState<ReportKind>('completo')
  const [mode, setMode] = useState<RangeMode>('mes')
  const [month, setMonth] = useState(today.slice(0, 7))
  const [year, setYear] = useState(Number(today.slice(0, 4)))
  const [custom, setCustom] = useState<Range>({ from: `${today.slice(0, 7)}-01`, to: monthRange(today.slice(0, 7)).to })
  const [activity, setActivity] = useState<ActivityType | 'todas'>('todas')
  const [title, setTitle] = useState('')
  const [notes, setNotes] = useState('')
  const [charts, setCharts] = useState(true)

  const [url, setUrl] = useState<string | null>(null)
  const [pages, setPages] = useState(0)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const frame = useRef<HTMLIFrameElement>(null)
  const urlRef = useRef<string | null>(null)
  const seq = useRef(0)

  const range: Range = useMemo(() => {
    if (mode === 'mes') return monthRange(month)
    if (mode === 'ano') return { from: `${year}-01-01`, to: `${year}-12-31` }
    return custom.from <= custom.to ? custom : { from: custom.to, to: custom.from }
  }, [mode, month, year, custom])

  const usesRange = kind !== 'planejamento' && kind !== 'anual'
  const usesActivity = kind === 'completo' || kind === 'produtividade'
  const customInvalid = mode === 'personalizado' && (!custom.from || !custom.to)

  const opts: ReportOptions = useMemo(
    () => ({ kind, range, month, year, activityFilter: activity, title, notes, charts }),
    [kind, range, month, year, activity, title, notes, charts],
  )

  const optsKey = JSON.stringify(opts)
  const dataStamp = data.updatedAt

  // Pré-visualização automática (com atraso curto para não gerar a cada tecla)
  useEffect(() => {
    if (customInvalid) return
    const id = ++seq.current
    setBusy(true)
    setError(null)
    const t = setTimeout(async () => {
      try {
        const { buildReport } = await import('../reports/build')
        const doc = buildReport(data, opts, today)
        if (id !== seq.current) return
        const blob = doc.output('blob')
        const next = URL.createObjectURL(blob)
        if (urlRef.current) URL.revokeObjectURL(urlRef.current)
        urlRef.current = next
        setUrl(next)
        setPages(doc.getNumberOfPages())
      } catch (e) {
        console.error(e)
        if (id === seq.current) setError('Não foi possível montar o relatório. Confira os dados e tente novamente.')
      } finally {
        if (id === seq.current) setBusy(false)
      }
    }, 450)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [optsKey, dataStamp, today, customInvalid])

  useEffect(
    () => () => {
      if (urlRef.current) URL.revokeObjectURL(urlRef.current)
    },
    [],
  )

  const download = async () => {
    try {
      const { buildReport, reportFileName } = await import('../reports/build')
      buildReport(data, opts, today).save(reportFileName(opts))
      notify('PDF gerado. Verifique a pasta de downloads.')
    } catch (e) {
      console.error(e)
      notify('Não foi possível gerar o PDF.', 'error')
    }
  }

  const print = () => {
    const w = frame.current?.contentWindow
    try {
      if (!w) throw new Error('sem janela')
      w.focus()
      w.print()
    } catch {
      if (url) window.open(url, '_blank', 'noopener')
      notify('Abri o PDF em outra aba: use o botão de imprimir do visualizador.', 'info')
    }
  }

  const periodLabel = kind === 'planejamento' ? monthLabel(month) : kind === 'anual' ? String(year) : `${formatDateBR(range.from)} a ${formatDateBR(range.to)}`
  const hasData = data.productivity.length + data.expenses.length + data.debts.length + data.transactions.length + data.payrolls.length > 0

  return (
    <>
      <PageHeader
        title="Relatórios"
        subtitle="Documentos em PDF no formato A4, com layout próprio para impressão. Confira a pré-visualização antes de baixar ou imprimir."
      />

      {!hasData && (
        <Notice tone="info" className="mb-4">
          Você ainda não tem registros. Os relatórios já funcionam com o salário configurado, mas ficarão mais completos conforme você cadastrar produtividade, despesas e dívidas.
        </Notice>
      )}

      <div className="grid gap-5 lg:grid-cols-[22rem_1fr]">
        <div className="space-y-4">
          <Card title="Tipo de relatório">
            <ul className="space-y-1.5" role="radiogroup" aria-label="Tipo de relatório">
              {KINDS.map((k) => (
                <li key={k.kind}>
                  <button
                    type="button"
                    role="radio"
                    aria-checked={kind === k.kind}
                    onClick={() => setKind(k.kind)}
                    className={cx('w-full rounded-xl border px-3 py-2 text-left transition', kind === k.kind ? 'border-accent bg-accent/5' : 'border-gray-200 hover:bg-gray-50')}
                  >
                    <span className="block text-sm font-medium text-gray-900">{k.label}</span>
                    <span className="block text-xs text-gray-500">{k.hint}</span>
                  </button>
                </li>
              ))}
            </ul>
          </Card>

          <Card title="Período e conteúdo">
            <div className="space-y-3">
              {kind === 'planejamento' && (
                <Field label="Mês">
                  <div className="flex gap-1">
                    <Button variant="secondary" size="sm" aria-label="Mês anterior" onClick={() => setMonth(addMonthKey(month, -1))}>
                      ‹
                    </Button>
                    <Input type="month" value={month} onChange={(e) => e.target.value && setMonth(e.target.value)} />
                    <Button variant="secondary" size="sm" aria-label="Próximo mês" onClick={() => setMonth(addMonthKey(month, 1))}>
                      ›
                    </Button>
                  </div>
                </Field>
              )}
              {kind === 'anual' && (
                <Field label="Ano">
                  <Input type="number" min={2000} max={2100} value={year} onChange={(e) => { const y = Number(e.target.value); if (y >= 2000 && y <= 2100) setYear(y) }} />
                </Field>
              )}
              {usesRange && (
                <>
                  <Field label="Período">
                    <Select value={mode} onChange={(e) => setMode(e.target.value as RangeMode)}>
                      <option value="mes">Mês</option>
                      <option value="ano">Ano</option>
                      <option value="personalizado">Período personalizado</option>
                    </Select>
                  </Field>
                  {mode === 'mes' && (
                    <Field label="Mês">
                      <Input type="month" value={month} onChange={(e) => e.target.value && setMonth(e.target.value)} />
                    </Field>
                  )}
                  {mode === 'ano' && (
                    <Field label="Ano">
                      <Input type="number" min={2000} max={2100} value={year} onChange={(e) => { const y = Number(e.target.value); if (y >= 2000 && y <= 2100) setYear(y) }} />
                    </Field>
                  )}
                  {mode === 'personalizado' && (
                    <div className="grid grid-cols-2 gap-2">
                      <Field label="De">
                        <Input type="date" value={custom.from} onChange={(e) => setCustom({ ...custom, from: e.target.value })} />
                      </Field>
                      <Field label="Até">
                        <Input type="date" value={custom.to} onChange={(e) => setCustom({ ...custom, to: e.target.value })} />
                      </Field>
                    </div>
                  )}
                </>
              )}
              {usesActivity && (
                <Field label="Atividade (produtividade)">
                  <Select value={activity} onChange={(e) => setActivity(e.target.value as ActivityType | 'todas')}>
                    <option value="todas">Conferência e separação</option>
                    <option value="conferencia">Somente conferência</option>
                    <option value="separacao">Somente separação</option>
                  </Select>
                </Field>
              )}
              <Field label="Título do relatório (opcional)">
                <Input value={title} maxLength={70} onChange={(e) => setTitle(e.target.value)} placeholder="Padrão do tipo escolhido" />
              </Field>
              <label className="flex items-center gap-2 text-sm text-gray-700">
                <input type="checkbox" checked={charts} onChange={(e) => setCharts(e.target.checked)} /> Incluir gráficos
              </label>
              <Field label="Observações (aparecem no final)" hint="Deixe vazio para imprimir linhas em branco para anotações à mão.">
                <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} maxLength={800} />
              </Field>
              <p className="text-xs text-gray-500">O nome exibido nos relatórios é definido em Configurações → Aparência.</p>
            </div>
          </Card>
        </div>

        <div className="min-w-0">
          <div className="no-print mb-3 flex flex-wrap items-center gap-2">
            <Button onClick={download} disabled={busy || !url}>
              <Download size={16} /> Baixar PDF
            </Button>
            <Button variant="secondary" onClick={print} disabled={busy || !url}>
              <Printer size={16} /> Imprimir
            </Button>
            {url && (
              <a className="btn-secondary" href={url} target="_blank" rel="noopener noreferrer">
                <ExternalLink size={16} /> Abrir em nova aba
              </a>
            )}
            <span className="ml-auto flex items-center gap-1.5 text-xs text-gray-500" aria-live="polite">
              {busy ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />}
              {busy ? 'Atualizando…' : `${pages} página(s) · ${periodLabel}`}
            </span>
          </div>

          {error && <Notice tone="danger" className="mb-3">{error}</Notice>}

          <div className="card overflow-hidden bg-gray-100">
            {customInvalid ? (
              <div className="flex h-[40rem] items-center justify-center text-sm text-gray-500">Informe as duas datas do período.</div>
            ) : url ? (
              <iframe ref={frame} key={url} title="Pré-visualização do relatório em PDF" src={url} className="h-[75vh] min-h-[32rem] w-full bg-white" />
            ) : (
              <div className="flex h-[40rem] flex-col items-center justify-center gap-2 text-sm text-gray-500">
                <FileText size={28} aria-hidden /> Montando a pré-visualização…
              </div>
            )}
          </div>
          <p className="mt-2 text-xs text-gray-500">
            Se a pré-visualização não aparecer (alguns celulares não exibem PDF dentro da página), use “Abrir em nova aba” ou “Baixar PDF”.
          </p>
        </div>
      </div>
    </>
  )
}
