import { useMemo, useState } from 'react'
import { ArrowLeftRight, Download, Link2, Pencil, Plus, Search, Trash2 } from 'lucide-react'
import { periodToRange, useApp, type Period } from '../store/store'
import type { Transaction, TxKind, TxStatus } from '../types'
import { accountBalances, ledgerTotals, plannedBalance, realizedBalance, sum } from '../lib/calc'
import { brl, formatDate, parseNumber } from '../lib/format'
import { downloadFile, toCSV } from '../lib/csv'
import { Badge, Button, Card, ConfirmDialog, EmptyState, Field, Input, Modal, Notice, PageHeader, Segmented, Select, Stat, Table, Textarea } from '../components/ui'
import { PeriodFilter } from '../components/PeriodFilter'
import { inRange } from '../lib/dates'

type TypeFilter = 'todas' | 'entrada' | 'saida'
type StatusFilter = 'todos' | TxStatus

const SOURCE_LABEL = { salary: 'Folha', expense: 'Despesa', debt: 'Dívida' } as const

export function LivroCaixa() {
  const { data, actions, period: globalPeriod, notify } = useApp()
  const [period, setPeriod] = useState<Period>(globalPeriod)
  const range = periodToRange(period)
  const [type, setType] = useState<TypeFilter>('todas')
  const [status, setStatus] = useState<StatusFilter>('todos')
  const [account, setAccount] = useState('todas')
  const [category, setCategory] = useState('todas')
  const [query, setQuery] = useState('')
  const [editing, setEditing] = useState<Transaction | 'new' | null>(null)
  const [transfer, setTransfer] = useState(false)
  const [deleting, setDeleting] = useState<Transaction | null>(null)

  const inPeriod = useMemo(() => data.transactions.filter((t) => inRange(t.date, range)), [data.transactions, range.from, range.to])
  const filtered = useMemo(
    () =>
      inPeriod
        .filter(
          (t) =>
            (type === 'todas' || t.type === type) &&
            (status === 'todos' || t.status === status) &&
            (account === 'todas' || t.account === account) &&
            (category === 'todas' || t.category === category) &&
            (!query.trim() || `${t.description} ${t.origin} ${t.notes}`.toLowerCase().includes(query.trim().toLowerCase())),
        )
        .sort((a, b) => b.date.localeCompare(a.date)),
    [inPeriod, type, status, account, category, query],
  )

  const totals = useMemo(() => ledgerTotals(inPeriod), [inPeriod])
  const realized = useMemo(() => realizedBalance(data.transactions), [data.transactions])
  const planned = useMemo(() => plannedBalance(data.transactions), [data.transactions])
  const accounts = useMemo(() => accountBalances(data.transactions, data.settings.accounts), [data.transactions, data.settings.accounts])
  const cats = useMemo(() => [...new Set([...data.settings.incomeCategories, ...data.settings.expenseCategories, ...data.transactions.map((t) => t.category)])], [data])

  const exportCSV = () => {
    const rows: (string | number)[][] = [['Data', 'Tipo', 'Descrição', 'Categoria', 'Valor', 'Conta', 'Origem/Destino', 'Situação', 'Natureza', 'Vínculo', 'Observação']]
    for (const t of [...filtered].sort((a, b) => a.date.localeCompare(b.date)))
      rows.push([formatDate(t.date), t.type === 'entrada' ? 'Entrada' : 'Saída', t.description, t.category, t.type === 'entrada' ? t.amount : -t.amount, t.account, t.origin, t.status === 'efetivado' ? 'Efetivado' : 'Previsto', t.kind === 'normal' ? 'Normal' : t.kind === 'transferencia' ? 'Transferência' : 'Incorporada ao salário', t.sourceType ? `${SOURCE_LABEL[t.sourceType]}:${t.sourceId}` : '', t.notes])
    downloadFile(`movimentacoes_${range.from}_${range.to}.csv`, toCSV(rows), 'text/csv;charset=utf-8')
    notify('CSV das movimentações exportado.')
  }

  return (
    <>
      <PageHeader
        title="Livro-caixa"
        subtitle="Entradas e saídas. O saldo realizado considera só o que de fato aconteceu; o previsto inclui lançamentos futuros sem misturá-los ao saldo atual."
        actions={
          <>
            <Button variant="secondary" onClick={exportCSV} disabled={!filtered.length}>
              <Download size={16} /> CSV
            </Button>
            <Button variant="secondary" onClick={() => setTransfer(true)}>
              <ArrowLeftRight size={16} /> Transferir
            </Button>
            <Button onClick={() => setEditing('new')}>
              <Plus size={16} /> Novo lançamento
            </Button>
          </>
        }
      />

      <div className="mb-5">
        <PeriodFilter value={period} onChange={setPeriod} />
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Saldo realizado (total)" tone={realized >= 0 ? 'income' : 'expense'} value={brl(realized)} hint="Somente movimentações efetivadas" />
        <Stat label="Saldo previsto (total)" tone={planned >= 0 ? 'neutral' : 'expense'} value={brl(planned)} hint="Inclui lançamentos futuros" />
        <Stat label="Entradas efetivadas" tone="income" value={brl(totals.inReal)} hint={`Previstas ${brl(totals.inPlan)}`} />
        <Stat label="Saídas efetivadas" tone="expense" value={brl(totals.outReal)} hint={`Previstas ${brl(totals.outPlan)}`} />
      </div>

      <Card title="Saldo por conta" className="mt-5">
        <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {accounts.map((a) => (
            <li key={a.account} className="rounded-xl bg-gray-50 px-4 py-3">
              <p className="text-xs text-gray-500">{a.account}</p>
              <p className={`num text-lg font-semibold ${a.balance >= 0 ? 'text-gray-900' : 'text-expense'}`}>{brl(a.balance)}</p>
            </li>
          ))}
        </ul>
        <p className="mt-3 text-xs text-gray-500">Transferências entre contas movem o saldo de uma para outra e não contam como receita nem despesa.</p>
      </Card>

      <div className="mt-6 flex flex-wrap items-center gap-2">
        <div className="relative">
          <Search size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" aria-hidden />
          <Input aria-label="Buscar lançamento" placeholder="Buscar…" value={query} onChange={(e) => setQuery(e.target.value)} className="w-44 py-1.5 pl-8" />
        </div>
        <Segmented
          label="Tipo"
          value={type}
          onChange={setType}
          options={[
            { value: 'todas', label: 'Todos' },
            { value: 'entrada', label: 'Entradas' },
            { value: 'saida', label: 'Saídas' },
          ]}
        />
        <Select aria-label="Situação" value={status} onChange={(e) => setStatus(e.target.value as StatusFilter)} className="w-36 py-1.5">
          <option value="todos">Todas as situações</option>
          <option value="efetivado">Efetivados</option>
          <option value="previsto">Previstos</option>
        </Select>
        <Select aria-label="Conta" value={account} onChange={(e) => setAccount(e.target.value)} className="w-40 py-1.5">
          <option value="todas">Todas as contas</option>
          {accounts.map((a) => (
            <option key={a.account}>{a.account}</option>
          ))}
        </Select>
        <Select aria-label="Categoria" value={category} onChange={(e) => setCategory(e.target.value)} className="w-48 py-1.5">
          <option value="todas">Todas as categorias</option>
          {cats.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </Select>
      </div>

      <div className="mt-3">
        {inPeriod.length === 0 ? (
          <EmptyState
            title="Nenhuma movimentação neste período"
            text="Salários recebidos, despesas pagas e pagamentos de dívidas aparecem aqui automaticamente. Você também pode lançar entradas e saídas manuais."
            action={<Button onClick={() => setEditing('new')}>Novo lançamento</Button>}
          />
        ) : filtered.length === 0 ? (
          <EmptyState title="Nada encontrado com esses filtros" />
        ) : (
          <Card pad={false}>
            <Table head={['Data', 'Descrição', 'Categoria', 'Conta', { label: 'Valor', className: 'text-right' }, 'Situação', { label: 'Ações', className: 'text-right' }]}>
              {filtered.map((t) => (
                <tr key={t.id} className="hover:bg-gray-50/60">
                  <td className="td num whitespace-nowrap">{formatDate(t.date)}</td>
                  <td className="td">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="font-medium text-gray-900">{t.description}</span>
                      {t.sourceType && (
                        <Badge tone="info">
                          <Link2 size={10} aria-hidden /> {SOURCE_LABEL[t.sourceType]}
                        </Badge>
                      )}
                      {t.kind === 'transferencia' && <Badge>Transferência</Badge>}
                      {t.kind === 'incorporada' && <Badge tone="warn">Já no salário</Badge>}
                    </div>
                    {(t.origin || t.notes) && <p className="max-w-xs truncate text-xs text-gray-500">{[t.origin, t.notes].filter(Boolean).join(' · ')}</p>}
                  </td>
                  <td className="td text-gray-600">{t.category}</td>
                  <td className="td text-gray-600">{t.account}</td>
                  <td className={`td num whitespace-nowrap text-right font-medium ${t.type === 'entrada' ? 'text-income' : 'text-expense'}`}>
                    {t.type === 'entrada' ? '+' : '−'} {brl(t.amount)}
                  </td>
                  <td className="td">
                    <Badge tone={t.status === 'efetivado' ? 'income' : 'neutral'}>{t.status === 'efetivado' ? 'Efetivado' : 'Previsto'}</Badge>
                  </td>
                  <td className="td whitespace-nowrap text-right">
                    <Button variant="ghost" size="sm" aria-label={`Editar ${t.description}`} onClick={() => setEditing(t)}>
                      <Pencil size={14} />
                    </Button>
                    <Button variant="ghost" size="sm" aria-label={`Excluir ${t.description}`} onClick={() => setDeleting(t)}>
                      <Trash2 size={14} />
                    </Button>
                  </td>
                </tr>
              ))}
              <tr className="bg-gray-50 font-semibold">
                <td className="td" colSpan={4}>
                  Resultado da lista (sem transferências)
                </td>
                <td className="td num text-right">
                  {brl(sum(filtered.filter((t) => t.kind === 'normal').map((t) => (t.type === 'entrada' ? t.amount : -t.amount))))}
                </td>
                <td className="td" colSpan={2} />
              </tr>
            </Table>
          </Card>
        )}
      </div>

      <TxForm tx={editing} onClose={() => setEditing(null)} />
      <TransferForm open={transfer} onClose={() => setTransfer(false)} />
      <ConfirmDialog
        open={!!deleting}
        danger
        title="Excluir lançamento"
        confirmLabel="Excluir"
        text={deleting ? `Excluir "${deleting.description}" (${brl(deleting.amount)})?${deleting.transferGroup ? ' A outra perna da transferência também será removida.' : ''}` : ''}
        onClose={() => setDeleting(null)}
        onConfirm={() => {
          if (!deleting) return
          const err = actions.deleteTransaction(deleting.id)
          if (err) notify(err, 'error')
          else notify('Lançamento excluído.')
        }}
      />
    </>
  )
}

function TxForm({ tx, onClose }: { tx: Transaction | 'new' | null; onClose: () => void }) {
  const { data, actions, today, notify } = useApp()
  const existing = tx && tx !== 'new' ? tx : null
  const linked = !!existing?.sourceType
  const locked = linked || existing?.kind === 'transferencia'
  const [type, setType] = useState<'entrada' | 'saida'>('entrada')
  const [desc, setDesc] = useState('')
  const [category, setCategory] = useState('')
  const [amount, setAmount] = useState('')
  const [date, setDate] = useState('')
  const [account, setAccount] = useState('')
  const [origin, setOrigin] = useState('')
  const [notes, setNotes] = useState('')
  const [status, setStatus] = useState<TxStatus>('efetivado')
  const [kind, setKind] = useState<TxKind>('normal')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [key, setKey] = useState<unknown>(null)

  if (tx !== key) {
    setKey(tx)
    if (tx) {
      setType(existing?.type ?? 'entrada')
      setDesc(existing?.description ?? '')
      setCategory(existing?.category ?? 'Renda extra')
      setAmount(existing ? String(existing.amount).replace('.', ',') : '')
      setDate(existing?.date ?? today)
      setAccount(existing?.account ?? data.settings.accounts[0] ?? 'Conta principal')
      setOrigin(existing?.origin ?? '')
      setNotes(existing?.notes ?? '')
      setStatus(existing?.status ?? 'efetivado')
      setKind(existing?.kind ?? 'normal')
      setErrors({})
    }
  }

  const catList = [...new Set([...(type === 'entrada' ? data.settings.incomeCategories : [...data.settings.expenseCategories, ...data.settings.incomeCategories]), category].filter(Boolean))]
  const accounts = [...new Set([...data.settings.accounts, account].filter(Boolean))]

  const save = () => {
    const e: Record<string, string> = {}
    const a = parseNumber(amount)
    if (!desc.trim()) e.desc = 'Informe a descrição.'
    if (!Number.isFinite(a) || a <= 0) e.amount = 'Informe um valor maior que zero.'
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) e.date = 'Informe a data.'
    setErrors(e)
    if (Object.keys(e).length) return
    const payload = { type, description: desc.trim(), category, amount: a, date, account, origin: origin.trim(), notes: notes.trim(), status, kind }
    if (existing) {
      actions.updateTransaction(existing.id, locked ? { account, notes: notes.trim(), origin: origin.trim() } : payload)
      notify('Lançamento atualizado.')
    } else {
      actions.addTransaction(payload)
      notify('Lançamento adicionado.')
    }
    onClose()
  }

  return (
    <Modal
      open={tx !== null}
      onClose={onClose}
      wide
      title={existing ? 'Editar lançamento' : 'Novo lançamento'}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={save}>Salvar</Button>
        </>
      }
    >
      <form
        className="grid gap-4 sm:grid-cols-2"
        noValidate
        onSubmit={(e) => {
          e.preventDefault()
          save()
        }}
      >
        {locked && (
          <div className="sm:col-span-2">
            <Notice tone="info">
              {linked
                ? 'Este lançamento é gerado por outro módulo (salário, despesa ou dívida). Para alterar valor, data ou situação, edite na origem. Aqui você pode ajustar conta, origem e observação.'
                : 'Transferências só podem ter conta e observação ajustadas. Exclua e refaça para mudar valores.'}
            </Notice>
          </div>
        )}
        <Field label="Tipo">
          <Select value={type} onChange={(e) => setType(e.target.value as 'entrada' | 'saida')} disabled={locked}>
            <option value="entrada">Entrada</option>
            <option value="saida">Saída</option>
          </Select>
        </Field>
        <Field label="Situação">
          <Select value={status} onChange={(e) => setStatus(e.target.value as TxStatus)} disabled={locked}>
            <option value="efetivado">Efetivado (já aconteceu)</option>
            <option value="previsto">Previsto (futuro)</option>
          </Select>
        </Field>
        <Field label="Descrição" error={errors.desc} className="sm:col-span-2">
          <Input value={desc} onChange={(e) => setDesc(e.target.value)} invalid={!!errors.desc} disabled={locked} maxLength={100} />
        </Field>
        <Field label="Categoria">
          <Select value={category} onChange={(e) => setCategory(e.target.value)} disabled={locked}>
            {catList.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </Select>
        </Field>
        <Field label="Valor (R$)" error={errors.amount}>
          <Input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} invalid={!!errors.amount} disabled={locked} placeholder="0,00" />
        </Field>
        <Field label="Data" error={errors.date}>
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} invalid={!!errors.date} disabled={locked} />
        </Field>
        <Field label="Conta ou carteira">
          <Select value={account} onChange={(e) => setAccount(e.target.value)} disabled={existing?.kind === 'transferencia'}>
            {accounts.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </Select>
        </Field>
        <Field label={type === 'entrada' ? 'Origem' : 'Destino'} className="sm:col-span-2">
          <Input value={origin} onChange={(e) => setOrigin(e.target.value)} maxLength={80} />
        </Field>
        {!locked && (
          <label className="flex items-start gap-2 text-sm text-gray-700 sm:col-span-2">
            <input type="checkbox" className="mt-1" checked={kind === 'incorporada'} onChange={(e) => setKind(e.target.checked ? 'incorporada' : 'normal')} />
            <span>
              Este valor <strong>já está incluído no cálculo do salário</strong> (ex.: produtividade ou assiduidade). Ele fica registrado, mas não é somado de novo nos saldos nem nas receitas extras.
            </span>
          </label>
        )}
        <Field label="Observação" className="sm:col-span-2">
          <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} maxLength={300} />
        </Field>
        <button type="submit" className="hidden" aria-hidden tabIndex={-1} />
      </form>
    </Modal>
  )
}

function TransferForm({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { data, actions, today, notify } = useApp()
  const accounts = data.settings.accounts
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [amount, setAmount] = useState('')
  const [date, setDate] = useState(today)
  const [notes, setNotes] = useState('')
  const [err, setErr] = useState('')
  const [wasOpen, setWasOpen] = useState(false)

  if (open !== wasOpen) {
    setWasOpen(open)
    if (open) {
      setFrom(accounts[0] ?? '')
      setTo(accounts[1] ?? '')
      setAmount('')
      setDate(today)
      setNotes('')
      setErr('')
    }
  }

  const save = () => {
    const a = parseNumber(amount)
    if (!Number.isFinite(a) || a <= 0) return setErr('Informe um valor maior que zero.')
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return setErr('Informe a data.')
    const e = actions.addTransfer({ from, to, amount: a, date, notes: notes.trim() })
    if (e) return setErr(e)
    notify(`Transferência de ${brl(a)} registrada.`)
    onClose()
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Transferir entre contas"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={save}>Transferir</Button>
        </>
      }
    >
      {accounts.length < 2 ? (
        <Notice tone="warn">Cadastre pelo menos duas contas em Configurações para fazer transferências.</Notice>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="De">
            <Select value={from} onChange={(e) => setFrom(e.target.value)}>
              {accounts.map((a) => (
                <option key={a}>{a}</option>
              ))}
            </Select>
          </Field>
          <Field label="Para">
            <Select value={to} onChange={(e) => setTo(e.target.value)}>
              {accounts.map((a) => (
                <option key={a}>{a}</option>
              ))}
            </Select>
          </Field>
          <Field label="Valor (R$)">
            <Input inputMode="decimal" value={amount} onChange={(e) => { setAmount(e.target.value); setErr('') }} placeholder="0,00" />
          </Field>
          <Field label="Data">
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          <Field label="Observação" className="sm:col-span-2">
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={200} />
          </Field>
          {err && (
            <div className="sm:col-span-2">
              <Notice tone="danger">{err}</Notice>
            </div>
          )}
        </div>
      )}
    </Modal>
  )
}
