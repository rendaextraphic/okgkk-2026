import { useEffect, useMemo, useState } from 'react'
import { ChevronLeft, ChevronRight, Pencil, Plus, Settings as Cog, Trash2, Wand2 } from 'lucide-react'
import { useApp } from '../store/store'
import type { PayrollRecord, PayrollStatus } from '../types'
import { computePayroll, effectivePayroll } from '../lib/calc'
import { addMonthKey, addMonths, monthLabel, pad } from '../lib/dates'
import { brl, formatDate, num, parseNumber, round2, signed } from '../lib/format'
import { Badge, Button, Card, ConfirmDialog, EmptyState, Field, Input, Modal, Notice, PageHeader, Select, Stat, Table, Textarea } from '../components/ui'
import type { Route } from '../components/Layout'

const STATUS_LABEL: Record<PayrollStatus, string> = { previsto: 'Previsto', recebido: 'Recebido', ajustado: 'Ajustado' }
const statusTone = { previsto: 'neutral', recebido: 'income', ajustado: 'warn' } as const

function Row({ label, hint, value, tone, strong }: { label: string; hint?: string; value: number; tone?: 'income' | 'expense'; strong?: boolean }) {
  return (
    <div className={`flex items-start justify-between gap-4 py-2 ${strong ? 'border-t border-gray-200 pt-3 font-semibold' : ''}`}>
      <div className="min-w-0">
        <p className={`text-sm ${strong ? 'text-gray-900' : 'text-gray-700'}`}>{label}</p>
        {hint && <p className="text-xs text-gray-500">{hint}</p>}
      </div>
      <p className={`num shrink-0 text-sm ${tone === 'income' ? 'text-income' : tone === 'expense' ? 'text-expense' : 'text-gray-900'} ${strong ? 'text-base' : ''}`}>
        {tone === 'expense' && value > 0 ? '− ' : ''}
        {brl(value)}
      </p>
    </div>
  )
}

export function Salario({ go }: { go: (r: Route) => void }) {
  const { data, actions, today, notify } = useApp()
  const s = data.settings
  const [month, setMonth] = useState(today.slice(0, 7))
  const [editing, setEditing] = useState<PayrollRecord | 'new' | null>(null)
  const [toDelete, setToDelete] = useState<PayrollRecord | null>(null)

  const calc = useMemo(() => computePayroll(data, month), [data, month])
  const eff = useMemo(() => effectivePayroll(data, month), [data, month])
  const record = data.payrolls.find((p) => p.month === month)
  const mp = data.monthParams[month]

  // parâmetros do mês
  const [pNight, setPNight] = useState('')
  const [pDays, setPDays] = useState('')
  const [pOver, setPOver] = useState('')
  const [pAdv, setPAdv] = useState('')
  const [pErr, setPErr] = useState('')
  useEffect(() => {
    setPNight(mp?.nightHours !== undefined ? String(mp.nightHours).replace('.', ',') : '')
    setPDays(mp?.workedDays !== undefined ? String(mp.workedDays) : '')
    setPOver(mp?.overtimeHours !== undefined ? String(mp.overtimeHours).replace('.', ',') : '')
    setPAdv(mp?.advances !== undefined ? String(mp.advances).replace('.', ',') : '')
    setPErr('')
  }, [month, mp?.nightHours, mp?.workedDays, mp?.overtimeHours, mp?.advances])

  const saveParams = () => {
    const out: Record<string, number> = {}
    const read = (txt: string, key: string, label: string, max: number) => {
      if (txt.trim() === '') return true
      const n = parseNumber(txt)
      if (!Number.isFinite(n) || n < 0 || n > max) {
        setPErr(`${label}: informe um número entre 0 e ${num(max)}.`)
        return false
      }
      out[key] = n
      return true
    }
    if (!read(pNight, 'nightHours', 'Horas noturnas', 744) || !read(pDays, 'workedDays', 'Dias trabalhados', 31) || !read(pOver, 'overtimeHours', 'Horas extras', 744) || !read(pAdv, 'advances', 'Adiantamentos', 1_000_000)) return
    setPErr('')
    actions.setMonthParams(month, out)
    notify(Object.keys(out).length ? `Parâmetros de ${monthLabel(month)} salvos.` : 'Parâmetros do mês voltaram ao padrão.')
  }

  const records = useMemo(
    () =>
      [...data.payrolls]
        .sort((a, b) => b.month.localeCompare(a.month))
        .map((r) => ({ r, est: computePayroll(data, r.month) })),
    [data],
  )

  const diff = record && record.status !== 'previsto' ? round2(record.net - calc.net) : null

  return (
    <>
      <PageHeader
        title="Salário"
        subtitle="Detalhamento transparente da remuneração. Valores calculados são estimativas até você registrar a folha confirmada."
        actions={
          <>
            <Button variant="secondary" onClick={() => go('configuracoes')}>
              <Cog size={16} /> Regras de cálculo
            </Button>
            <Button onClick={() => setEditing('new')}>
              <Plus size={16} /> Registrar pagamento
            </Button>
          </>
        }
      />

      <div className="mb-5 flex flex-wrap items-center gap-2">
        <Button variant="secondary" size="sm" aria-label="Mês anterior" onClick={() => setMonth(addMonthKey(month, -1))}>
          <ChevronLeft size={15} />
        </Button>
        <Input type="month" aria-label="Competência" value={month} onChange={(e) => e.target.value && setMonth(e.target.value)} className="w-44 py-1.5" />
        <Button variant="secondary" size="sm" aria-label="Próximo mês" onClick={() => setMonth(addMonthKey(month, 1))}>
          <ChevronRight size={15} />
        </Button>
        <span className="text-sm font-medium capitalize text-gray-700">{monthLabel(month)}</span>
        {eff.confirmed ? <Badge tone={statusTone[record!.status]}>Folha {record!.status === 'ajustado' ? 'ajustada' : 'recebida'}</Badge> : <Badge>Estimativa</Badge>}
        <span className="text-xs text-gray-500">
          Período da folha: {formatDate(calc.period.from)} a {formatDate(calc.period.to)}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Total bruto estimado" value={brl(calc.gross)} />
        <Stat label="Total de descontos" tone="expense" value={brl(calc.totalDeductions)} />
        <Stat label="Líquido estimado" tone="income" value={brl(calc.net)} />
        <Stat
          label={eff.confirmed ? 'Líquido recebido' : 'Folha confirmada'}
          value={eff.confirmed ? brl(eff.net) : '—'}
          hint={
            diff === null ? (
              'Registre o pagamento para comparar'
            ) : (
              <span className={diff >= 0 ? 'text-income' : 'text-expense'}>
                {signed(diff)} em relação ao estimado
              </span>
            )
          }
        />
      </div>

      {calc.warnings.length > 0 && (
        <div className="mt-4 space-y-2">
          {calc.warnings.map((w) => (
            <Notice key={w} tone="warn">
              {w}
            </Notice>
          ))}
        </div>
      )}

      <div className="mt-5 grid gap-4 lg:grid-cols-5">
        <Card title="Detalhamento da folha" subtitle={`Competência de ${monthLabel(month)}`} className="lg:col-span-3">
          <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-gray-500">Proventos</p>
          <div className="divide-y divide-gray-50">
            <Row label="Salário-base" value={calc.baseSalary} />
            <Row
              label="Adicional noturno"
              value={calc.nightAdditional}
              hint={`${num(calc.nightHours, 1)} h noturnas × ${brl(calc.hourly)}/h × ${num(s.nightPct, 1)}%${s.nightReducedHour ? ' (hora reduzida)' : ''}`}
              tone="income"
            />
            <Row label="Assiduidade" value={calc.attendance} hint={s.attendanceEnabled ? undefined : 'Desativada nas configurações'} tone="income" />
            <Row
              label="Produtividade (elegível)"
              value={calc.productionEligible}
              hint={calc.productionTotal ? `Produzido ${brl(calc.productionTotal)}${calc.productionPending ? ` · pendente ${brl(calc.productionPending)}` : ''}` : 'Nenhum registro no período'}
              tone="income"
            />
            {s.overtimeEnabled && <Row label="Horas extras" value={calc.overtime} hint={`${num(calc.overtimeHours, 1)} h × ${brl(calc.hourly)} × ${num(1 + s.overtimePct / 100, 2)}`} tone="income" />}
            {s.otherAdditions.map((i) => (
              <Row key={i.id} label={i.name || 'Outro adicional'} value={i.amount} tone="income" />
            ))}
          </div>
          <Row label="Total bruto estimado" value={calc.gross} strong />

          <p className="mb-1 mt-5 text-xs font-semibold uppercase tracking-wide text-gray-500">Descontos</p>
          <div className="divide-y divide-gray-50">
            <Row label="Vale-transporte" value={calc.vt} hint={s.vtMode === 'percentual' ? `${num(s.vtPercent, 1)}% do salário-base` : s.vtMode === 'valor' ? 'Valor fixo' : 'Não configurado'} tone="expense" />
            <Row
              label="INSS e outros descontos legais"
              value={calc.inss}
              hint={calc.inssConfigured ? `Conforme configuração${s.inss.competence ? ` (${s.inss.competence})` : ''}` : 'Não configurado: valor a confirmar no holerite'}
              tone="expense"
            />
            <Row label="Adiantamentos" value={calc.advances} tone="expense" />
            {s.otherDeductions.map((i) => (
              <Row key={i.id} label={i.name || 'Outro desconto'} value={i.amount} tone="expense" />
            ))}
          </div>
          <Row label="Total de descontos" value={calc.totalDeductions} tone="expense" strong />
          <Row label="Salário líquido estimado" value={calc.net} tone="income" strong />
          <p className="mt-3 text-xs text-gray-500">
            Fórmula: bruto = salário-base + adicional noturno + assiduidade + produtividade elegível + extras e outros adicionais. Líquido = bruto − descontos.
          </p>
        </Card>

        <Card title="Parâmetros deste mês" subtitle="Sobrescrevem as configurações apenas nesta competência" className="lg:col-span-2">
          <div className="space-y-3">
            <Field label="Horas noturnas trabalhadas" hint={`Padrão: ${num(round2(s.nightHoursPerDay * s.workedDays), 1)} h (${num(s.nightHoursPerDay, 1)} h/dia × ${s.workedDays} dias)`}>
              <Input inputMode="decimal" value={pNight} onChange={(e) => setPNight(e.target.value)} placeholder="Usar padrão" />
            </Field>
            <Field label="Dias trabalhados" hint={`Padrão: ${s.workedDays} dias. Só afeta o cálculo quando as horas noturnas não são informadas acima.`}>
              <Input inputMode="numeric" value={pDays} onChange={(e) => setPDays(e.target.value)} placeholder="Usar padrão" />
            </Field>
            {s.overtimeEnabled && (
              <Field label="Horas extras" hint={`Padrão: ${num(s.overtimeHours, 1)} h`}>
                <Input inputMode="decimal" value={pOver} onChange={(e) => setPOver(e.target.value)} placeholder="Usar padrão" />
              </Field>
            )}
            <Field label="Adiantamentos (R$)" hint={`Padrão: ${brl(s.advances)}`}>
              <Input inputMode="decimal" value={pAdv} onChange={(e) => setPAdv(e.target.value)} placeholder="Usar padrão" />
            </Field>
            {pErr && (
              <p role="alert" className="text-xs font-medium text-expense">
                {pErr}
              </p>
            )}
            <div className="flex gap-2">
              <Button onClick={saveParams}>Salvar parâmetros</Button>
              {mp && (
                <Button
                  variant="secondary"
                  onClick={() => {
                    actions.setMonthParams(month, null)
                    notify('Parâmetros do mês restaurados.')
                  }}
                >
                  Restaurar padrão
                </Button>
              )}
            </div>
            <p className="text-xs text-gray-500">
              Valor da hora normal: <span className="num font-medium">{brl(calc.hourly)}</span> ({s.hourlyRateOverride > 0 ? 'informado manualmente' : `${brl(s.baseSalary)} ÷ ${num(s.monthlyHours)} h`}).
            </p>
          </div>
        </Card>
      </div>

      <Card title="Controle de pagamentos" subtitle="Compare o que foi estimado com o que realmente caiu na conta" className="mt-5" pad={false}>
        {records.length === 0 ? (
          <div className="p-5">
            <EmptyState
              title="Nenhum pagamento registrado"
              text="Quando receber o salário, registre o valor bruto, os descontos e a data. O sistema compara com a estimativa e lança a entrada no livro-caixa."
              action={<Button onClick={() => setEditing('new')}>Registrar pagamento</Button>}
            />
          </div>
        ) : (
          <Table
            head={[
              'Competência',
              'Previsto para',
              'Pago em',
              { label: 'Bruto', className: 'text-right' },
              { label: 'Descontos', className: 'text-right' },
              { label: 'Líquido', className: 'text-right' },
              { label: 'Estimado', className: 'text-right' },
              { label: 'Diferença', className: 'text-right' },
              'Status',
              { label: 'Ações', className: 'text-right' },
            ]}
          >
            {records.map(({ r, est }) => {
              const d = r.status === 'previsto' ? null : round2(r.net - est.net)
              return (
                <tr key={r.id} className="hover:bg-gray-50/60">
                  <td className="td whitespace-nowrap font-medium capitalize">{monthLabel(r.month)}</td>
                  <td className="td num">{formatDate(r.expectedDate)}</td>
                  <td className="td num">{formatDate(r.paidDate)}</td>
                  <td className="td num text-right">{brl(r.gross)}</td>
                  <td className="td num text-right text-expense">{brl(r.deductions)}</td>
                  <td className="td num text-right font-medium">{brl(r.net)}</td>
                  <td className="td num text-right text-gray-500">{brl(est.net)}</td>
                  <td className={`td num text-right font-medium ${d === null ? 'text-gray-400' : d >= 0 ? 'text-income' : 'text-expense'}`}>{d === null ? '—' : signed(d)}</td>
                  <td className="td">
                    <Badge tone={statusTone[r.status]}>{STATUS_LABEL[r.status]}</Badge>
                  </td>
                  <td className="td whitespace-nowrap text-right">
                    <Button variant="ghost" size="sm" aria-label={`Editar pagamento de ${monthLabel(r.month)}`} onClick={() => setEditing(r)}>
                      <Pencil size={14} />
                    </Button>
                    <Button variant="ghost" size="sm" aria-label={`Excluir pagamento de ${monthLabel(r.month)}`} onClick={() => setToDelete(r)}>
                      <Trash2 size={14} />
                    </Button>
                  </td>
                </tr>
              )
            })}
          </Table>
        )}
      </Card>

      <PayrollForm record={editing} defaultMonth={month} onClose={() => setEditing(null)} />
      <ConfirmDialog
        open={!!toDelete}
        danger
        title="Excluir pagamento"
        text={toDelete ? `Excluir o registro de ${monthLabel(toDelete.month)}? O lançamento correspondente no livro-caixa também será removido.` : ''}
        confirmLabel="Excluir"
        onClose={() => setToDelete(null)}
        onConfirm={() => {
          if (toDelete) {
            actions.deletePayroll(toDelete.id)
            notify('Pagamento excluído.')
          }
        }}
      />
    </>
  )
}

function PayrollForm({ record, defaultMonth, onClose }: { record: PayrollRecord | 'new' | null; defaultMonth: string; onClose: () => void }) {
  const { data, actions, notify } = useApp()
  const s = data.settings
  const open = record !== null
  const existing = record && record !== 'new' ? record : null

  const [month, setMonth] = useState('')
  const [status, setStatus] = useState<PayrollStatus>('previsto')
  const [expected, setExpected] = useState('')
  const [paid, setPaid] = useState('')
  const [gross, setGross] = useState('')
  const [ded, setDed] = useState('')
  const [notes, setNotes] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [key, setKey] = useState<unknown>(null)

  const defaultExpected = (m: string) => {
    const day = Math.min(28, Math.max(1, s.payDay))
    const base = s.payMonthOffset === 1 ? addMonths(`${m}-01`, 1).slice(0, 7) : m
    return `${base}-${pad(day)}`
  }

  if (record !== key) {
    setKey(record)
    if (record) {
      const m = existing?.month ?? defaultMonth
      setMonth(m)
      setStatus(existing?.status ?? 'previsto')
      setExpected(existing?.expectedDate ?? defaultExpected(m))
      setPaid(existing?.paidDate ?? '')
      setGross(existing ? String(existing.gross).replace('.', ',') : '')
      setDed(existing ? String(existing.deductions).replace('.', ',') : '')
      setNotes(existing?.notes ?? '')
      setErrors({})
    }
  }

  const grossN = parseNumber(gross)
  const dedN = ded.trim() === '' ? 0 : parseNumber(ded)
  const net = Number.isFinite(grossN) && Number.isFinite(dedN) ? round2(grossN - dedN) : NaN
  const est = month ? computePayroll(data, month) : null

  const fillEstimate = () => {
    if (!est) return
    setGross(String(est.gross).replace('.', ','))
    setDed(String(est.totalDeductions).replace('.', ','))
  }

  const save = () => {
    const e: Record<string, string> = {}
    if (!/^\d{4}-\d{2}$/.test(month)) e.month = 'Escolha a competência.'
    if (!Number.isFinite(grossN) || grossN <= 0) e.gross = 'Informe o valor bruto.'
    if (!Number.isFinite(dedN) || dedN < 0) e.ded = 'Descontos inválidos.'
    else if (Number.isFinite(grossN) && dedN > grossN) e.ded = 'Os descontos não podem superar o bruto.'
    if (status !== 'previsto' && !paid) e.paid = 'Informe a data efetiva do pagamento.'
    if (!expected && status === 'previsto') e.expected = 'Informe a data prevista.'
    setErrors(e)
    if (Object.keys(e).length) return
    const err = actions.savePayroll({
      id: existing?.id,
      month,
      status,
      expectedDate: expected,
      paidDate: status === 'previsto' ? '' : paid,
      gross: grossN,
      deductions: dedN,
      net,
      notes: notes.trim(),
    })
    if (err) {
      setErrors({ month: err })
      return
    }
    notify(existing ? 'Pagamento atualizado.' : 'Pagamento registrado e lançado no livro-caixa.')
    onClose()
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      wide
      title={existing ? 'Editar pagamento' : 'Registrar pagamento do salário'}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={save}>Salvar</Button>
        </>
      }
    >
      <form
        className="grid gap-4 sm:grid-cols-2"
        noValidate
        onSubmit={(ev) => {
          ev.preventDefault()
          save()
        }}
      >
        <Field label="Mês de referência" error={errors.month}>
          <Input
            type="month"
            value={month}
            onChange={(e) => {
              setMonth(e.target.value)
              if (!existing && e.target.value) setExpected(defaultExpected(e.target.value))
            }}
            invalid={!!errors.month}
          />
        </Field>
        <Field label="Status">
          <Select value={status} onChange={(e) => setStatus(e.target.value as PayrollStatus)}>
            <option value="previsto">Previsto</option>
            <option value="recebido">Recebido</option>
            <option value="ajustado">Ajustado (recebido com correção)</option>
          </Select>
        </Field>
        <Field label="Data prevista de pagamento" error={errors.expected}>
          <Input type="date" value={expected} onChange={(e) => setExpected(e.target.value)} invalid={!!errors.expected} />
        </Field>
        <Field label="Data efetiva de pagamento" error={errors.paid} hint={status === 'previsto' ? 'Preencha ao receber.' : undefined}>
          <Input type="date" value={paid} onChange={(e) => setPaid(e.target.value)} invalid={!!errors.paid} disabled={status === 'previsto'} />
        </Field>
        <Field label="Valor bruto (R$)" error={errors.gross}>
          <Input inputMode="decimal" value={gross} onChange={(e) => setGross(e.target.value)} invalid={!!errors.gross} placeholder="0,00" />
        </Field>
        <Field label="Descontos (R$)" error={errors.ded}>
          <Input inputMode="decimal" value={ded} onChange={(e) => setDed(e.target.value)} invalid={!!errors.ded} placeholder="0,00" />
        </Field>
        <div className="sm:col-span-2">
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-gray-50 px-4 py-3">
            <div>
              <p className="text-xs text-gray-500">Valor líquido {status === 'previsto' ? 'previsto' : 'recebido'}</p>
              <p className="num text-xl font-semibold">{Number.isFinite(net) ? brl(net) : '—'}</p>
            </div>
            {est && (
              <div className="text-right text-xs text-gray-500">
                <p>
                  Estimativa do sistema: <span className="num font-medium text-gray-800">{brl(est.net)}</span>
                </p>
                {Number.isFinite(net) && (
                  <p className={net - est.net >= 0 ? 'text-income' : 'text-expense'}>Diferença: {signed(round2(net - est.net))}</p>
                )}
                <Button variant="secondary" size="sm" className="mt-1.5" onClick={fillEstimate}>
                  <Wand2 size={13} /> Preencher com a estimativa
                </Button>
              </div>
            )}
          </div>
        </div>
        <Field label="Observações" className="sm:col-span-2">
          <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} maxLength={300} />
        </Field>
        <button type="submit" className="hidden" aria-hidden tabIndex={-1} />
      </form>
    </Modal>
  )
}
