export type ActivityType = 'conferencia' | 'separacao'

export const ACTIVITY_LABEL: Record<ActivityType, string> = {
  conferencia: 'Conferência',
  separacao: 'Separação',
}

export interface ProductivityEntry {
  id: string
  date: string // YYYY-MM-DD
  type: ActivityType
  qty: number
  unitValue: number
  notes?: string
}

export interface Item {
  id: string
  name: string
  amount: number
}

export type PayMode = 'integral' | 'parcial' | 'pendente'

export interface InssConfig {
  mode: 'nenhum' | 'valor' | 'percentual'
  value: number
  competence: string // texto livre: competência / tabela usada
}

export interface Settings {
  displayName: string
  baseSalary: number
  nightPct: number
  attendanceEnabled: boolean
  attendance: number
  rateConferencia: number
  rateSeparacao: number
  prodPayMode: PayMode
  prodPartialPct: number
  // jornada e adicional noturno
  monthlyHours: number // jornada mensal em horas (divisor da hora normal)
  hourlyRateOverride: number // 0 = calcular a partir do salário-base
  nightHoursPerDay: number
  workedDays: number
  nightReducedHour: boolean // hora noturna reduzida (52min30s)
  payrollStartDay: number // 1 = mês-calendário
  payDay: number // dia previsto de pagamento
  payMonthOffset: 0 | 1 // 0 = paga no mesmo mês da competência, 1 = mês seguinte
  overtimeEnabled: boolean
  overtimeHours: number
  overtimePct: number
  otherAdditions: Item[]
  vtMode: 'nenhum' | 'percentual' | 'valor'
  vtPercent: number
  vtFixed: number
  inss: InssConfig
  advances: number
  otherDeductions: Item[]
  // planejamento
  monthlyGoal: number
  expenseCategories: string[]
  incomeCategories: string[]
  accounts: string[]
  budgets: Record<string, number>
  // aparência
  currency: 'BRL' | 'USD' | 'EUR'
  dateFormat: 'br' | 'iso'
  accent: 'grafite' | 'verde' | 'azul'
  textSize: 'normal' | 'grande'
}

export type PayrollStatus = 'previsto' | 'recebido' | 'ajustado'

export interface PayrollRecord {
  id: string
  month: string // YYYY-MM (competência)
  expectedDate: string
  paidDate: string
  gross: number
  deductions: number
  net: number
  status: PayrollStatus
  notes: string
}

export interface MonthParams {
  nightHours?: number
  workedDays?: number
  overtimeHours?: number
  advances?: number
}

export type Recurrence = 'unica' | 'semanal' | 'mensal' | 'anual'
export type ExpenseStatus = 'pendente' | 'paga'

export interface Expense {
  id: string
  name: string
  category: string
  amount: number
  dueDate: string
  paidDate: string
  method: string
  recurrence: Recurrence
  status: ExpenseStatus
  notes: string
  seriesId?: string
  seriesStart?: string
  occurrenceKey?: string
  installment?: { n: number; of: number }
}

export type DebtStatus = 'ativa' | 'negociacao'
export type Priority = 'baixa' | 'media' | 'alta'

export interface Debt {
  id: string
  name: string
  creditor: string
  category: string
  originalAmount: number
  currentAmount: number // 0 = usar valor original menos entrada
  downPayment: number
  totalInstallments: number
  installmentValue: number
  paidInstallmentsInitial: number // parcelas já pagas antes de cadastrar
  interestRate: number // % ao mês; 0 = não informado
  contractDate: string
  nextDue: string
  status: DebtStatus
  priority: Priority
  notes: string
}

export interface DebtPayment {
  id: string
  debtId: string
  date: string
  amount: number
  notes: string
}

export type TxKind = 'normal' | 'transferencia' | 'incorporada'
export type TxStatus = 'previsto' | 'efetivado'

export interface Transaction {
  id: string
  type: 'entrada' | 'saida'
  description: string
  category: string
  amount: number
  date: string
  account: string
  origin: string
  notes: string
  status: TxStatus
  kind: TxKind
  sourceType?: 'salary' | 'expense' | 'debt'
  sourceId?: string
  transferGroup?: string
}

export interface Goal {
  id: string
  name: string
  target: number
  saved: number
  deadline: string
  notes: string
}

export interface AppData {
  version: 1
  settings: Settings
  productivity: ProductivityEntry[]
  payrolls: PayrollRecord[]
  monthParams: Record<string, MonthParams>
  expenses: Expense[]
  deletedOccurrences: string[]
  seriesEnds: Record<string, string>
  debts: Debt[]
  debtPayments: DebtPayment[]
  transactions: Transaction[]
  goals: Goal[]
  updatedAt: string
}

export interface Range {
  from: string
  to: string
}
