import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import type {
  AppData,
  Debt,
  DebtPayment,
  Expense,
  Goal,
  MonthParams,
  PayrollRecord,
  ProductivityEntry,
  Range,
  Settings,
  Transaction,
} from '../types'
import { createInitialData, defaultSettings } from '../lib/defaults'
import { validateBackup } from '../lib/validate'
import { addDays, addMonths, monthLabel, monthRange, todayISO } from '../lib/dates'
import { calcDebt, generateOccurrences } from '../lib/calc'
import { brl, round2, setFormatConfig, uid } from '../lib/format'
import { useAuth } from '../auth/context'
import { activeDataKey, openExternal, saveCorruptedCopy, saveData } from '../auth/vault'

/** Mensagem de erro (texto) ou null quando deu certo. */
export type Err = string | null

export type PeriodMode = 'mes' | 'ano' | 'personalizado'
export interface Period {
  mode: PeriodMode
  month: string
  year: number
  from: string
  to: string
}

export type ExpenseInput = Omit<Expense, 'id'> & { installments?: number }

export interface Actions {
  updateSettings: (patch: Partial<Settings>) => void
  addProductivity: (e: Omit<ProductivityEntry, 'id'>) => void
  updateProductivity: (id: string, patch: Partial<ProductivityEntry>) => void
  deleteProductivity: (id: string) => void
  savePayroll: (r: Omit<PayrollRecord, 'id'> & { id?: string }) => Err
  deletePayroll: (id: string) => void
  setMonthParams: (month: string, p: MonthParams | null) => void
  addExpense: (e: ExpenseInput) => void
  updateExpense: (id: string, patch: Partial<Expense>, propagate?: boolean) => void
  deleteExpense: (id: string, scope: 'one' | 'future') => void
  payExpense: (id: string, date: string, method?: string) => void
  unpayExpense: (id: string) => void
  addDebt: (d: Omit<Debt, 'id'>) => void
  updateDebt: (id: string, patch: Partial<Debt>) => void
  deleteDebt: (id: string) => void
  addDebtPayment: (p: Omit<DebtPayment, 'id'>) => Err
  deleteDebtPayment: (id: string) => void
  addTransaction: (t: Omit<Transaction, 'id'>) => void
  updateTransaction: (id: string, patch: Partial<Transaction>) => void
  deleteTransaction: (id: string) => Err
  addTransfer: (x: { from: string; to: string; amount: number; date: string; notes: string }) => Err
  addGoal: (g: Omit<Goal, 'id'>) => void
  updateGoal: (id: string, patch: Partial<Goal>) => void
  deleteGoal: (id: string) => void
  exportJSON: () => string
  importJSON: (text: string) => { ok: true } | { ok: false; errors: string[] }
  resetSettings: () => void
  wipeAll: () => void
}

interface Toast {
  id: number
  type: 'success' | 'error' | 'info'
  text: string
}

interface Ctx {
  data: AppData
  actions: Actions
  today: string
  period: Period
  range: Range
  setPeriod: (p: Period) => void
  notify: (text: string, type?: Toast['type']) => void
  toasts: Toast[]
  dismissToast: (id: number) => void
  storageError: string | null
}

const AppContext = createContext<Ctx | null>(null)

export function useApp(): Ctx {
  const c = useContext(AppContext)
  if (!c) throw new Error('useApp deve ser usado dentro de <AppProvider>')
  return c
}

/* ------------------------------------------------------------------ */

function withRecurrences(d: AppData, today: string): AppData {
  const created = generateOccurrences(d, today, uid)
  return created.length ? { ...d, expenses: [...d.expenses, ...created] } : d
}

/** Recebe os dados já descriptografados no login (null = conta nova). */
function loadData(raw: unknown | null, today: string): { data: AppData; warning?: string } {
  try {
    if (raw === null || raw === undefined) return { data: withRecurrences(createInitialData(), today) }
    const v = validateBackup(raw)
    if (v.ok) return { data: withRecurrences(v.data, today) }
    // Dados ilegíveis: preserva uma cópia (criptografada) em vez de sobrescrever.
    void saveCorruptedCopy(raw)
    return { data: createInitialData(), warning: 'Os dados salvos estavam inconsistentes. Uma cópia foi preservada no navegador e o sistema iniciou vazio.' }
  } catch {
    return { data: createInitialData(), warning: 'Não foi possível ler os dados salvos no navegador.' }
  }
}

function upsertLinked(
  d: AppData,
  sourceType: NonNullable<Transaction['sourceType']>,
  sourceId: string,
  tx: Omit<Transaction, 'id' | 'sourceType' | 'sourceId'> | null,
): AppData {
  const existing = d.transactions.find((t) => t.sourceType === sourceType && t.sourceId === sourceId)
  const rest = d.transactions.filter((t) => !(t.sourceType === sourceType && t.sourceId === sourceId))
  if (!tx) return { ...d, transactions: rest }
  return {
    ...d,
    transactions: [...rest, { ...tx, account: existing?.account ?? tx.account, id: existing?.id ?? uid(), sourceType, sourceId }],
  }
}

function expenseTx(d: AppData, e: Expense): AppData {
  if (e.status !== 'paga') return upsertLinked(d, 'expense', e.id, null)
  const label = e.installment ? `${e.name} (${e.installment.n}/${e.installment.of})` : e.name
  return upsertLinked(d, 'expense', e.id, {
    type: 'saida',
    description: label,
    category: 'Despesas pessoais',
    amount: e.amount,
    date: e.paidDate || e.dueDate,
    account: d.settings.accounts[0] ?? 'Conta principal',
    origin: e.category,
    notes: e.method ? `Forma de pagamento: ${e.method}` : '',
    status: 'efetivado',
    kind: 'normal',
  })
}

function periodDefault(today: string): Period {
  const y = Number(today.slice(0, 4))
  return { mode: 'mes', month: today.slice(0, 7), year: y, from: `${today.slice(0, 7)}-01`, to: monthRange(today.slice(0, 7)).to }
}

export function periodToRange(p: Period): Range {
  if (p.mode === 'mes') return monthRange(p.month)
  if (p.mode === 'ano') return { from: `${p.year}-01-01`, to: `${p.year}-12-31` }
  const from = p.from <= p.to ? p.from : p.to
  const to = p.from <= p.to ? p.to : p.from
  return { from, to }
}

const ACCENTS: Record<Settings['accent'], string> = { grafite: '17 24 39', verde: '47 125 79', azul: '37 99 235' }

/* ------------------------------------------------------------------ */

export function AppProvider({ children }: { children: ReactNode }) {
  const [today, setToday] = useState(todayISO())
  const todayRef = useRef(today)
  todayRef.current = today

  const { initialRaw } = useAuth()
  const initial = useMemo(() => loadData(initialRaw, todayISO()), [])
  const [data, setData] = useState<AppData>(initial.data)
  const dataRef = useRef(data)
  const skipSave = useRef(false)
  const [storageError, setStorageError] = useState<string | null>(initial.warning ?? null)
  const [period, setPeriod] = useState<Period>(() => periodDefault(todayISO()))
  const [toasts, setToasts] = useState<Toast[]>([])
  const toastId = useRef(0)

  setFormatConfig({ currency: data.settings.currency, dateFormat: data.settings.dateFormat })

  const notify = useCallback((text: string, type: Toast['type'] = 'success') => {
    const id = ++toastId.current
    setToasts((t) => [...t.slice(-3), { id, type, text }])
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), type === 'error' ? 6500 : 3500)
  }, [])
  const dismissToast = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), [])

  // Persistência automática
  useEffect(() => {
    dataRef.current = data
    if (skipSave.current) {
      skipSave.current = false
      return
    }
    saveData(data).then(
      () => setStorageError((e) => (e && e.startsWith('Não foi possível salvar') ? null : e)),
      () => setStorageError('Não foi possível salvar no navegador (armazenamento cheio ou bloqueado). Exporte um backup agora.'),
    )
  }, [data])

  // Sincroniza abas abertas
  useEffect(() => {
    const onStorage = async (e: StorageEvent) => {
      if (!e.newValue || e.key !== activeDataKey()) return
      try {
        const raw = await openExternal(e.newValue)
        if (raw === null) return
        const v = validateBackup(raw)
        if (v.ok) {
          skipSave.current = true
          dataRef.current = v.data
          setData(v.data)
        }
      } catch {
        /* ignora */
      }
    }
    window.addEventListener('storage', onStorage)
    return () => window.removeEventListener('storage', onStorage)
  }, [])

  // Virada de dia: atualiza "hoje" e gera ocorrências recorrentes novas (sem duplicar)
  useEffect(() => {
    const tick = () => {
      const t = todayISO()
      if (t !== todayRef.current) setToday(t)
    }
    const id = setInterval(tick, 60_000)
    document.addEventListener('visibilitychange', tick)
    return () => {
      clearInterval(id)
      document.removeEventListener('visibilitychange', tick)
    }
  }, [])
  useEffect(() => {
    const next = withRecurrences(dataRef.current, today)
    if (next !== dataRef.current) {
      dataRef.current = next
      setData(next)
    }
  }, [today])

  // Aparência
  useEffect(() => {
    document.documentElement.style.setProperty('--accent', ACCENTS[data.settings.accent] ?? ACCENTS.grafite)
    document.documentElement.style.fontSize = data.settings.textSize === 'grande' ? '17px' : '15px'
  }, [data.settings.accent, data.settings.textSize])

  const actions = useMemo<Actions>(() => {
    const commit = (fn: (d: AppData) => AppData) => {
      const next = { ...fn(dataRef.current), updatedAt: new Date().toISOString() }
      dataRef.current = next
      setData(next)
    }
    const get = () => dataRef.current
    const now = () => todayRef.current

    return {
      updateSettings: (patch) => commit((d) => ({ ...d, settings: { ...d.settings, ...patch } })),

      addProductivity: (e) => commit((d) => ({ ...d, productivity: [...d.productivity, { ...e, id: uid() }] })),
      updateProductivity: (id, patch) =>
        commit((d) => ({ ...d, productivity: d.productivity.map((x) => (x.id === id ? { ...x, ...patch } : x)) })),
      deleteProductivity: (id) => commit((d) => ({ ...d, productivity: d.productivity.filter((x) => x.id !== id) })),

      savePayroll: (r) => {
        const d = get()
        const dup = d.payrolls.find((p) => p.month === r.month && p.id !== r.id)
        if (dup) return `Já existe um registro de folha para ${monthLabel(r.month)}. Edite o registro existente.`
        const id = r.id ?? uid()
        const rec: PayrollRecord = { ...r, id, gross: round2(r.gross), deductions: round2(r.deductions), net: round2(r.net) }
        commit((cur) => {
          const payrolls = cur.payrolls.some((p) => p.id === id) ? cur.payrolls.map((p) => (p.id === id ? rec : p)) : [...cur.payrolls, rec]
          const date = rec.status === 'previsto' ? rec.expectedDate : rec.paidDate || rec.expectedDate
          const next = { ...cur, payrolls }
          return upsertLinked(
            next,
            'salary',
            id,
            date
              ? {
                  type: 'entrada',
                  description: `Salário de ${monthLabel(rec.month)}`,
                  category: 'Salário',
                  amount: rec.net,
                  date,
                  account: cur.settings.accounts[0] ?? 'Conta principal',
                  origin: 'Empregador',
                  notes: rec.status === 'previsto' ? 'Valor previsto' : '',
                  status: rec.status === 'previsto' ? 'previsto' : 'efetivado',
                  kind: 'normal',
                }
              : null,
          )
        })
        return null
      },
      deletePayroll: (id) =>
        commit((d) => upsertLinked({ ...d, payrolls: d.payrolls.filter((p) => p.id !== id) }, 'salary', id, null)),
      setMonthParams: (month, p) =>
        commit((d) => {
          const mp = { ...d.monthParams }
          if (!p || Object.keys(p).length === 0) delete mp[month]
          else mp[month] = p
          return { ...d, monthParams: mp }
        }),

      addExpense: (input) =>
        commit((d) => {
          const { installments, ...base } = input
          let list: Expense[] = []
          if (installments && installments > 1 && base.recurrence === 'unica') {
            const seriesId = uid()
            for (let i = 1; i <= installments; i++)
              list.push({
                ...base,
                id: uid(),
                status: 'pendente',
                paidDate: '',
                dueDate: addMonths(base.dueDate, i - 1),
                seriesId,
                occurrenceKey: `${seriesId}|p${i}`,
                installment: { n: i, of: installments },
              })
          } else if (base.recurrence !== 'unica') {
            const seriesId = uid()
            list = [{ ...base, id: uid(), seriesId, seriesStart: base.dueDate, occurrenceKey: `${seriesId}|${base.dueDate}` }]
          } else {
            list = [{ ...base, id: uid() }]
          }
          let next: AppData = { ...d, expenses: [...d.expenses, ...list] }
          for (const e of list) if (e.status === 'paga') next = expenseTx(next, e)
          return withRecurrences(next, now())
        }),
      updateExpense: (id, patch, propagate) =>
        commit((d) => {
          const cur = d.expenses.find((e) => e.id === id)
          if (!cur) return d
          let upd: Expense = { ...cur, ...patch }
          if (upd.status === 'paga' && !upd.paidDate) upd.paidDate = now()
          if (upd.status === 'pendente') upd.paidDate = ''
          // despesa avulsa que passou a ser recorrente vira uma série
          if (!cur.seriesId && upd.recurrence !== 'unica') {
            upd = { ...upd, seriesId: cur.id, seriesStart: upd.dueDate, occurrenceKey: `${cur.id}|${upd.dueDate}` }
          }
          // mudar a data de uma ocorrência recorrente atualiza sua chave
          if (cur.seriesId && cur.recurrence !== 'unica' && patch.dueDate && patch.dueDate !== cur.dueDate) {
            upd.occurrenceKey = `${cur.seriesId}|${patch.dueDate}`
          }
          let expenses = d.expenses.map((e) => (e.id === id ? upd : e))
          if (propagate && cur.seriesId) {
            expenses = expenses.map((e) =>
              e.seriesId === cur.seriesId && e.id !== id && e.status === 'pendente' && e.dueDate > cur.dueDate
                ? { ...e, name: upd.name, category: upd.category, amount: upd.amount, method: upd.method, notes: upd.notes }
                : e,
            )
          }
          let next: AppData = { ...d, expenses }
          next = expenseTx(next, upd)
          const deleted =
            cur.seriesId && cur.recurrence !== 'unica' && cur.occurrenceKey && cur.occurrenceKey !== upd.occurrenceKey
              ? [...next.deletedOccurrences, cur.occurrenceKey]
              : next.deletedOccurrences
          return withRecurrences({ ...next, deletedOccurrences: deleted }, now())
        }),
      deleteExpense: (id, scope) =>
        commit((d) => {
          const e = d.expenses.find((x) => x.id === id)
          if (!e) return d
          let removed: Expense[] = [e]
          let seriesEnds = d.seriesEnds
          if (scope === 'future' && e.seriesId) {
            removed = d.expenses.filter((x) => x.seriesId === e.seriesId && x.dueDate >= e.dueDate && (x.id === id || x.status === 'pendente'))
            if (e.recurrence !== 'unica') seriesEnds = { ...seriesEnds, [e.seriesId]: addDays(e.dueDate, -1) }
          }
          const ids = new Set(removed.map((x) => x.id))
          const deletedOccurrences = [...d.deletedOccurrences, ...removed.map((x) => x.occurrenceKey).filter(Boolean) as string[]]
          let next: AppData = { ...d, expenses: d.expenses.filter((x) => !ids.has(x.id)), deletedOccurrences, seriesEnds }
          for (const r of removed) next = upsertLinked(next, 'expense', r.id, null)
          return next
        }),
      payExpense: (id, date, method) =>
        commit((d) => {
          const cur = d.expenses.find((e) => e.id === id)
          if (!cur) return d
          const upd: Expense = { ...cur, status: 'paga', paidDate: date, method: method || cur.method }
          return expenseTx({ ...d, expenses: d.expenses.map((e) => (e.id === id ? upd : e)) }, upd)
        }),
      unpayExpense: (id) =>
        commit((d) => {
          const cur = d.expenses.find((e) => e.id === id)
          if (!cur) return d
          const upd: Expense = { ...cur, status: 'pendente', paidDate: '' }
          return expenseTx({ ...d, expenses: d.expenses.map((e) => (e.id === id ? upd : e)) }, upd)
        }),

      addDebt: (x) => commit((d) => ({ ...d, debts: [...d.debts, { ...x, id: uid() }] })),
      updateDebt: (id, patch) => commit((d) => ({ ...d, debts: d.debts.map((x) => (x.id === id ? { ...x, ...patch } : x)) })),
      deleteDebt: (id) =>
        commit((d) => {
          const payIds = d.debtPayments.filter((p) => p.debtId === id).map((p) => p.id)
          let next: AppData = { ...d, debts: d.debts.filter((x) => x.id !== id), debtPayments: d.debtPayments.filter((p) => p.debtId !== id) }
          for (const pid of payIds) next = upsertLinked(next, 'debt', pid, null)
          return next
        }),
      addDebtPayment: (p) => {
        const d = get()
        const debt = d.debts.find((x) => x.id === p.debtId)
        if (!debt) return 'Dívida não encontrada.'
        if (!(p.amount > 0)) return 'Informe um valor maior que zero.'
        const before = calcDebt(debt, d.debtPayments, now())
        if (before.status === 'quitada') return 'Esta dívida já está quitada.'
        if (p.amount > before.remaining + 0.005) return `O valor excede o saldo restante (${brl(before.remaining)}).`
        const payment: DebtPayment = { ...p, id: uid(), amount: round2(p.amount) }
        commit((cur) => {
          const payments = [...cur.debtPayments, payment]
          const after = calcDebt(debt, payments, now())
          const diff = after.paidInstallments - before.paidInstallments
          const nextDue = diff > 0 && debt.nextDue ? addMonths(debt.nextDue, diff) : debt.nextDue
          const next: AppData = { ...cur, debtPayments: payments, debts: cur.debts.map((x) => (x.id === debt.id ? { ...x, nextDue } : x)) }
          return upsertLinked(next, 'debt', payment.id, {
            type: 'saida',
            description: `Pagamento: ${debt.name}`,
            category: 'Pagamento de dívidas',
            amount: payment.amount,
            date: payment.date,
            account: cur.settings.accounts[0] ?? 'Conta principal',
            origin: debt.creditor || debt.name,
            notes: payment.notes,
            status: 'efetivado',
            kind: 'normal',
          })
        })
        return null
      },
      deleteDebtPayment: (id) =>
        commit((d) => {
          const p = d.debtPayments.find((x) => x.id === id)
          if (!p) return d
          const debt = d.debts.find((x) => x.id === p.debtId)
          const payments = d.debtPayments.filter((x) => x.id !== id)
          let debts = d.debts
          if (debt) {
            const before = calcDebt(debt, d.debtPayments, now())
            const after = calcDebt(debt, payments, now())
            const diff = before.paidInstallments - after.paidInstallments
            if (diff > 0 && debt.nextDue) debts = d.debts.map((x) => (x.id === debt.id ? { ...x, nextDue: addMonths(debt.nextDue, -diff) } : x))
          }
          return upsertLinked({ ...d, debtPayments: payments, debts }, 'debt', id, null)
        }),

      addTransaction: (t) => commit((d) => ({ ...d, transactions: [...d.transactions, { ...t, id: uid() }] })),
      updateTransaction: (id, patch) =>
        commit((d) => ({ ...d, transactions: d.transactions.map((t) => (t.id === id ? { ...t, ...patch } : t)) })),
      deleteTransaction: (id) => {
        const t = get().transactions.find((x) => x.id === id)
        if (!t) return null
        if (t.sourceType) return 'Este lançamento é vinculado a outro módulo. Desfaça-o na origem (despesa, dívida ou folha).'
        commit((d) => ({
          ...d,
          transactions: d.transactions.filter((x) => x.id !== id && !(t.transferGroup && x.transferGroup === t.transferGroup)),
        }))
        return null
      },
      addTransfer: ({ from, to, amount, date, notes }) => {
        if (from === to) return 'Escolha contas diferentes para a transferência.'
        if (!(amount > 0)) return 'Informe um valor maior que zero.'
        const group = uid()
        const common = { category: 'Transferências', amount: round2(amount), date, notes, status: 'efetivado' as const, kind: 'transferencia' as const, transferGroup: group }
        commit((d) => ({
          ...d,
          transactions: [
            ...d.transactions,
            { ...common, id: uid(), type: 'saida', description: `Transferência para ${to}`, account: from, origin: to },
            { ...common, id: uid(), type: 'entrada', description: `Transferência de ${from}`, account: to, origin: from },
          ],
        }))
        return null
      },

      addGoal: (g) => commit((d) => ({ ...d, goals: [...d.goals, { ...g, id: uid() }] })),
      updateGoal: (id, patch) => commit((d) => ({ ...d, goals: d.goals.map((g) => (g.id === id ? { ...g, ...patch } : g)) })),
      deleteGoal: (id) => commit((d) => ({ ...d, goals: d.goals.filter((g) => g.id !== id) })),

      exportJSON: () => JSON.stringify({ ...get(), exportedAt: new Date().toISOString() }, null, 2),
      importJSON: (text) => {
        let parsed: unknown
        try {
          parsed = JSON.parse(text)
        } catch {
          return { ok: false, errors: ['O arquivo não é um JSON válido.'] }
        }
        const v = validateBackup(parsed)
        if (!v.ok) return v
        commit(() => withRecurrences(v.data, now()))
        return { ok: true }
      },
      resetSettings: () => commit((d) => ({ ...d, settings: JSON.parse(JSON.stringify(defaultSettings)) })),
      wipeAll: () => commit(() => withRecurrences(createInitialData(), now())),
    }
  }, [])

  const range = useMemo(() => periodToRange(period), [period])

  const value: Ctx = { data, actions, today, period, range, setPeriod, notify, toasts, dismissToast, storageError }
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}
