import { StrictMode, useCallback, useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import { AuthGate } from './auth/AuthGate'
import { AppProvider } from './store/store'
import { Layout, NAV, type Route } from './components/Layout'
import { Dashboard } from './pages/Dashboard'
import { Produtividade } from './pages/Produtividade'
import { Salario } from './pages/Salario'
import { Despesas } from './pages/Despesas'
import { Dividas } from './pages/Dividas'
import { LivroCaixa } from './pages/LivroCaixa'
import { Planejamento } from './pages/Planejamento'
import { Relatorios } from './pages/Relatorios'
import { Configuracoes } from './pages/Configuracoes'

const routeFromHash = (): Route => {
  const h = window.location.hash.replace(/^#\/?/, '')
  return (NAV.find((n) => n.route === h)?.route ?? 'inicio') as Route
}

function App() {
  const [route, setRoute] = useState<Route>(routeFromHash)

  useEffect(() => {
    const onHash = () => setRoute(routeFromHash())
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])

  const go = useCallback((r: Route) => {
    window.location.hash = `#/${r}`
    window.scrollTo({ top: 0 })
  }, [])

  useEffect(() => {
    const label = NAV.find((n) => n.route === route)?.label ?? 'Início'
    document.title = `${label} · Meu Controle`
  }, [route])

  return (
    <Layout route={route} go={go}>
      {route === 'inicio' && <Dashboard go={go} />}
      {route === 'produtividade' && <Produtividade />}
      {route === 'salario' && <Salario go={go} />}
      {route === 'despesas' && <Despesas />}
      {route === 'dividas' && <Dividas />}
      {route === 'caixa' && <LivroCaixa />}
      {route === 'planejamento' && <Planejamento />}
      {route === 'relatorios' && <Relatorios />}
      {route === 'configuracoes' && <Configuracoes />}
    </Layout>
  )
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AuthGate>
      <AppProvider>
        <App />
      </AppProvider>
    </AuthGate>
  </StrictMode>,
)
